import './moduleA'

console.log("this is subPageA")

export default 'subPageA'
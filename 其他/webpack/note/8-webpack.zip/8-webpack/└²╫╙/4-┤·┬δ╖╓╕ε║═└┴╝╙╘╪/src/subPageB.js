import './moduleA'

console.log("this is subPageB")

export default 'subPageB'
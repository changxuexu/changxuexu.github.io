const a = "欢迎访问webpack"
export default a
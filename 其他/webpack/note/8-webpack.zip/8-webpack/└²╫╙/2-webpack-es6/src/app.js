import a from './a'
const fn = () => 1;

let arr = [1, 2, 3, 4]
let test = arr.includes(8)

console.log(test);
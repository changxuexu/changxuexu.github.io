import './css/common.css'

//


import 'jQuery'

$(".bigbox").click(function () {
  alert("触发了")
})
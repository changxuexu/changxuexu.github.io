import './moduleA'

export default 'subPageB'
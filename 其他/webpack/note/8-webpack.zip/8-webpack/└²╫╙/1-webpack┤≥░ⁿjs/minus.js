//common.js方式
module.exports = function (a, b) {
  return a - b
}
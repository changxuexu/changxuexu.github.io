// es6 module规范
export default function sum (a, b) {
  return a + b
}
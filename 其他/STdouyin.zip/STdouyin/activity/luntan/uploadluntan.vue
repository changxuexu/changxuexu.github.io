<template>
	<view>
		<block >
			<form @submit="formsubmit" style="margin-top: 100rpx;" >
				<view class="st_box">
					<view class="st_form">
						<view v-if="cateArr">
							<picker @change="cateChange" :value="cindex" :range="cateArr" style="height:80rpx;line-height:80rpx;border-bottom:1px solid #EEEEEE;font-size:26rpx">
								<view class="picker">{{cindex==-1? '请选择发帖类型' : cateArr[cindex]}}</view>
							</picker>
						</view>
					    <view v-if="cate2 && cateArr2 && cateArr2.length>0">
					    	<picker @change="cateChange2" :value="cindex2" :range="cateArr2" style="height:80rpx;line-height:80rpx;border-bottom:1px solid #EEEEEE;font-size:18px">
					    		<view class="picker">{{cindex2==-1? '请选择二级分类' : cateArr2[cindex2]}}</view>
					    	</picker>
					    </view>
						<!-- <view v-if="cateArr">
							<picker @change="cateChange" :value="cindex" :range="cateArr" style="height:80rpx;line-height:80rpx;border-bottom:1px solid #EEEEEE;font-size:18px">
								<view class="picker">{{cindex==-1? '请选择曝光标签' : cateArr[cindex]}}</view>
							</picker>
						</view> -->
						<view><textarea placeholder="输入内容" name="content" maxlength="-1"></textarea></view>
						<view v-if="need_call">
								<input type="text" placeholder="输入联系电话" name="mobile"/>
						</view>
						<block v-if="isphone">
							<view>
									<input type="text" placeholder="请输入姓名" name="name"/>
							</view>
							<view>
									<input type="text" placeholder="请输入手机号" name="mobile"/>
							</view>
						</block>
						
						
						
						<view class="uploadbtn_ziti1">
							插入图片
						</view>
						<view class="flex" style="flex-wrap:wrap;padding-top:20rpx;">
							<view v-for="(item, index) in pics" :key="index" class="layui-imgbox">
								<view class="layui-imgbox-close" @tap="removeimg" :data-index="index" data-field="pics"><image src="/static/img/ico-del.png"></image></view>
								<view class="layui-imgbox-img"><image :src="item" @tap="previewImage" :data-url="item" mode="widthFix"></image></view>
								<!-- <view class="layui-imgbox-repeat" @tap="xuanzhuan" :data-index="index" data-field="pics"><text class="fa fa-repeat"></text></view> -->
							</view>
							<view class="uploadbtn" :style="'background:url('+pre_url+'/static/img/shaitu_icon.png) no-repeat 60rpx;background-size:80rpx 80rpx;border-radius: 20rpx;width:198rpx;height:198rpx;background-color:#F3F3F3;'" @tap="uploadimg" data-field="pics" v-if="pics.length<9">
								
							</view>
							
						</view>
						
						<input type="text" hidden="true" name="pics" :value="pics.join(',')" maxlength="-1"></input>
					
					<view class="uploadbtn_ziti2">
						插入视频
					</view>
						<view class="flex-y-center" style="width:100%;padding:20rpx 0;margin-top:20rpx;">
							<image :src="pre_url+'/static/img/uploadvideo.png'" style="width:200rpx;height:200rpx;border-radius: 20rpx;background:#eee;" @tap="uploadvideo"></image><text v-if="video" style="padding-left:20rpx;color:#333">已上传短视频</text></view>
						<input type="text" hidden="true" name="video" :value="video" maxlength="-1"></input>
				
					
					
					<view class="apply_item">
						<view class="uploadbtn_ziti1">地址</view>
						<view class="flex-y-center"><input type="text" placeholder="请选择地址" name="address" :value="address"
								@tap="locationSelect"></input></view>
					</view>
					
					<!-- ==========商户======== -->
					<view class="uploadbtn_ziti1" style="position: relative;">
						选择商户 (非必选项)
						<view>
							<text
								@tap="selected_product_indexs = []  ,selected_shop_index = null,selected_shop =null, selected_prodcut_index = null,selected_products = [] "
								style="position:absolute;right:4px;margin:auto;top:-4rpx;color:#ff6767;font-size: 28rpx;border-radius: 5px;padding: 5px 5px;background-color: #ffe5e5;">清空选项</text>
						</view>
					</view>
					
					
					<view class="shop-selecter">
						<view class="wrapper flex-y-center">
							<view class="shop-info">
								<view class="shop-title" @tap="showShopPopup()">
									<block v-if="selected_shop">
										{{ selected_shop.name }}
									</block>
									<block v-else>
										选择商户
									</block>
								</view>
					
							</view>
					
							<view class="shop-join" @tap="goto" data-url="/pagesExt/business/apply">
								<view class="join-ing">
									<text>选择入驻</text>
								</view>
							</view>
						</view>
					</view>
					
					
					<view class="product-selecter" v-if="selected_shop">
						<view class="wrapper flex-y-center">
							<view class="product-info">
								<view class="product-title" @tap="showProPopup">
									<block v-if="selected_products.length">
										<block v-for="(item, index) in selected_products" :key="index">
											{{ item.name }}
											<block>,</block>
										</block>
									</block>
									<block v-else>
										选择商品
									</block>
								</view>
					
							</view>
							<view class="product-num" v-if="selected_products.length">
								<text>已选：{{ selected_products.length }}个</text>
							</view>
						</view>
					</view>
					<!-- ==========商户======== -->
			
					</view>

				</view>


				<view class="st_title flex-y-center">
					<button form-type="submit"
						:style="{background:'linear-gradient(-90deg,'+t('#ec81ff')+' 0%,rgba('+t('color1rgb')+',0.8) 100%)'}">立即发布</button>
						
						<button
							style="width:40%;text-align:center;color:#fff;display:flex;align-items:center;justify-content:center;"
							@tap="goto" data-url="fatielog">发布记录
						</button>
				</view>
				
				<view style="width:100%;height:50rpx"></view>
			</form>
		</block>
		<loading v-if="loading"></loading>
		<dp-tabbar :opt="opt"></dp-tabbar>
		<popmsg ref="popmsg"></popmsg>
		
		
		<!-- ==========================商户========================================== -->
		<liu-popup height="1096rpx" radius="12px" type="bottom" ref="shopPopup" :isMask="false">
			<view class="popup-container">
				<view class="popup-header">
					<text>选择商户</text>
				</view>
		
				<view class="popup-main">
					<view class="topsearch flex-y-center">
						<view class="f1 flex-y-center">
							<image class="img" src="/static/img/search_ico.png"></image>
							<input v-model="shop_keyword" placeholder="搜索感兴趣的商户" placeholder-style="font-size:24rpx;color:#C2C2C2"
								@confirm="shopSearchConfirm"></input>
							<view class="camera" v-if="set.image_search == 1" @tap="goto" data-url="/pagesExt/shop/imgsearch"
								:style="'background-image:url('+pre_url+'/static/img/camera.png)'"></view>
						</view>
					</view>
		
					<scroll-view :scroll-y="true" class="popup-list shop-list" @scrolltolower="popupScrollTolower($event,'shop')">
						<uv-radio-group @change="shopChange" v-model="selected_shop_index" placement="column">
							<view class="popup-list-item shop-list-item" v-for="(item, index) in shop_list" :key="index">
								<view class="item-header">
									<view class="shop-name">
										<view class="shop-icon">
											<image src="../../static/img/shop.png" mode=""></image>
										</view>
										<view class="shop-title">
											<text>{{ item.name }}</text>
										</view>
									</view>
								</view>
		
								<view class="item-main">
									<view class="image-area">
										<view class="image-block shop-image">
											<image :src="item.logo">
											</image>
										</view>
									</view>
		
		
									<view class="content-area">
										<view class="rate-area">
											<uv-rate active-color="#FF9900" :count="5" :value="parseFloat(item.comment_score)" readonly />
										</view>
										<view class="address-area">
											<image src="../../static/img/position.png" class="icon" mode=""></image>
											<text class="text">{{ item.address }}</text>
										</view>
										<view class="tel-area">
											<image src="../../static/img/phone.png" class="icon" mode=""></image>
											<text class="text">{{ item.tel }}</text>
										</view>
									</view>
		
									<view class="operate-area">
										<uv-radio activeColor="#ff9900" :name="index" shape="circle"></uv-radio>
									</view>
								</view>
							</view>
						</uv-radio-group>
						<nomore v-if="nomore"></nomore>
					</scroll-view>
				</view>
		
		
			</view>
		</liu-popup>
		
		<liu-popup height="1096rpx" radius="12px" type="bottom" ref="proPopup" :isMask="false">
			<view class="popup-container">
				<view class="popup-header">
					<text>选择商品</text>
				</view>
		
				<view class="popup-main popup-product-main">
					<view class="topsearch flex-y-center">
						<view class="f1 flex-y-center">
							<image class="img" src="/static/img/search_ico.png"></image>
							<input v-model="keyword" placeholder="搜索感兴趣的商品" placeholder-style="font-size:24rpx;color:#C2C2C2"
								@confirm="productSearchConfirm"></input>
							<view class="camera" v-if="set.image_search == 1" @tap="goto" data-url="/pagesExt/shop/imgsearch"
								:style="'background-image:url('+pre_url+'/static/img/camera.png)'"></view>
						</view>
					</view>
		
					<scroll-view :scroll-y="true" class="popup-list pro-list"
						@scrolltolower="popupScrollTolower($event,'product')">
						<uv-checkbox-group @change="productChange" v-model="selected_prodcut_index" placement="column">
							<view class="popup-list-item pro-list-item" v-for="(item, index) in product_list" :key="index">
								<view class="item-main">
									<view class="image-area">
										<view class="image-block shop-image">
											<image :src="item.pic">
											</image>
										</view>
									</view>
		
		
									<view class="content-area">
		
										<view class="pro-title-area">
											<text class="text">{{ item.name }}</text>
										</view>
										<view class="pro-price-area">
											<text style="font-size:24rpx;">￥</text>
											<text>{{ item.sell_price }}</text>
										</view>
									</view>
		
									<view class="operate-area">
										<uv-checkbox activeColor="#ff9900" :name="index" shape="circle"></uv-checkbox>
									</view>
								</view>
							</view>
						</uv-checkbox-group>
						<nomore v-if="nomore"></nomore>
					</scroll-view>
				</view>
		
				<view class="popup-footer">
					<uv-button type="success" text="确定" @tap="productPopupConfirm"></uv-button>
				</view>
			</view>
		</liu-popup>
		<!-- ===========================商户======================================== -->
		

		
	</view>
</template>
<script>
	var app = getApp();
	import liuPopup from '../luntan/omponents/liu-popup/liu-popup.vue';

	export default {
		components: {
			liuPopup
		},
		data() {
			return {
				pre_url: app.globalData.pre_url,
				opt: {},
				loading: false,
				isload: false,
				menuindex: -1,
				datalist: [],
				content_pic: [],
				pagenum: 1,
				cindex: -1,
				pics: [],
				video: '',
				need_call: false,
				shopPopup: false,
				shop_list: [],
				product_list: [],
				selected_shop_index: null,
				selected_prodcut_index: null,
				selected_shop: null,
				selected_products: [],
				selected_product_indexs: [],
				shopPageNum: 1,
				productPageNum: 1,
				nomore: false,
				keyword: '',
				shop_keyword: '',
				st: '0',
				cate2:false,
				cateArr: [],
				sysset: {},
				address: '',
				longitude: '',
				latitude: '',
				
				proPopup: false,
				videoDes: '',
				clist: [],
				activeTopic: 0
			};
		},

		onLoad: function(opt) {
			this.opt = app.getopts(opt);
			this.getdata();
		},
		created() {
			this.getdata();
		},
		onShow() {
			// this.showShopPopup()
		},
		onPullDownRefresh: function() {
			this.getdata();
		},
		methods: {

			getdata: function() {
				var that = this;
				that.loading = true;
				app.get('ApiLuntan/fatie', {}, function(res) {
					that.loading = false;
					if (res.status == 0) {
						app.alert(res.msg);
						return;
					}
					that.clist = res.clist;
					var clist = res.clist;
					if (clist.length > 0) {
						var cateArr = [];
						for (var i in clist) {
							if (that.opt && that.opt.cid == clist[i].id) {
								that.cindex = i;
							}
							cateArr.push(clist[i].name);
						}
					} else {
						cateArr = false;
					}
					that.cateArr = cateArr
					if (res.need_call) {
						that.need_call = true;
					}
					that.loaded();
				});
			},
			changetab(e) {
				this.st = e;
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
			},
			// 地址
			locationSelect: function() {
				var that = this;
				uni.chooseLocation({
					success: function(res) {
						console.log(res)
						that.address = res.address;
						that.latitude = res.latitude;
						that.longitude = res.longitude;
					},
					fail(err) {
						console.log("Select location fail!", err)
					}
				});
			},
			cateChange: function(e) {
				this.cindex = e.detail.value;
			},
			formsubmit: function(e) {
				var that = this;
				console.log(e);
				var clist = that.clist;
				if (clist.length > 0) {
					if (that.cindex == -1) {
						app.error('请选择分类');
						return false;
					}
					var cid = clist[that.cindex].id;
				} else {
					var cid = 0;
				}
				var formdata = e.detail.value;
				var content = formdata.content;
				var pics = formdata.pics;
				var video = formdata.video;
				let product = that.selected_products
				let shop = that.selected_shop
				var address = formdata.address
				console.log(shop, product)
				if (shop)
					delete shop.prolist
				var mobile = formdata.mobile;
				if (content == '' && pics == '') {
					app.error('请输入内容');
					return false;
				}
				// console.log("pics", formdata.pics)
				// return false
				if (pics == '') {
					app.error('至少上传一张图片！')
					return false
				}
				app.post('ApiLuntan/fatie', {
					cid: cid,
					pics: pics,
					content: content,
					video: video,
					shop: shop,
					product: product,
					mobile: mobile,
					type: that.st,
					address: address,
					latitude: that.latitude,
					longitude: that.longitude
				}, function(res) {
					app.showLoading(false);
					if (res.status == 1) {
						app.success(res.msg);
						setTimeout(function() {
							app.goback(true);
						}, 1000);
					} else {
						app.error(res.msg);
					}
				});
			},
			uploadimg: function(e) {
				var that = this;
				var field = e.currentTarget.dataset.field
				var pics = that[field]
				if (!pics) pics = [];
				app.chooseImage(function(urls) {
					for (var i = 0; i < urls.length; i++) {
						pics.push(urls[i]);
					}
					if (field == 'pic') that.pic = pics;
					if (field == 'pics') that.pics = pics;
					if (field == 'zhengming') that.zhengming = pics;
				}, 9)
			},
			uploadvideo: function() {
				var that = this;
				console.log(11);
				uni.chooseVideo({
					compressed: false,
					sourceType: ['album', 'camera'],
					maxDuration: 60,
					success: function(res) {
						var tempFilePath = res.tempFilePath;
						app.showLoading('上传中');
						uni.uploadFile({
							url: app.globalData.baseurl + 'ApiImageupload/uploadImg/aid/' + app
								.globalData.aid + '/platform/' + app.globalData.platform +
								'/session_id/' + app.globalData.session_id,
							filePath: tempFilePath,
							name: 'file',
							success: function(res) {
								app.showLoading(false);
								var data = JSON.parse(res.data);

								if (data.status == 1) {
									that.video = data.url;
								} else {
									app.alert(data.msg);
								}
							},
							fail: function(res) {
								app.showLoading(false);
								app.alert(res.errMsg);
							}
						});
					},
					fail: function(res) {
						console.log(res); //alert(res.errMsg);
					}
				});
			},
			removeimg: function(e) {
				var that = this;
				var index = e.currentTarget.dataset.index
				var field = e.currentTarget.dataset.field
				var pics = that[field]
				pics.splice(index, 1)
			},
			
			// ===========商户
			showShopPopup(e) {
				var that = this;
			
				that.$refs.shopPopup.open()
			
				that.getBlistData()
			},
			showProPopup() {
				this.$refs.proPopup.open()
			
				this.getProductList()
			
			},
			getBlistData: function() {
				var that = this;
				that.loading = true
				that.nomore = false;
				app.post('ApiBusiness/blist', {
					field: "juli",
					keyword: "",
					latitude: "",
					longitude: "",
					order: "asc",
					pagenum: that.shopPageNum,
					keyword: that.shop_keyword
				}, function(res) {
					if (res.data.length === 0) {
						that.nomore = true
			
					} else {
						if (that.shop_list.length > 0) {
							that.shop_list.concat(res.data)
						} else {
							that.shop_list = res.data
						}
						that.shopPageNum++
					}
					that.loading = false
				});
			},
			shopChange(e) {
				const that = this
				console.log('shopChange', e)
				that.selected_shop = that.shop_list[e]
				this.product_list = []
				this.productPageNum = 1
				this.selected_product = null
				this.$refs.shopPopup.close()
			},
			popupScrollTolower(e, type) {
				console.log("type", type)
				if (type === "shop") {
					this.getBlistData()
				}
				if (type == 'product')
					this.getProductList()
			},
			getProductList: function(loadmore) {
				var that = this;
				var pagenum = that.productPageNum;
				var st = 0
				const keyword = that.keyword
				that.loading = true;
				that.nomore = false;
				app.post('ApiBusiness/getdatalist', {
					id: that.selected_shop.id,
					st: st,
					pagenum: pagenum,
					yuyue_cid: 0,
					keyword: keyword
				}, function(res) {
					if (res.data.length === 0) {
						that.nomore = true
			
					} else {
						if (that.product_list.length > 0) {
							that.product_list.concat(res.data)
						} else {
							that.product_list = res.data
						}
						that.productPageNum++
					}
					that.loading = false
				});
			},
			productChange(e) {
				const that = this
				console.log(e)
				that.selected_product_indexs = e
				// this.$refs.proPopup.close()
			},
			productPopupConfirm() {
				const that = this
				that.selected_products = []
				that.selected_product_indexs.forEach((item, index) => {
					that.selected_products.push(that.product_list[index])
				})
				this.$refs.proPopup.close()
			},
			productSearchConfirm() {
				console.log(this.keyword)
				this.product_list = []
				this.productPageNum = 1
				this.getProductList()
			},
			shopSearchConfirm() {
				this.shop_list = []
				this.shopPageNum = 1
				this.getBlistData()
			}
		}
	};
</script>
<style>
	page {
		background: #f7f7f7
	}

	.st_box {
		padding: 4rpx 0;
		margin-top: 90rpx;
	}

	.st_title {
		display: flex;
		justify-content: space-between;
		padding: 24rpx;
	}

	.st_title1 {
		display: flex;
		justify-content: space-between;
		padding: 24rpx;
		border-bottom: 1px solid #D0D0D0
	}

	.st_title image {
		width: 18rpx;
		height: 32rpx
	}

	.st_title text {
		color: #242424;
		font-size: 36rpx
	}

	/* .st_title button{ background: #31C88E; border-radius:6rpx; line-height: 48rpx;border: none; padding:0 20rpx ;color:#fff;margin:0} */


	.st_title button {
		border-radius: 16rpx;
		line-height: 48rpx;
		border: none;
		padding: 0 20rpx;
		color: #fff;
		font-size: 18px;
		text-align: center;
		/* margin: 0; */
		width: 45%;
		display: flex;
		height: 80rpx;
		background: linear-gradient(-90deg,#03f4f4,#ffd55a);
		box-shadow: 2rpx 2rpx 30rpx #abecff;
		justify-content: center;
		align-items: center;
	}



	.st_form {
		padding: 24rpx;
		background: #ffffff;
		margin: 16rpx;
		border-radius: 30rpx;
	}

	.st_form input {
		width: 100%;
		height: 120rpx;
		border: none;
		border-bottom: 1px solid #EEEEEE;
	}

	.st_form input::-webkit-input-placeholder {
		/* WebKit browsers */
		color: #BBBBBB;
		font-size: 24rpx
	}

	.st_form textarea {
		width: 100%;
		min-height: 200rpx;
		padding: 20rpx 0;
		border: none;
		/*border-bottom: 1px solid #EEEEEE;*/
		background-color: #f9f9f9;
		border-radius: 16rpx;
		padding: 20rpx;
		margin-top: 16rpx;
	}

	.layui-imgbox {
		margin-right: 16rpx;
		margin-bottom: 10rpx;
		font-size: 24rpx;
		position: relative;
	}

	.layui-imgbox-close {
		position: absolute;
		display: block;
		width: 32rpx;
		height: 32rpx;
		right: -16rpx;
		top: -16rpx;
		z-index: 90;
		color: #999;
		font-size: 32rpx;
		background: #fff
	}

	.layui-imgbox-close image {
		width: 100%;
		height: 100%
	}

	.layui-imgbox-img {
		display: block;
		width: 195rpx;
		height: 195rpx;
		padding: 1px;
		border: #d3d3d3 1px solid;
		background-color: #f6f6f6;
		overflow: hidden
	}

	.layui-imgbox-img>image {
		max-width: 100%;
	}

	.layui-imgbox-repeat {
		position: absolute;
		display: block;
		width: 32rpx;
		height: 32rpx;
		line-height: 28rpx;
		right: 2px;
		bottom: 2px;
		color: #999;
		font-size: 30rpx;
		background: #fff
	}

	.uploadbtn {
		position: relative;
		height: 100rpx;
		width: 100rpx
	}

	.uploadbtn_ziti1 {
		height: 30rpx;
		line-height: 30rpx;
		font-size: 28rpx;
		margin-top: 20rpx;
		color: #bfbfbf;
	}

	.uploadbtn_ziti2 {
		height: 30rpx;
		line-height: 30rpx;
		font-size: 30rpx;
		padding-top: 20rpx;
		margin-top: 20rpx;
		/*border-top: 1px solid #EEEEEE;*/
	}


	.shop-selecter,
	.product-selecter {
		background-color: #f9f9f9;
		padding: 24rpx 20rpx;
		font-size: 28rpx;
		color: #8b8b8b;
		margin-top: 24rpx;
		border-radius: 14rpx;
	}

	.shop-selecter>.wrapper,
	.product-selecter>.wrapper {
		justify-content: space-between;
	}

	.product-selecter .product-info .product-title {
		width: 240px;
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		display: block;
	}

	.shop-selecter>.wrapper>.shop-join {
		color: #999;
		font-size: 28rpx;
	}


	.popup-container {
		min-height: 1093rpx;
		background-color: #f1f3f5;
		box-sizing: border-box;
		padding: 30rpx 24rpx;
		/* z-index: 99999999999; */
		position: relative;
		bottom: 0;
		border-radius: 32rpx 32rpx 0;
		width: 100%;
	}

	.popup-container .popup-header {
		font-family: 'IM FELL French Canon SC';
		font-style: normal;
		font-weight: 400;
		font-size: 32rpx;
		text-align: center;
		color: #000000;
	}

	.popup-container .popup-main {
		margin-top: 32rpx;

	}

	.popup-container .popup-product-main {
		margin-bottom: 16rpx;
	}

	.popup-container .popup-main .popup-list {
		height: 772rpx;
		margin-top: 20rpx;
	}

	.popup-container .popup-main .shop-list {
		height: 856rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item {
		padding: 26rpx 18rpx;
		background-color: #fff;
		border-radius: 16rpx;
		margin-top: 16rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item:first-child {
		margin-top: 0;
	}

	.popup-container .popup-main .shop-list .shop-list-item {}

	.popup-container .popup-main .shop-list .shop-list-item .item-header {
		display: flex;
	}


	.popup-container .popup-main .shop-list .shop-list-item .item-header .shop-name {
		display: flex;
		align-items: center;
		justify-content: space-around;
		color: #000000;
		font-size: 32rpx;
		font-weight: 400;
		letter-spacing: 0em;

	}

	.popup-container .popup-main .shop-list .shop-list-item .item-header .shop-name .shop-icon {
		position: relative;
		width: 40rpx;
		height: 40rpx;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-header .shop-name .shop-icon image {
		display: block;
		width: 100%;
		height: 100%;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-header .shop-name .shop-title {
		margin-left: 8rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item .item-main {
		display: flex;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-main {
		margin-top: 32rpx;

	}

	.popup-container .popup-main .shop-list .shop-list-item .item-main .image-area {
		display: block;

	}


	.popup-container .shop-list .shop-list-item .item-main .image-area .image-block {
		width: 172rpx;
		height: 132rpx;
	}

	.popup-container .pro-list .pro-list-item .item-main .image-area .image-block {
		width: 160rpx;
		height: 160rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item .item-main .image-area .image-block image {
		display: block;
		width: 100%;
		height: 100%;
		border-radius: 16rpx;

	}

	.popup-container .popup-main .pro-list .pro-list-item .item-main .content-area {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-left: 16rpx;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-main .content-area {
		color: #949494;
		margin-left: 16rpx;
		font-size: 24rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}


	.popup-container .popup-main .popup-list .popup-list-item .item-main .content-area .address-area {
		display: flex;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-main .content-area .icon {
		width: 32rpx;
		height: 32rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item .item-main .content-area .text {
		text-overflow: ellipsis;
		display: inline-block;
		overflow: hidden;
		white-space: nowrap;
		margin-left: 8rpx;
		width: 420rpx;
	}

	.popup-container .popup-main .shop-list .shop-list-item .item-main .content-area .text {
		width: 372rpx;
	}

	.popup-container .popup-main .popup-list .popup-list-item .item-main .operate-area {
		display: flex;
		align-items: center;
		margin-left: 16rpx;
	}



	.popup-container .popup-main .popup-list .popup-list-item .item-main .content-area .pro-title-area .text {
		color: #000000;
		font-size: 32rpx;
		text-align: left;
		white-space: revert;
		line-clamp: 2;
		display: -webkit-box;
		overflow: hidden;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.popup-container .popup-main .popup-list .popup-list-item .item-main .content-area .pro-price-area {
		font-size: 32rpx;
		/* identical to box height */


		color: #FF5757;

	}

	.topsearch {
		width: 100%;
	}

	.topsearch .f1 {
		height: 64rpx;
		border-radius: 30rpx;
		border: 0;
		background-color: #ffffff;
		flex: 1;
	}

	.topsearch .f1 .img {
		width: 24rpx;
		height: 24rpx;
		margin-left: 10px
	}

	.topsearch .f1 input {
		height: 100%;
		flex: 1;
		padding: 0 20rpx;
		font-size: 28rpx;
		color: #333;
	}

	.topsearch .f1 .camera {
		height: 72rpx;
		width: 72rpx;
		color: #666;
		border: 0px;
		padding: 0px;
		margin: 0px;
		background-position: center;
		background-repeat: no-repeat;
		background-size: 40rpx;
	}

	.topsearch .search-btn {
		display: flex;
		align-items: center;
		color: #5a5a5a;
		font-size: 30rpx;
		width: 60rpx;
		text-align: center;
		margin-left: 20rpx
	}
	
	
	.uploadbtn_ziti1 {
		height: 30rpx;
		line-height: 30rpx;
		font-size: 30rpx;
		margin-top: 20rpx;
	}
	
	.uploadbtn_ziti2 {
		height: 30rpx;
		line-height: 30rpx;
		font-size: 30rpx;
		padding-top: 20rpx;
		margin-top: 20rpx;
		/*border-top: 1px solid #EEEEEE;*/
		color: #bfbfbf;
	}
	
	.gk-radio {
		color: #bfbfbf;
		padding: 10px;
	}
</style>

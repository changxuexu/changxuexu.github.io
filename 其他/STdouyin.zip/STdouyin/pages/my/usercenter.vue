<template>
<view class="container" :style="{backgroundColor:pageinfo.bgcolor}">
	<dp :pagecontent="pagecontent" :isapplymendian="isapplymendian"></dp>
	
	
	
	<view class="qrcodebox" v-if="showthqrcode && thqrcode">
		<view class="qrcode"><image :src="thqrcode" @tap="previewImage" :data-url="thqrcode" ></view>
		<view class="t1">向{{t('门店')}}出示二维码提货</view>
	</view>
	
	
	<view v-if="showxieyi" class="xieyibox">
		<view class="xieyibox-content">
			<view style="overflow:scroll;height:100%;">
				<parse :content="xycontent" @navigate="navigate"></parse>
			</view>
			<view style="position:absolute;z-index:9999;bottom:10px;left:0;right:0;margin:0 auto;text-align:center; width: 50%;height: 60rpx; line-height: 60rpx; color: #fff; border-radius: 8rpx;" :style="{background:'linear-gradient(90deg,'+t('color1')+' 0%,rgba('+t('color1rgb')+',0.8) 100%)'}"  @tap="hidexieyi">已阅读并同意</view>
		</view>
	</view>
	<view v-if="copyright!=''" class="copyright" @tap="goto" :data-url="copyright_link">{{copyright}}</view>
	<dp-tabbar :opt="opt"></dp-tabbar>
	<popmsg ref="popmsg"></popmsg>
		<popmsg ref="popmsg"></popmsg>
</view>
</template>

<script>

var app = getApp();
export default {
	data() {
	return {
			opt:{},
			loading:false,
      isload: false,
			pageinfo: [],
			pagecontent: [],
			copyright:'',
			copyright_link:'',
			xixie:false,
			showxieyi:false,
			xycontent:'',
			thqrcode:'',
			showthqrcode:'',
			isapplymendian:0
		}
	},
	onShow:function() {
    if(app.globalData.platform=='wx' && app.globalData.hide_home_button==1){
      uni.hideHomeButton();
    }
	},
	onLoad: function (opt) {
		this.opt = app.getopts(opt);
		this.getdata(); 
	},
	onPullDownRefresh:function(e){
		this.getdata();
	},
	methods: {
		getdata:function(){
			var that = this;
			that.loading = true;
			app.get('ApiMy/usercenter',{},function (data){
				that.loading = false;
			  var pagecontent = data.pagecontent;
				that.pageinfo = data.pageinfo;
				that.pagecontent = data.pagecontent;
				that.copyright = data.copyright;
				that.copyright_link = data.copyright_link || '';
				that.thqrcode = data.thqrcode
				that.showthqrcode = data.showthqrcode
				uni.setNavigationBarTitle({
					title: data.pageinfo.title
				});
				if(data.xixie){
					that.xixie = data.xixie;
				}
				if(data.isapplymendian){
					that.isapplymendian = data.isapplymendian;
				}
				that.loaded();
			});
			//获取升级协议
			app.get('ApiMy/getUpAgree',{'needinit':0},function (data){
				if(data.data.uplv_agree){
					that.showxieyi = true;
					that.xycontent = data.data.agree_content;
				}
			});
		},
		hidexieyi: function () {
			var that = this
		  //同意升级
		  app.get('ApiMy/agreeUplv',{'needinit':0},function (data){
		  	console.log(data);
		  	if(data.status==1){
				that.showxieyi = false;
		  		that.getdata();
		  	}
		  });
		},
	}
}
</script>
<style>
.container{width: 100%;min-height: 100vh;}
.xieyibox{width:100%;height:100%;position:fixed;top:0;left:0;z-index:99;background:rgba(0,0,0,0.7)}
.xieyibox-content{width:90%;margin:0 auto;height:80%;margin-top:10%;background:#fff;color:#333;padding:5px 10px 50px 10px;position:relative;border-radius:2px}

.qrcodebox{ background: #fff; border-radius: 20rpx; display: flex;align-items: center;justify-content: center;margin:0 30rpx 30rpx;padding: 30rpx 30rpx;  }
.qrcodebox image{ width: 200rpx; height:200rpx;margin-right: 30rpx;}
.qrcodebox .t1{ color: #2B9D4B;}
</style>
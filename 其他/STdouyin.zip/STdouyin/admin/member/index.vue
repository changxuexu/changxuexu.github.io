<template>
<view>
	<block v-if="isload">
		<view class="topsearch flex-y-center">
			<view class="f1 flex-y-center">
				<image class="img" src="/static/img/search_ico.png"></image>
				<input :value="keyword" placeholder="输入昵称/姓名/手机号搜索" placeholder-style="font-size:24rpx;color:#C2C2C2" @confirm="searchConfirm" @input="searchChange"></input>
			</view>
		</view>
		<view class="content" v-if="datalist && datalist.length>0">
			<view class="label">
				<text class="t1">{{t('会员')}}列表（共{{count}}人）</text>
				<view class="btn" @tap="goto" data-url="/admin/order/addmember?type=1"  v-if="is_add_member">添加会员</view>
			</view>
			<block v-for="(item, index) in datalist" :key="index">
				<view class="item">
					<view class="f1" @tap="goto" :data-url="'detail?mid=' + item.id">
						<image :src="item.headimg"></image>
						<view class="t2">
							<view v-if="dkopen && item.realname">
								{{item.realname}}
							</view>
							<view class="x1 flex-y-center">
								{{item.nickname}}
								<image style="margin-left:10rpx;width:40rpx;height:40rpx" src="/static/img/nan.png" v-if="item.sex==1"></image>
								<image style="margin-left:10rpx;width:40rpx;height:40rpx" src="/static/img/nv.png" v-if="item.sex==2"></image>
							</view>
							<block v-if="!dkopen">
								<text class="x2">最后访问：{{item.last_visittime}}</text>
								<text class="x2">加入时间：{{item.createtime}}</text>
								<text class="x2">{{item.province ? '' : item.province}}{{item.city ? '' : item.city}}</text>
								<text class="x2" v-if="item.remark" style="color:#a66;font-size:22rpx">{{item.remark}}</text>
							</block>
							<block v-if='item.tel && dkopen'>
								<text class="x2">手机号：{{item.tel}}</text>
							</block>
						</view>
					</view>
					<view class="f2" v-if="!dkopen">
						<view class="btn" @tap="goto" :data-url="'detail?mid=' + item.id">详情</view>
						<view class="btn" @tap="goto" :data-url="'/admin/member/history?id='+item.id">足迹</view>
						<view v-if="item.can_login" class="btn" @tap="loginUser(item.id,item.tel)">登录</view>
					</view>
					<view class="f2" v-else>
						<view class="btn" @click="SelectMembers(item)">选择</view>
					</view>
				</view>
			</block>
		</view>
		<nomore v-if="nomore"></nomore>
		<nodata v-if="nodata"></nodata>
		<view class="tabbar" v-if="!dkopen">
			<view class="tabbar-bot"></view>
			<view class="tabbar-bar" style="background-color:#ffffff;">
				<view @tap="goto" data-url="../member/index" data-opentype="reLaunch" class="tabbar-item" v-if="auth_data.member">
					<view class="tabbar-image-box">
						<image class="tabbar-icon" :src="pre_url+'/static/img/admin/member2.png?v=1'"></image>
					</view>
					<view class="tabbar-text active">{{t('会员')}}</view>
				</view>
				<view @tap="goto" data-url="../kefu/index" data-opentype="reLaunch" class="tabbar-item" v-if="auth_data.zixun">
					<view class="tabbar-image-box">
						<image class="tabbar-icon" :src="pre_url+'/static/img/admin/zixun.png?v=1'"></image>
					</view>
					<view class="tabbar-text">咨询</view>
				</view>
				<view @tap="goto" data-url="../finance/index" data-opentype="reLaunch" class="tabbar-item" v-if="auth_data.finance">
					<view class="tabbar-image-box">
						<image class="tabbar-icon" :src="pre_url+'/static/img/admin/finance.png?v=1'"></image>
					</view>
					<view class="tabbar-text">财务</view>
				</view>
				<view @tap="goto" data-url="../index/index" data-opentype="reLaunch" class="tabbar-item">
					<view class="tabbar-image-box">
						<image class="tabbar-icon" :src="pre_url+'/static/img/admin/my.png?v=1'"></image>
					</view>
					<view class="tabbar-text">我的</view>
				</view>
			</view>
		</view>
	</block>
	<popmsg ref="popmsg"></popmsg>
	<loading v-if="loading"></loading>
</view>
</template>

<script>
var app = getApp();

export default {
  data() {
    return {
      opt:{},
			loading:false,
      isload: false,
			pre_url:app.globalData.pre_url,

      datalist: [],
      pagenum: 1,
      nomore: false,
			nodata:false,
      count: 0,
      keyword: '',
      auth_data: {},
			dkopen:false,
			member_tel:'',
			member_pwd:'',
			is_add_member:1
    };
  },
  onLoad: function (opt) {
		this.opt = app.getopts(opt);
		this.getdata();
		if(opt.type) this.dkopen = true;
  },
	onPullDownRefresh: function () {
		this.getdata();
	},
  onReachBottom: function () {
    if (!this.nodata && !this.nomore) {
      this.pagenum = this.pagenum + 1;
      this.getdata(true);
    }
  },
  methods: {
		SelectMembers(item){
			app.goto('/admin/order/dkorder?mid='+item.id)
		},
    getdata: function (loadmore) {
			if(!loadmore){
				this.pagenum = 1;
				this.datalist = [];
			}
      var that = this;
			var pagenum = that.pagenum;
      var keyword = that.keyword;
			that.nodata = false;
			that.nomore = false;
			that.loading = true;
      app.post('ApiAdminMember/index', {keyword: keyword,pagenum: pagenum}, function (res) {
        that.loading = false;
				that.is_add_member = res.is_add_member ? res.is_add_member:0;
        var data = res.datalist;
        if (pagenum == 1) {
					that.datalist = data;
					that.count = res.count;
					that.auth_data = res.auth_data;
          if (data.length == 0) {
            that.nodata = true;
          }
					uni.setNavigationBarTitle({
						title: that.t('会员') + '列表'
					});
					that.loaded();
        }else{
          if (data.length == 0) {
            that.nomore = true;
          } else {
            var datalist = that.datalist;
            var newdata = datalist.concat(data);
            that.datalist = newdata;
          }
        }
      });
    },
    searchChange: function (e) {
      this.keyword = e.detail.value;
    },
    searchConfirm: function (e) {
      var that = this;
      var keyword = e.detail.value;
      that.keyword = keyword;
      that.getdata();
    },
	loginUser:function (id,tel){
		var str = id+tel
		app.post("ApiAdminMember/adminLoginUser", {mid:id,str:str}, function (res) {
			app.showLoading(false);
		    if (res.status == 1) {
		    app.success(res.msg);
				
					setTimeout(function () {
						app.goto('/pages/my/usercenter','redirect');
					}, 1000);
				
		  } else {
		    app.error(res.msg);
		  }
		});
	}
  }
};
</script>
<style>
@import "../common.css";
.topsearch{width:94%;margin:16rpx 3%;}
.topsearch .f1{height:60rpx;border-radius:30rpx;border:0;background-color:#fff;flex:1}
.topsearch .f1 .img{width:24rpx;height:24rpx;margin-left:10px}
.topsearch .f1 input{height:100%;flex:1;padding:0 20rpx;font-size:28rpx;color:#333;}

.content{width: 94%;margin:0 3%;background: #fff;border-radius:16rpx}
.content .label{display:flex;width: 100%;padding:24rpx 16rpx;color: #333;}
.content .label .t1{flex:1}
.content .label .t2{ width:300rpx;text-align:right}
.content .label .btn{ border-radius:8rpx; padding:3rpx 12rpx;margin-left: 10px;border: 1px #999 solid; text-align:center; font-size:28rpx;color:#333;}

.content .item{width: 100%;padding: 32rpx;border-top: 1px #e5e5e5 solid;min-height: 112rpx;display:flex;align-items:center;}
.content .item image{width:90rpx;height:90rpx;}
.content .item .f1{display:flex;flex:1}
.content .item .f1 .t2{display:flex;flex-direction:column;padding-left:20rpx}
.content .item .f1 .t2 .x1{color: #222;font-size:30rpx;}
.content .item .f1 .t2 .x2{color: #999;font-size:24rpx}

.content .item .f2{display:flex;flex-direction:column;width:auto;text-align:right;border-left:1px solid #e5e5e5}
.content .item .f2 .t1{ font-size: 40rpx;color: #666;height: 40rpx;line-height: 40rpx;}
.content .item .f2 .t2{ font-size: 28rpx;color: #999;height: 50rpx;line-height: 50rpx;}
.content .item .btn{ border-radius:8rpx; padding:3rpx 12rpx;margin-left: 10px;border: 1px #999 solid; text-align:center; font-size:28rpx;color:#333;}
.content .item .btn:nth-child(n+2) {margin-top: 10rpx;}
.popup__options{display: flex;align-items: center;justify-content: flex-start;padding-bottom: 15rpx;}
.popup__options .popup__options_text{width: 120rpx;text-align: right;}
.popup__but{font-size: 14px;color: #007aff;display: table;margin: 30rpx auto 30rpx;}
</style>
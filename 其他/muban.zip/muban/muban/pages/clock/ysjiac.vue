<template>
	<view class="ysjiacpage">
		
	</view>
</template>

<script>
</script>

<style>
</style>
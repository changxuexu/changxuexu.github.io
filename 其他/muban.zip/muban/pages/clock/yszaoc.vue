<template>
	<view class="yszaocpage">
		
		<view class="wrap">
			
			
			<view class="bannerbox">
				<image :src="clock8pic" class="banner"></image>
			</view>
			
			<view class="floorheader flex-y-center">
				<view class="tit">
					<text>早餐饮食</text>
					<text class="titdesc">(可填不吃)</text>
				</view>
			</view>
			
			
			<view class="p-relative border-line-b">
				<input type="text" v-model="ystype" placeholder="请输入" class="ystype"/>
			</view> 
			
			 
			<view class="p-relative border-line-b">
				<picker mode="time" :value="ystime" start="00:00" end="23:59" @change="bindystimeChange">
					<view class="flex item">
						<view class="flex1">饮食时间</view>
						<view class="val">{{ystime}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			
			<view class="p-relative border-line-b" style="padding-top:30rpx;padding-bottom:30rpx;">
				<view>添加饮食图片，最多6张</view>
				<view class="uploadwrap">
					<template v-for="(item,index) in arr_upload">
						<image :src="item" mode="aspectFit" class="pic" :key="index"></image>
					</template>
					<image v-if="!(arr_upload.length >= 6)" @click="uploadhandle" :src="clock7pic" mode="aspectFit" class="pic"></image>
				</view>
			</view>
			
			<view class="floorheader flex-y-center mt15">
				<view class="tit">
					<text>其他数据</text>
					<text class="titdesc">(记录一天的数据)</text>
				</view>
			</view>
			<view class="p-relative border-line-b">
				<picker :range="arr_yundong" :value="yundong_index" @change="bindyundongChange">
					<view class="flex item">
						<view class="flex1">运动类型</view>
						<view class="val">{{yundong_value}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			
			<view class="p-relative border-line-b">
				<picker :value="yinshui_index" :range="arr_yinshui" @change="bindyinshuiChange">
					<view class="flex item">
						<view class="flex1">饮水情况(ML)</view>
						<view class="val">{{yinshui_value}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			
			<view class="footerwrap">
				<view class="fixfoot">提交打卡</view>
			</view>
			
		</view>
	</view>
</template>

<script>
import { chooseImage, uploadFile } from './util.js'
import clock7pic from './images/clock7.png'
import clock8pic from './images/clock8.png'
export default {
	data() {
		return {
			clock7pic,clock8pic,
			arr_yundong:['无', '低强度(慢跑、快走等)', '中强度(跳绳、跳操等)', '高强度(游泳、举重等)'],
			arr_yinshui:[0,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100,2200,2300,2400,2500,2600,2700,2800,2900,3000,3100,3200,3300,3400,3500,3600,3700,3800,3900,4000,4100,4200,4300,4400,4500,4600,4700,4800,4900,5000],
			ystype:'',
			yundong_index:0,
			yundong_value:'无',
			yinshui_index:'',
			yinshui_value:'',
			ystime:'07:00',
			arr_upload:[]
		}
	},
	methods:{
		bindystimeChange(){
			this.ystime = e.detail.value
		},
		bindyundongChange(e){
			let arr_yundong = this.arr_yundong
			this.yundong_index = e.detail.value
			this.yundong_value = arr_yundong[e.detail.value]
		},
		bindyinshuiChange(e){
			let arr_yinshui = this.arr_yinshui
			this.yinshui_index = e.detail.value
			this.yinshui_value = arr_yinshui[e.detail.value]
		},
		uploadhandle(){
			chooseImage().then(res=>{
			  let tempFilePaths = res.tempFilePaths[0];
			  let arr_upload = this.arr_upload
			  if(arr_upload.length>=6){
				  uni.showToast({
					icon:'none',
				  	title: '最多上传6张',
				  	duration: 2000
				  });
				  return
			  }
			  this.arr_upload.push(tempFilePaths)
			  // let options = {
			  //   url: api.upload,
			  //   filepath: tempFilePaths,
			  //   name: 'file',
			  //   token: token
			  // }
			  // uploadFile(options).then(res=>{
			  //   let { code, data, msg } = JSON.parse(res.data)
			  //   if(code == 1){
			  //     userinfo['avatar'] = data['url']
			  //     this.setData({ userinfo})
			  //   }
			  // })
			})
		}
	}
}
</script>

<style>
.yszaocpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
}
.yszaocpage .bannerbox{
	display: flex;
	justify-content: center;
	margin-bottom:50rpx;
}
.yszaocpage .banner{
	width: 700rpx;
	height:136rpx;
}
.yszaocpage .wrap{
	padding:30rpx;
}

.uploadwrap{
	display: flex;
	flex-wrap: wrap;
}
.uploadwrap .pic{
	display:block;
	margin-top:20rpx;
	margin-right:20rpx;
	width:120rpx;
	height:120rpx;
	background-color:#f5f5f5;
}

.footerwrap{
	height:40px;
}
.fixfoot{
	position: fixed;
	left:0;
	right:0;
	bottom:0;
	height:40px;
	line-height:40px;
	background-color: #9A7EE5;
	text-align: center;
	font-size:30rpx;
	color:#ffffff;
}
.yszaocpage .floorheader .tit{
	line-height:32rpx;
	font-size:30rpx;
	font-weight:bold;
	border-left: 8rpx solid #22ADB4;
}
.yszaocpage .floorheader .titdesc{
	font-size:24rpx;
	color:#999999;
}
.yszaocpage .floorheader .tit text{
	padding-left:15rpx;
}

.yszaocpage .p-relative{ position: relative; }
.yszaocpage .border-line-b::after{position: absolute;box-sizing: border-box;content: " ";
	pointer-events: none;top: -50%;right: -50%;bottom: -50%;left: -50%;border: 0 solid #ebedf0;
	-webkit-transform: scale(.5);transform: scale(.5);border-bottom-width: 1px;}

.yszaocpage .arrow {margin-right:4px;position: relative}
.yszaocpage .arrow:after {content:" ";display:inline-block;height:6px;width:6px;border-width:1px 1px 0 0;border-style:solid;border-color:#999999;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-3px; position:absolute;top:50%;right:0;}
.yszaocpage .item{padding: 30rpx 0;}
.yszaocpage .item .val{padding-right: 30rpx;}
.yszaocpage .mt15{ margin-top:30rpx;}
.ystype{
	height:40px;
	line-height:40px;
}
</style>
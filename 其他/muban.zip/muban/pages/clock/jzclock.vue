<template>
	<view class="jzclockpage">
		<view class="wrap">
			<view class="header">剂量记录</view>
			<view v-if="isbuka" class="p-relative border-line-b">
				<picker mode="date" :end="endDate" @change="bindendDateChange">
					<view class="flex item">
						<view class="flex1">补充打卡时间</view>
						<view class="val">{{time ? time:'请选择'}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			<view class="p-relative border-line-b">
				<picker :value="jiliang_index" :range="arr_jiliang" @change="bindjiliangChange">
					<view class="flex item">
						<view class="flex1">本次剂量</view>
						<view class="val">{{jiliang_value}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			
			<view class="p-relative border-line-b">
				<picker :value="daka_index" :range="arr_time" @change="binddakaChange">
					<view class="flex item">
						<view class="flex1">本次剂量</view>
						<view class="val">{{daka_value}}</view>
						<view class="arrow"></view>
					</view>
				</picker>
			</view>
			<view class="footerwrap">
				<view class="fixfoot">提交打卡</view>
			</view>
			
		</view>
	</view>
</template>

<script>
import { dateFormater } from './util.js'
export default {
	data() {
		return {
			endDate:dateFormater('YYYY-MM-DD'),
			arr_jiliang: ['0.06mg', '0.08mg', '0.10mg', '0.12mg', '0.14mg', '0.16mg', '0.18mg', '0.20mg', '0.22mg', '0.24mg', '0.26mg', '0.28mg', '0.30mg'],
			arr_time:['早餐时段', '中餐时段', '晚餐时段', '加餐时段'],
			isbuka:false,
			time:'',
			jiliang_index:0,
			jiliang_value:'0.06mg',
			daka_index:0,
			daka_value:'早餐时段'
		}
	},
	onLoad(options){
		if(options.type == 'buka'){
			this.isbuka = true
		}else{
			this.isbuka = false
		}
		
	},
	methods:{
		bindendDateChange(e){
			this.time = e.detail.value
		},
		bindjiliangChange(e){
			let arr_jiliang = this.arr_jiliang
			this.jiliang_index = e.detail.value
			this.jiliang_value = arr_jiliang[e.detail.value]
		},
		binddakaChange(e){
			let arr_time = this.arr_time
			this.daka_index = e.detail.value
			this.daka_value = arr_time[e.detail.value]
		},
	}
}
</script>

<style>
.jzclockpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
}
.jzclockpage .wrap{
	padding:30rpx;
}
.jzclockpage .header{
	background-color: #9A7EE5;
	font-size:30rpx;
	color:#ffffff;
	text-align: center;
	height:40px;
	line-height:40px;
	width:450rpx;
	margin:0 auto 40rpx auto;
	border-radius:40px;
}
.jzclockpage .p-relative{ position: relative; }
.jzclockpage .border-line-b::after{position: absolute;box-sizing: border-box;content: " ";
	pointer-events: none;top: -50%;right: -50%;bottom: -50%;left: -50%;border: 0 solid #ebedf0;
	-webkit-transform: scale(.5);transform: scale(.5);border-bottom-width: 1px;}

.jzclockpage .arrow {margin-right:4px;position: relative}
.jzclockpage .arrow:after {content:" ";display:inline-block;height:6px;width:6px;border-width:1px 1px 0 0;border-style:solid;border-color:#999999;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-3px; position:absolute;top:50%;right:0;}
.jzclockpage .item{
	padding: 30rpx 0;
}
.jzclockpage .item .val{
	padding-right: 30rpx;
}
.footerwrap{
	height:40px;
}
.fixfoot{
	position: fixed;
	left:0;
	right:0;
	bottom:0;
	height:40px;
	line-height:40px;
	background-color: #9A7EE5;
	text-align: center;
	font-size:30rpx;
	color:#ffffff;
}
</style>
<template>
	<view class="clockidxpage">
		<view class="wrap">
			<view class="floorheader flex-y-center">
				<view class="flex1 tit">
					<text>减重记录</text>
				</view>
				<view @click="gohandle(1)" class="desc">打卡记录>></view>
			</view>
			
			<view @click="gohandle(2)" class="floorjianzhong">
				<image :src="clock1pic" mode="heightFix" class="clock1"></image>
				<view class="tit">减重打卡</view>
			</view>
			
			<view class="floorheader flex-y-center">
				<view class="flex1 tit">
					<text>饮食记录</text>
				</view>
				<view @click="gohandle(3)" class="desc">打卡记录>></view>
			</view>
			
			<view class="floordiet">
				<view @click="gohandle(4)" class="item">
					<image :src="clock2pic" mode="heightFix" class="clockdiet"></image>
					<view class="tit">早餐打卡</view>
				</view>
				<view @click="gohandle(5)" class="item">
					<image :src="clock3pic" mode="heightFix" class="clockdiet"></image>
					<view class="tit">午餐打卡</view>
				</view>
				<view @click="gohandle(6)" class="item">
					<image :src="clock4pic" mode="heightFix" class="clockdiet"></image>
					<view class="tit">晚餐打卡</view>
				</view>
				<view @click="gohandle(7)" class="item">
					<image :src="clock5pic" mode="heightFix" class="clockdiet"></image>
					<view class="tit">加餐打卡</view>
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
import clock1pic from './images/clock1.png'
import clock2pic from './images/clock2.png'
import clock3pic from './images/clock3.png'
import clock4pic from './images/clock4.png'
import clock5pic from './images/clock5.png'
export default {
	data() {
		return {
			clock1pic,clock2pic,clock3pic,clock4pic,clock5pic
		}
	},
	methods:{
		gohandle(type){
			let url = ''
			if(type == 1){
				url = '/pages/clock/jzlist'
			}else if(type == 2){
				url = '/pages/clock/jzclock'
			}else if(type == 3){
				url = '/pages/clock/yslist'
			}else if(type == 4){
				url = '/pages/clock/yszaoc'
			}else if(type == 5){
				url = '/pages/clock/yswuc'
			}else if(type == 6){
				url = '/pages/clock/yswanc'
			}else if(type == 7){
				url = '/pages/clock/ysjiac'
			}
			uni.navigateTo({ url })
		}
	}
}
</script>

<style>
.clockidxpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
}
.clockidxpage .wrap{
	padding:30rpx;
}
.clockidxpage .floorheader .tit{
	line-height:32rpx;
	font-size:30rpx;
	font-weight:bold;
	border-left: 8rpx solid #BCAEE0;
}
.clockidxpage .floorheader .tit text{
	padding-left:15rpx;
}
.clockidxpage .floorheader .desc{
	color:#BCAEE0;
}
.floorjianzhong{
	margin-top:30rpx;
	margin-bottom:40rpx;
	background-color: #23C0D1;
	padding:30rpx;
	border-radius: 10rpx;
	display: flex;
	flex-direction: column;
	align-items: center;
	font-size:30rpx;
}
.floorjianzhong .clock1{
	width:80rpx;
	height:80rpx;
}
.floorjianzhong .tit{
	color:#ffffff;
	margin-top:10rpx;
}
.floordiet{
	display: flex;
	justify-content: space-between;
	flex-wrap: wrap;
}
.floordiet .item{ 
	margin-top:30rpx;
	background-color: #EFF9FA;
	padding:30rpx 0;
	border-radius: 10rpx;
	display: flex;
	flex-direction: column;
	align-items: center;
	font-size:30rpx;
	width:calc(50% - 15rpx);
	overflow: hidden;
}
.floordiet .item .clockdiet{ 
	height:44rpx;
	max-width: 50rpx;
}
.floordiet .item .tit{ 
	color:#333333;
	margin-top:10rpx;
}
</style>
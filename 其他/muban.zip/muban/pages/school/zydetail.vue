<template>
	<view class="xydetailwrap">
		<image :src="xytoppic" class="xytoppic"></image>
		<view class="contentbox">
			<view class="content">
				<view class="topwrap">
					<view class="base">
						<view class="name">文科试验班类</view>
						<button open-type="share">
							<image :src="shareffpic" class="shareffpic"></image>
						</button>
						<view class="btn">关注</view>
					</view>
					<view class="desc">描述信息</view>
				</view>
				<view class="vtabswrap">
					<vtabs v-model="current" :tabs="tabs" :scroll="true" lineScale="0.4" @change="changeTab" activeColor="#527739" lineColor="#527739" bgColor="#ffffff" height="100rpx" :fixed="false"></vtabs>
				</view>
				<scroll-view scroll-y="true" scroll-into-view="{{toView}}" scroll-with-animation="true" class="scroll-Y">
					
					<view id="floor1" class="baseinfo">
						<view class="item">
							<view class="tit">招生类型：</view>
							<view class="des">普通类</view>
						</view>
						<view class="item">
							<view class="tit">科目类别：</view>
							<view class="des">文史</view>
						</view>
						<view class="item">
							<view class="tit">选科要求：</view>
							<view class="des">文科</view>
						</view>
						<view class="item">
							<view class="tit">录取批次：</view>
							<view class="des">1</view>
						</view>
						<view class="item">
							<view class="tit">学习年限：</view>
							<view class="des">4年</view>
						</view>
						<view class="item">
							<view class="tit">每年学费：</view>
							<view class="des">2000元</view>
						</view>
					</view>
					
					<view id="floor2" class="zhuanyejieshao">
						<view class="name">招生计划和历年分数</view>
						<view class="miaoshu">2023招生计划:15人</view>
						<view class="miaoshu">历年分数</view>
						<view class="miaoshu">2023年 15人 最高:627分 最低:617分2023年</view>
						<view class="miaoshu">2022年最高:609分最低:602分</view>
					</view>
					
					<view id="floor3" class="zhuanyejieshao">
						<view class="name">培养学院和分流专业</view>
						<template v-for="(item,idx) in 2">
							<view class="itemzhuanye" :key="idx">
								<view class="flex-y-center">
									<view class="dot"></view>
									<view class="flex1 tit">人文学院</view>
									<view class="intro arrow">院系介绍</view>
								</view>
								<view class="labelwrap">
									<view class="type active">建筑学</view>
									<view class="type">城乡规划</view>
									<view class="type">风录园林</view>
								</view>
							</view>
						</template>
					</view>
					
					<view id="floor4" class="zhuanyejieshao">
						<view class="name">专业(类)介绍</view>
						<view class="miaoshu">文科试验班类</view>
					</view>
					
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
import xytoppic from './images/xytop.png'
import shareffpic from './images/shareff.png'
import vtabs from './components/v-tabs/v-tabs.vue';
export default {
	components: {
	    vtabs
	},
	data() {
		return {
			xytoppic,shareffpic,
			current: 0,
			tabs: ['基础信息', '招生计划和历年分数', '培养学院和分流专业', '专业(类)介绍'],
			tabIds: ['floor1', 'floor2', 'floor3','floor4'],
			currentId:'',
			videoinfo:{
				name: '你相信有灵魂伴侣吗',
				img: 'https://t7.baidu.com/it/u=1951548898,3927145&fm=193&f=GIF',
				video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=5544&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
				videoId: '1'
			},
			toView:''
		}
	},
	methods: {
		changeTab(e){
			let tabIds = this.tabIds
			this.toView = tabIds[e]
		}
	}
}
</script>

<style lang="scss" scoped>
.xydetailwrap{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	// background-color:#F3EFCA;
	position: relative;
	// overflow: hidden;
	.xytoppic{
		width:100%;
		height:270rpx;
	}
	
	/deep/ .v-tabs__container{
		border-radius: 10px 10px 0 0;
	}
	
	/deep/ .v-tabs__container-item{
		font-size:32rpx !important;
	}
	
	.contentbox{
		// background-color: red;
		position: absolute;
		left:0;
		right:0;
		top:0;
		bottom:0;
		.content{
			width:100%;
			height:100%;
			display: flex;
			flex-direction: column;
		}
		.scroll-Y{
			flex:1;
			overflow-y: auto;
		}
		
		.itemzhuanye{
			background-color: #ffffff;
			padding:30rpx 10rpx;
			border-bottom:1px solid rgba(0, 0, 0, 0.1);
			&:last-child{
				border-bottom:0
			}
			.dot{
				width:15rpx;
				height:15rpx;
				border-radius:100%;
				background-color:#4B7C2A;
				margin-right:12rpx;
			}
			.tit{
				font-size:32rpx;
				font-weight:bold;
			}
			.intro{
				position: relative;
				padding-right:20rpx;
			}
			.arrow {position: relative}
			.arrow:after {content:" ";display:inline-block;height:4px;width:4px;border-width:1px 1px 0 0;border-style:solid;border-color:#666666;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-2px; position:absolute;top:50%;right:0;}
			
			.labelwrap{
				display: flex;
				flex-wrap: wrap;
				.type{
					margin-right:20rpx;
					border:1px solid #8F8F8F;
					font-size:28rpx;
					height:55rpx;
					line-height:55rpx;
					border-radius:55rpx;
					padding-left:30rpx;
					padding-right:20rpx;
					margin-top:20rpx;
				}
				.active{
					border-color:#4C7C2B;
					background-color: #4C7C2B;
					color:#ffffff;
				}
			}
		}
		
		.zhuanyejieshao{
			margin-top:20rpx;
			background-color: #ffffff;
			padding:30rpx 20rpx 30rpx 20rpx;
			.name{
				font-size:32rpx;
				font-weight:bold;
			}
			.miaoshu{
				color:#8C8C8C;
				font-size:32rpx;
				margin-top:15rpx;
			}
		}
		.baseinfo{
			background-color: #ffffff;
			padding:10rpx 20rpx 30rpx 20rpx;
			.item{
				display:flex;
				flex-wrap:wrap;
				font-size:32rpx;
				margin-top:15rpx;
				.tit{
					color:#8C8C8C;
				}
				.btn{
					border-radius:30rpx;
					padding:10rpx 25rpx;
					background-color:#F6F6F6;
					font-size:30rpx;
					.arrow{
						padding-left:20rpx;
					}
				}
				.des{
					color:#333333;
				}
			}
		}
		.arrow {position: relative}
		.arrow:after {content:" ";display:inline-block;height:4px;width:4px;border-width:1px 1px 0 0;border-style:solid;border-color:#666666;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-2px; position:absolute;top:50%;right:0;}
		.topwrap{
			padding-left:30rpx;
			padding-right:30rpx;
			padding-top:100rpx;
			.base{
				display: flex;
				align-items: center;
				.name{
					flex:1;
					font-size:40rpx;
					font-weight:bold;
					color:#ffffff;
				}
				.shareffpic{
					width:40rpx;
					height:40rpx;
					display: block;
				}
				.btn{
					background-color: #ffffff;
					color:#567249;
					height:45rpx;
					line-height:45rpx;
					border-radius:45rpx;
					font-size:24rpx;
					padding-left: 15rpx;
					padding-right: 15rpx;
					margin-left:30rpx;
				}
			}
			.desc{
				color:#ffffff;
				margin-top:15rpx;
				margin-bottom:15rpx;
				display:-webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp:2;
				overflow: hidden;
			}
		}
	}
}
</style>
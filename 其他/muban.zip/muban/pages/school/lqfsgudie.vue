<template>
	<view class="zsgudiepage">
		
		<view class="floorwrap">
			<view class="title">年份</view>
			<view class="info">
				<view 
					@click="yearhandle(index)" 
					:class="['item', {'active':index == year_index}]" 
					v-for="(item,index) in year" :key="index">{{item}}</view>
			</view>
		</view>
		
		<view class="floorwrap">
			<view class="title">地区</view>
			<view class="info">
				<view 
					@click="areahandle(index)" 
					:class="['item', {'active':index == area_index}]"
					v-for="(item,index) in area" :key="index">{{item}}</view>
			</view>
		</view>
		
		<view class="floorwrap">
			<view class="title">科类</view>
			<view class="info">
				<view
					@click="typehandle(index)" 
					:class="['item', {'active':index == type_index}]"
					v-for="(item,index) in type" :key="index">{{item}}</view>
			</view>
		</view>
		
		<view class="tablewrap">
			<!-- <view class="title">专业线 <text class="des">（向左/向下滑动查看更多）</text></view> -->
			<ws-table :config="config" :table-data="tableData" :showSummary="false" :showTableFilter="false"></ws-table>
		</view>
		
	</view>
</template>

<script>
import WsTable from "./components/ws-table/index.vue"
export default {
	components: {WsTable},
	data() {
		return {
			year:['2023','2022','2021','2020'],
			year_index:0,
			area:['湖北省','陕西省','河南省','贵州省','云南省','宁夏回族自治区'],
			area_index:0,
			type:['历史', '物理', '艺术'],
			type_index:0,
			
			config: [
				{ label: '专业名称', key: 'pici', width: 200 },
				{ label: '计划类别', key: 'zyname', width: 400 },
				{ label: '最高分', key: 'shenkong', width: 200 },
				{ label: '最低分', key: 'zuidifen', width: 200 }
			],
			tableData: [
				{ pici: '金融学', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  },
				{ pici: '能源经济', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  },
				{ pici: '能源经济', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  },				
				{ pici: '能源经济', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  },				
				{ pici: '能源经济', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  },				
				{ pici: '能源经济', zyname: '普通类(C13001组)', shenkong:558, zuidifen:555  }			
			]
		}
	},
	methods: {
		yearhandle(index){
			this.year_index = index
		},
		areahandle(index){
			this.area_index = index
		},
		typehandle(index){
			this.type_index = index
		}
	}
}
</script>

<style lang="scss" scoped>
.zsgudiepage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
	overflow: hidden;
	.floorwrap{
		padding-left:30rpx;
		padding-right:30rpx;
		display: flex;
		margin-top:30rpx;
		.title{
			flex-shrink:0;
			font-size:32rpx;
			font-weight:bold;
			height:60rpx;
			line-height:60rpx;
			margin-right:30rpx;
		}
		.info{
			display: flex;
			flex-wrap: wrap;
			.item{
				background-color: #F0F0F0;
				height:60rpx;
				line-height:60rpx;
				border-radius:60rpx;
				padding-left:30rpx;
				padding-right:30rpx;
				margin-right:20rpx;
				margin-bottom:20rpx;
				font-size:28rpx;
			}
			.active{
				background-color: #1267BB;
				color: #ffffff;
			}
		}
	}
	.tablewrap{
		margin:30rpx;
		.title{
			font-size:32rpx;
			font-weight:bold;
			margin-bottom:20rpx;
			.des{
				color:#999999;
			}
		}
		
		/deep/ .header-bg{
			background-color: #1267BB !important;
			color: #ffffff;
		}
	}
}
</style>
<template>
	<view class="xydetailwrap">
		<image :src="xytoppic" class="xytoppic"></image>
		<view class="contentbox">
			<view class="content">
				<view class="topwrap">
					<view class="base">
						<view class="name">建筑学院</view>
						<button open-type="share">
							<image :src="shareffpic" class="shareffpic"></image>
						</button>
						<view class="btn">关注</view>
					</view>
					<view class="desc">具体招生专业，最终以考试院公布为准。</view>
				</view>
				<view class="vtabswrap">
					<vtabs v-model="current" :tabs="tabs" :scroll="true" lineScale="0.4" @change="changeTab" activeColor="#527739" lineColor="#527739" bgColor="#ffffff" height="100rpx" :fixed="false"></vtabs>
				</view>
				<scroll-view scroll-y="true" scroll-into-view="{{toView}}" scroll-with-animation="true" class="scroll-Y">
					<template v-if="current == 0">
						<view class="xueyuanintro">
							<view class="des">
								建筑学院现有教职工200余人，师资力量雄厚，拥有院士5名、全国工程勘察设计大师4人、国家级高层次人才5人、国家杰出青年基金获得者2人、教育部“新世纪优秀人才支持计划"人选5人、江苏省设计大师14人、入选江苏省人才计划20余人。学院现有教授45名、副教授66名，其中博士生导师53名、硕士生导师130名。专业教师均有出国学习、进修、工作、考察交流的学术背景，这支以院士为核心、中青年教授为骨干的教师队伍，学术活跃，勇于探索，团结奋斗，长期耕耘在本科教学第一线，为学院的建设和发展奠定了坚实的基础。
							</view>
							<image :src="xytoppic" mode="widthFix" class="pic"></image>
						</view>
					</template>
					
					<template v-if="current == 1">
						<view v-for="(item,index) in 5" :key="index" class="zhuanyeitem">
							<view class="header">
								<view class="name">风景园林</view>
								<view class="tag">设为意向</view>
							</view>
							<view class="content">
								<view class="item">
									<view class="tit">招生专业(类)：</view>
									<view class="des des4C7D2B">建筑类></view>
								</view>
								<view class="flex-y-center">
									<view class="item flex1">
										<view class="tit">招生类型：</view>
										<view class="des">普通类</view>
									</view>
									<view class="item flex1">
										<view class="tit">选科要求：</view>
										<view class="des">理科</view>
									</view>
								</view>
							</view>
						</view>
					</template>
					
					<view v-if="current == 2" class="zhuanyejieshao">
						<view class="videobox">
							<video v-if="currentId == videoinfo.videoId" style="width:100%;height: 390rpx; display: block;" autoplay="true" :id="'video'+videoinfo.videoId" :src="videoinfo.video"></video>
							<view @click="play" v-else>
								<image :src="videoinfo.img" style="width:100%;height:390rpx;display: block;"></image>
								<view class="block">
									<view class="sanjia"></view>
								</view>
							</view>
						</view>
						<view class="videoname">
							{{videoinfo.name}}
						</view>
					</view>
					
					<template v-if="current == 3">
						<view v-for="(item,index) in 10" :key="index" class="zixunitem">
							<view class="title">建筑学院2022届毕业生去向报告</view>
							<view class="time">2023-05-23 21:32 阅读41</view>
						</view>
					</template>
					
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
import xytoppic from './images/xytop.png'
import shareffpic from './images/shareff.png'
import vtabs from './components/v-tabs/v-tabs.vue';
import readmore from './components/readmore/readmore'
export default {
	components: {
	    vtabs,readmore
	},
	data() {
		return {
			xytoppic,shareffpic,
			current: 0,
			tabs: ['学院概况', '分流专业', '宣传视频', '资讯动态'],
			currentId:'',
			videoinfo:{
				name: '建筑学院',
				img: 'https://t7.baidu.com/it/u=1951548898,3927145&fm=193&f=GIF',
				video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=5544&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
				videoId: '1'
			}
		}
	},
	methods: {
		play(){
			let videoinfo = this.videoinfo
			this.currentId = videoinfo['videoId']
		}
	}
}
</script>

<style lang="scss" scoped>
.xydetailwrap{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	// background-color:#F3EFCA;
	position: relative;
	// overflow: hidden;
	.xytoppic{
		width:100%;
		height:270rpx;
	}
	
	.zhuanyeitem{
		border:1px solid #4C7D2B;
		background-color: #ffffff;
		margin:30rpx;
		border-radius:5px;
		overflow: hidden;
		.header{
			background-color: #4C7D2B;
			display: flex;
			align-items: center;
			padding:20rpx;
			.name{
				color:#ffffff;
				font-size:34rpx;
				font-weight:bold;
			}
			.tag{
				border:1px solid #ffffff;
				font-size:20rpx;
				color:#ffffff;
				line-height:40rpx;
				height:40rpx;
				border-radius: 40rpx;
				padding-left:15rpx;
				padding-right:15rpx;
				margin-left:20rpx;
			}
		}
		.content{
			padding:30rpx;
			.item{
				display:flex;
				flex-wrap:wrap;
				font-size:32rpx;
				margin-bottom:15rpx;
				.tit{
					color:#8C8C8C;
				}
				.btn{
					border-radius:30rpx;
					padding:10rpx 25rpx;
					background-color:#F6F6F6;
					font-size:30rpx;
					.arrow{
						padding-left:20rpx;
					}
				}
				.des{
					color:#333333;
				}
				.des4C7D2B{
					color:#4C7D2B;
				}
			}
		}
	}
	
	.xueyuanintro{
		background-color: #ffffff;
		padding:30rpx;
		overflow: hidden;
		.des{
			font-size:32rpx;
			color:#333333;
			line-height:50rpx;
			margin-bottom:30rpx;
		}
		.pic{
			display:block;
			max-width:100%;
			margin-bottom:30rpx;
		}
	}
	
	/deep/ .v-tabs__container{
		border-radius: 10px 10px 0 0;
	}
	
	/deep/ .v-tabs__container-item{
		font-size:32rpx !important;
	}
	
	.zixunitem{
		background-color:#ffffff;
		margin-top:20rpx;
		padding:30rpx;
		.title{
			font-size:32rpx;
			font-weight:bold;
		}
		.time{
			color:#999999;
			margin-top:10rpx;
		}
	}
	
	.contentbox{
		// background-color: red;
		position: absolute;
		left:0;
		right:0;
		top:0;
		bottom:0;
		.content{
			width:100%;
			height:100%;
			display: flex;
			flex-direction: column;
		}
		.scroll-Y{
			flex:1;
			overflow-y: auto;
		}
		
		.videobox {
			overflow: hidden;
			position: relative;
			overflow: hidden;
			border-radius: 8px 8px 0 0;
			margin-top: 20rpx;
			.block {
				position: absolute;
				width: 100%;
				height: 390rpx;
				background-color: rgba($color: #000000, $alpha: .3);
				left: 0;
				top: 0;
				display: flex;
				justify-content: center;
				align-items: center;
		
				.sanjia {
					width: 0;
					height: 0;
					border-top: 12px solid transparent;
					border-left: 17px solid #FFFFFF;
					border-bottom: 12px solid transparent;
				}
			}
		}
		.videoname{
			border-radius: 0 0 10px 10px;
			background-color: #FFFFFF;
			padding:10px;
			font-size:32rpx;
			color:#333333;
			font-weight:bold;
		}
		
		.zhuanyejieshao{
			margin-top:20rpx;
			background-color: #ffffff;
			padding:30rpx 20rpx 30rpx 20rpx;
			.name{
				font-size:32rpx;
				font-weight:bold;
			}
		}
		.baseinfo{
			background-color: #ffffff;
			padding:10rpx 20rpx 30rpx 20rpx;
			.item{
				display:flex;
				flex-wrap:wrap;
				font-size:32rpx;
				margin-top:15rpx;
				.tit{
					color:#8C8C8C;
				}
				.btn{
					border-radius:30rpx;
					padding:10rpx 25rpx;
					background-color:#F6F6F6;
					font-size:30rpx;
					.arrow{
						padding-left:20rpx;
					}
				}
				.des{
					color:#333333;
				}
			}
		}
		.arrow {position: relative}
		.arrow:after {content:" ";display:inline-block;height:4px;width:4px;border-width:1px 1px 0 0;border-style:solid;border-color:#666666;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-2px; position:absolute;top:50%;right:0;}
		.topwrap{
			padding-left:30rpx;
			padding-right:30rpx;
			padding-top:100rpx;
			.base{
				display: flex;
				align-items: center;
				.name{
					flex:1;
					font-size:40rpx;
					font-weight:bold;
					color:#ffffff;
				}
				.shareffpic{
					width:40rpx;
					height:40rpx;
					display: block;
				}
				.btn{
					background-color: #ffffff;
					color:#567249;
					height:45rpx;
					line-height:45rpx;
					border-radius:45rpx;
					font-size:24rpx;
					padding-left: 15rpx;
					padding-right: 15rpx;
					margin-left:30rpx;
				}
			}
			.desc{
				color:#ffffff;
				margin-top:15rpx;
				margin-bottom:15rpx;
				display:-webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp:2;
				overflow: hidden;
			}
		}
	}
}
</style>
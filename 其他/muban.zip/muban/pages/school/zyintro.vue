<template>
	<view class="xydetailwrap">
		<image :src="xytoppic" class="xytoppic"></image>
		<view class="contentbox">
			<view class="content">
				<view class="topwrap">
					<view class="base">
						<view class="name">艺术史论</view>
						<button open-type="share">
							<image :src="shareffpic" class="shareffpic"></image>
						</button>
						<view class="btn">设为意向</view>
					</view>
					<view class="desc">描述信息</view>
				</view>
				<view class="vtabswrap">
					<vtabs v-model="current" :tabs="tabs" :scroll="true" lineScale="0.4" @change="changeTab" activeColor="#527739" lineColor="#527739" bgColor="#ffffff" height="100rpx" :fixed="false"></vtabs>
				</view>
				<scroll-view scroll-y="true" scroll-into-view="{{toView}}" scroll-with-animation="true" class="scroll-Y">
					<view id="basefloor" class="baseinfo">
						<view class="item">
							<view class="tit">培养院系：</view>
							<view class="btn">艺术学院<text class="arrow"></text></view>
						</view>
						<view class="item">
							<view class="tit">招生专业：</view>
							<view class="btn">文科试验班类<text class="arrow"></text></view>
						</view>
						<view class="item">
							<view class="tit">招生类型：</view>
							<view class="des">普通类</view>
						</view>
						<view class="item">
							<view class="tit">选科要求：</view>
							<view class="des">首选历史，再选不限</view>
						</view>
					</view>
					
					<view id="zhuanyefloor" class="zhuanyejieshao">
						<view class="name">专业介绍</view>
						<readmore hideLineNum="8" showHeight="100">
							培养目标:本专业培养具备中外艺术史与艺术理论等方面的基本知识，能在各级文化部门、美术馆、博物馆，以及报纸杂志、广播电视、出版机构、文化公司等单位工作的复合型人才，其中相 当数量的毕业生将通过研究生学习之后，进入高等院校、职业学院和中学担任艺术课程教师。培养要求:本专业学生主要学习中外艺术学理论和中外艺术史方面的基本理论和基本知识，较为全
							本专业培养具备中外艺术史与艺术理论等方面的基本知识本专业培养具备中外艺术史与艺术理论等方面的基本知识本专业培养具备中外艺术史与艺术理论等方面的基本知识
						</readmore>
					</view>
					
					<view id="videofloor" class="zhuanyejieshao">
						<view class="name">专业视频</view>
						<view class="videobox">
							<video v-if="currentId == videoinfo.videoId" style="width:100%;height: 390rpx; display: block;" autoplay="true" :id="'video'+videoinfo.videoId" :src="videoinfo.video"></video>
							<view @click="play" v-else>
								<image :src="videoinfo.img" style="width:100%;height:390rpx;display: block;"></image>
								<view class="block">
									<view class="sanjia"></view>
								</view>
							</view>
						</view>
						<view class="videoname">
							{{videoinfo.name}}
						</view>
					</view>
					
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
import xytoppic from './images/xytop.png'
import shareffpic from './images/shareff.png'
import vtabs from './components/v-tabs/v-tabs.vue';
import readmore from './components/readmore/readmore'
export default {
	components: {
	    vtabs,readmore
	},
	data() {
		return {
			xytoppic,shareffpic,
			current: 0,
			tabs: ['基础信息', '专业介绍', '专业视频'],
			tabIds: ['basefloor', 'zhuanyefloor', 'videofloor'],
			currentId:'',
			videoinfo:{
				name: '你相信有灵魂伴侣吗',
				img: 'https://t7.baidu.com/it/u=1951548898,3927145&fm=193&f=GIF',
				video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=5544&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
				videoId: '1'
			},
			toView:''
		}
	},
	methods: {
		play(){
			let videoinfo = this.videoinfo
			this.currentId = videoinfo['videoId']
		},
		changeTab(e){
			let tabIds = this.tabIds
			this.toView = tabIds[e]
		}
	}
}
</script>

<style lang="scss" scoped>
.xydetailwrap{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	// background-color:#F3EFCA;
	position: relative;
	// overflow: hidden;
	.xytoppic{
		width:100%;
		height:270rpx;
	}
	
	/deep/ .v-tabs__container{
		border-radius: 10px 10px 0 0;
	}
	
	/deep/ .v-tabs__container-item{
		font-size:32rpx !important;
	}
	
	.contentbox{
		// background-color: red;
		position: absolute;
		left:0;
		right:0;
		top:0;
		bottom:0;
		.content{
			width:100%;
			height:100%;
			display: flex;
			flex-direction: column;
		}
		.scroll-Y{
			flex:1;
			overflow-y: auto;
		}
		
		.videobox {
			overflow: hidden;
			position: relative;
			overflow: hidden;
			border-radius: 8px 8px 0 0;
			margin-top: 20rpx;
			.block {
				position: absolute;
				width: 100%;
				height: 390rpx;
				background-color: rgba($color: #000000, $alpha: .3);
				left: 0;
				top: 0;
				display: flex;
				justify-content: center;
				align-items: center;
		
				.sanjia {
					width: 0;
					height: 0;
					border-top: 12px solid transparent;
					border-left: 17px solid #FFFFFF;
					border-bottom: 12px solid transparent;
				}
			}
		}
		.videoname{
			border-radius: 0 0 10px 10px;
			background-color: #FFFFFF;
			padding:10px;
			font-size:32rpx;
			color:#333333;
			font-weight:bold;
		}
		
		.zhuanyejieshao{
			margin-top:20rpx;
			background-color: #ffffff;
			padding:30rpx 20rpx 30rpx 20rpx;
			.name{
				font-size:32rpx;
				font-weight:bold;
			}
		}
		.baseinfo{
			background-color: #ffffff;
			padding:10rpx 20rpx 30rpx 20rpx;
			.item{
				display:flex;
				flex-wrap:wrap;
				font-size:32rpx;
				margin-top:15rpx;
				.tit{
					color:#8C8C8C;
				}
				.btn{
					border-radius:30rpx;
					padding:10rpx 25rpx;
					background-color:#F6F6F6;
					font-size:30rpx;
					.arrow{
						padding-left:20rpx;
					}
				}
				.des{
					color:#333333;
				}
			}
		}
		.arrow {position: relative}
		.arrow:after {content:" ";display:inline-block;height:4px;width:4px;border-width:1px 1px 0 0;border-style:solid;border-color:#666666;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-2px; position:absolute;top:50%;right:0;}
		.topwrap{
			padding-left:30rpx;
			padding-right:30rpx;
			padding-top:100rpx;
			.base{
				display: flex;
				align-items: center;
				.name{
					flex:1;
					font-size:40rpx;
					font-weight:bold;
					color:#ffffff;
				}
				.shareffpic{
					width:40rpx;
					height:40rpx;
					display: block;
				}
				.btn{
					background-color: #ffffff;
					color:#567249;
					height:45rpx;
					line-height:45rpx;
					border-radius:45rpx;
					font-size:24rpx;
					padding-left: 15rpx;
					padding-right: 15rpx;
					margin-left:30rpx;
				}
			}
			.desc{
				color:#ffffff;
				margin-top:15rpx;
				margin-bottom:15rpx;
				display:-webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp:2;
				overflow: hidden;
			}
		}
	}
}
</style>
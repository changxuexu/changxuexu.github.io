<template>
	<view class="tztargetpage" @click="closePopover">
		<view class="boxpage">
			<!-- <view class="p-relative">
				<image :src="tbgpic" class="tbgpic"></image>
				<view class="tbgpictitle">我的体重管理目标</view>
			</view> -->
			<view class="boxpagecontent">
				<!-- <view class="header">
					<image :src="homea3pic" class="pic"></image>
					<view class="tit">我的目标体重</view>
					<image :src="homea3pic" class="pic"></image>
				</view> 
				
				<view class="data">91.2 <text>KG</text></view>
				
				-->
				<view class="otherdata">
					<view class="item">
						<view class="num"><text>7</text>天</view>
						<view class="name">目标天数</view>
					</view>
					<view class="line"></view>
					<view class="item">
						<view class="num"><text>30.7</text>KG</view>
						<view class="name">减掉重量</view>
					</view>
					<view class="line"></view>
					<view class="item">
						<view class="num"><text>0</text>%</view>
						<zbpopover placement="bottom-end" ref="Popover" class="item-popover">
							<view class="name flex-y-center">
								达标率
								<image :src="tippic" class="tippic"></image>
							</view>
							<view slot="content">
								<view class="dabiaotxt">
									达标率=减重KG/减掉KG
								</view>
							</view>
						</zbpopover>
					</view>
				</view>
				
				<!-- <view class="btnmubiao">设置新目标</view>
				<view class="mubiaoheshi">根据您的身高、性别、年龄得出您的理想体重为31.5公斤</view> -->
				
			</view>
		</view>
		
	</view>
</template>

<script>
import zbpopover from './components/Popover/Popover'
import homea3pic from './images/homea3.png';
import tbgpic from './images/tbg.png';
import tippic from './images/tip.png';
export default {
	components: {
	  zbpopover
	},
	data() {
		return {
			homea3pic,tbgpic,tippic,
			
		};
	},
	onShow(){
		
	},
	methods: {
		closePopover() {
			this.$refs.Popover.close()
		},
	}
};
</script>

<style lang="scss" scoped>
.tztargetpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color: #9A7EE5;
	.p-relative{
		position: relative;
	}
	.boxpagecontent{
		background-color: #ffffff;
		border-radius: 0 0 10rpx 10rpx;
		overflow: hidden;
		/* #ifdef MP */
		min-height: calc(100vh - 202rpx);
		/* #endif */
		/* #ifdef H5 */
		min-height: calc(100vh - 290rpx);
		/* #endif */
		.btnmubiao{
			height: 36px;
			line-height:36px;
			border-radius:36px;
			background-color: #9A7EE5;
			border:1px solid #9A7EE5;
			text-align: center;
			color: #ffffff;
			font-size:30rpx;
			margin: 30rpx 30rpx 0 30rpx;
		}
		.mubiaoheshi{
			color:#999999;
			font-size:24rpx;
			text-align: center;
			margin-top:15rpx;
		}
		.otherdata{
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding-left:30rpx;
			padding-right:30rpx;
			.line{
				width:1rpx;
				height:30rpx;
				background-color: #E2E2E2;
			}
			.item{
				text-align: center;
				.num{
					color:#333333;
					text{
						color:red;
					}
				}
				.name{
					color: #92938D;
				}
				.dabiaotxt{
					padding: 20px;
					width: 400rpx;
				}
				.tippic{
					width:28rpx;
					height: 28rpx;
					margin-left:10rpx;
				}
			}
		}
		.data{
			text-align: center;
			font-size: 50rpx;
			color: #9A7EE5;
			text{
				font-size: 24rpx;
			}
		}
		.header{
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top: 10rpx;
			margin-bottom: 30rpx;
			.pic{
				width: 36rpx;
				height: 24rpx;
			}
			.tit{
				color: #333;
				font-size: 30rpx;
				margin-left:10rpx;
				margin-right: 10rpx;
			}
		}
	}
	.boxpage{
		padding:30rpx;
		.tbgpic{
			width:690rpx;
			height:142rpx;
			display: block;
		}
		.tbgpictitle{
			position: absolute;
			left:0;
			right:0;
			top: 40rpx;
			text-align: center;
			font-size:34rpx;
			color: #9A7EE5;
			font-weight:500;
		}
	}
}
</style>
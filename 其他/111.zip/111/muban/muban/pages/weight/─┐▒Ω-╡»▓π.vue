<template>
	<view class="tztargetpage">
		<liupopup type="center" ref="popup">
			<view class="popupcontent">
				
				<view class="step1wrap">
					<view class="header">
						<image :src="homea3pic" class="pic"></image>
						<view class="tit">我的目标</view>
						<image :src="homea3pic" class="pic"></image>
					</view>
					<view class="tip">您的上一个目标还没有结束哦!</view>
					<view class="btn btnselect">开始一个新的目标</view>
					<view class="btn">继续上一个目标</view>
					<view class="des">2024-05-16 08-56:28 记录您的体重为:61.4KG</view> 
				</view> 
				
				<!-- <view class="step2wrap">
					<view class="header">
						<image :src="homea3pic" class="pic"></image>
						<view class="tit">初始体重设置</view>
						<image :src="homea3pic" class="pic"></image>
					</view>
					<view class="tip">请输入您目前的体重哈!</view>
					<view class="weightscale">
						<view class='scale-value'>{{ horizontaPointVal }}KG</view>
						<vue-scale 
							key="2"
						   :min="20"
						   :max="220"
						   :int="false"
						   :single="10"
						   :h="40"
						   :active="36.1"
						   :styles="styles"
						   @value="horizontaPointMethods"/> 
					</view>
					<view class="des">2024-05-16 08-56:28 记录您的体重为:61.4KG</view> 
				</view> -->
				
				<!-- <view class="step3wrap">
					<view class="header">
						<image :src="homea3pic" class="pic"></image>
						<view class="tit">目标体重设置</view>
						<image :src="homea3pic" class="pic"></image>
					</view>
					<view class="tip">请输入您期望的目标体重哈!</view>
					<view class="weightscale">
						<view class='scale-value'>{{ horizontaPointVal3 }}KG</view>
						<vue-scale 
							key="3"
						   :min="20"
						   :max="220"
						   :int="false"
						   :single="10"
						   :h="40"
						   :active="36.1"
						   :styles="styles"
						   @value="horizontaPointMethods3"/> 
					</view>
					<view class="des">2024-05-16 08-56:28 记录您的体重为:61.4KG</view> 
				</view> -->
				
				<!-- <view class="step4wrap">
					<view class="header">
						<image :src="homea3pic" class="pic"></image>
						<view class="tit">生成我的目标</view>
						<image :src="homea3pic" class="pic"></image>
					</view>
					<view class="tip">我们已经为您记录好了数据~</view>
					<view class="data">
						<view class="num">22</view>
						<view class="unit">当前体重(KG)</view>
					</view>
					<view class="data data2">
						<view class="num">49.3</view>
						<view class="unit">目标体重(KG)</view>
					</view>
				</view> -->
				
				<!-- <view class="step5wrap">
					<view class="header">
						<image :src="homea3pic" class="pic"></image>
						<view class="tit">预计达成时间</view>
						<image :src="homea3pic" class="pic"></image>
					</view>
					<view class="tip">我们已经为您记录好了数据~</view>
					<view class="weightscale">
						<view class='scale-value'>{{ horizontaPointVal5 }}天</view>
						<vue-scale 
							key="5"
						   :min="1"
						   :max="365"
						   :int="true"
						   :single="10"
						   :h="40"
						   :active="7"
						   :styles="styles"
						   @value="horizontaPointMethods5"/> 
					</view>
					<view class="des c9A7EE5">耗时{{ horizontaPointVal5 }}天,减重-27.3KG，平均每天减重-3.9KG</view> 
				</view> 
				-->
				
				<view class="operate">
					<view class="back">返回</view>
					<view class="next">下一步/完成</view>
				</view>
			</view>
		</liupopup>
	</view>
</template>

<script>
import liupopup from './components/liu-popup/liu-popup'
import vueScale from './components/vueScale/index.vue';
import homea3pic from './images/homea3.png';
export default {
	components: {
	  liupopup,vueScale
	},
	data() {
		return {
			homea3pic,
			styles: {
				line: '#BEBEBE',
				bginner: '#fbfbfb',
				bgoutside: '#ffffff',
				font: '#404040',
				fontColor: '#404040',
				fontSize: 14,
				lineSelect: '#C74D41',
			},
			horizontaPointVal: '',
			horizontaPointVal3:'',
			horizontaPointVal5:''
		};
	},
	onShow(){
		this.$refs['popup'].open();
	},
	methods: {
		horizontaPointMethods(msg) {
			this.horizontaPointVal = msg;
		},
		horizontaPointMethods3(msg){
			this.horizontaPointVal3 = msg;
		},
		horizontaPointMethods5(msg){
			this.horizontaPointVal5 = msg;
		}
	}
};
</script>

<style lang="scss" scoped>
// .baogaodetailpage{
// 	/* #ifdef MP */
// 	min-height: 100vh;
// 	/* #endif */
// 	/* #ifdef H5 */
// 	min-height: calc(100vh - 44px);
// 	/* #endif */
// 	background-color:#ffffff;
// }
.tztargetpage{
	.popupcontent{
		width:650rpx;
		padding:30rpx 30rpx 50rpx 30rpx;
		.step4wrap{
			.data{
				text-align: center;
				.num{
					font-size: 65rpx;
					font-family: monospace;
					font-weight: bold;
				}
				.unit{
					color: #5E6860;
				}
			}
			.data2{
				margin-top: 30rpx;
				.num{
					color: #9A7EE5;
				}
				.unit{
					color: #9A7EE5;
				}
			}
		}
		.scale-value{
			text-align: center;
			color: #C74D41;
			font-size:54rpx;
			margin-top:30rpx;
			margin-bottom:30rpx;
		}
		.operate{
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top:80rpx;
			.back{
				height: 36px;
				line-height:36px;
				border-radius:36px;
				// background-color: #9A7EE5;
				width:200rpx;
				text-align: center;
				color: #9A7EE5;
				font-size:30rpx;
				border:1px solid #9A7EE5;
			}
			.next{
				height: 36px;
				line-height:36px;
				border-radius:36px;
				background-color: #9A7EE5;
				border:1px solid #9A7EE5;
				width:200rpx;
				text-align: center;
				color: #ffffff;
				font-size:30rpx;
				margin-left: 50rpx;
			}
		}
		.header{
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top: 30rpx;
			margin-bottom: 30rpx;
			.pic{
				width: 36rpx;
				height: 24rpx;
			}
			.tit{
				color: #333;
				font-size: 30rpx;
				font-weight:bold;
				margin-left:10rpx;
				margin-right: 10rpx;
			}
		}
		.des{
			text-align: center;
			margin-top:20rpx;
			color:#999999;
			font-size:24rpx;
		}
		.tip{
			text-align: center;
			color:#666666;
			margin-bottom: 80rpx;
		}
		.step1wrap{
			.btn{
				color: #333;
				text-align: center;
				background: #f5f5f5;
				padding-top: 25rpx;
				padding-bottom: 25rpx;
				font-size: 30rpx;
				margin-top:30rpx;
			}
			.btnselect{
				background:#D7EBE6;
				color:#9A7EE5;
			}
		}
		.c9A7EE5{
			color: #9A7EE5;
		}
	}
}

</style>
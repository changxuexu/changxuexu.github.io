<template>
	<view class="weightpage">
		<view class="topbg"></view>
		
		<!-- 0  -->
		<view class="flex-y-center userinfo">
			<image :src="homea2pic" mode="aspectFit" class="avatar"></image>
			<view class="desc"> tom大叔 </view>
		</view>
		
		<!-- 1 -->
		<view class="floorbox tzzuijin">
			<view class="flex">
				<view class="tzinfo flex1">
					<view class="desc1">最近体重</view>
					<view class="desc2 flex">
						<text class="num">64.2</text>
						<text class="unit">kg</text>
						<image :src="homea1pic" class="icon"></image>
						<view class="btn">填写</view>
					</view>
					<view class="desc3">体重相比上次：<text class="up">增重2.10kg</text></view>
				</view>
				<view @click="gohandle(1)" class="more">查看更多></view>
			</view>
			<scroll-view class="scroll-view_H" scroll-x="true" scroll-left="0">
				<view class="item">
					<view class="name">性别</view>
					<view class="val">男</view>
				</view>
				<view class="item">
					<view class="name">年龄</view>
					<view class="val">26</view>
				</view>
				<view class="item">
					<view class="name">身高</view>
					<view class="val">172cm</view>
				</view>
				<view class="item">
					<view class="name">体重</view>
					<view class="val">64KG</view>
				</view>
			</scroll-view>
		</view>
		
		<!-- 2 -->
		<view class="floorbox jianzpaih">
			<view class="floorheader flex-y-center">
				<view class="flex1 tit">
					<text>减重排行</text>
				</view>
				<view class="desc">更多></view>
			</view>
			<view class="flex flex-bt">
				<template v-for="(item,index) in 3">
					<view class="item">
						<view class="top">
							<view v-if="index == 0" class="rankbox flex-y-center">
								<image :src="homeab1pic" class="iconhg"></image>
								<text>排名No.1</text>
							</view>
							<view v-if="index == 1" class="rankbox rankbox1 flex-y-center">
								<image :src="homeab2pic" class="iconhg"></image>
								<text>排名No.2</text>
							</view>
							<view v-if="index == 2" class="rankbox rankbox2 flex-y-center">
								<image :src="homeab3pic" class="iconhg"></image>
								<text>排名No.3</text>
							</view>
							<image :src="homea2pic" class="avatar"></image>
						</view>
						<view class="name">张三</view>
					</view>
				</template>
			</view>
		</view>
		
		<!-- 3 -->
		<view class="floorbox">
			<view class="floorheader flex-y-center">
				<view class="flex1 tit">
					<text>体重趋势</text>
				</view>
				<view class="desc">历史体重></view>
			</view>
			<view class="">
				折线图
			</view>
		</view>
		
		<!-- 4 -->
		<view class="floorbox tizhongmubiao">
			<view class="floorheader flex-y-center">
				<view class="flex1 tit">
					<text>体重目标</text>
				</view>
			</view>
			<view class="flex-y-center">
				<view class="des">快来设置健康目标计划!</view>
				<image :src="homea2pic" class="homea2pic"></image>
			</view>
			<view class="btn">参加计划</view>
		</view>
	</view>
</template>

<script>
import homea1pic from './images/homea1.png'
import homea2pic from './images/homea2.png'
import homeab1pic from './images/homeab1.png'
import homeab2pic from './images/homeab2.png'
import homeab3pic from './images/homeab3.png'
export default {
	data() {
		return {
			homea1pic,homea2pic,homeab1pic,homeab2pic,homeab3pic,
			
		}
	},
	methods:{
		gohandle(type){
			let url = ''
			if(type == 1){
				url = '/pages/weight/baogao'
			}else if(type == 2){
				// url = ''
			}
			uni.navigateTo({ url })
		}
	}
}
	
</script>

<style lang="scss" scoped>
.weightpage{
	overflow: hidden;
	padding-bottom:20rpx;
	.userinfo{
		margin:20rpx 30rpx;
		.avatar{
			border:1px solid #ffffff;
			background-color:#ffffff;
			width:80rpx;
			height:80rpx;
			border-radius:100rpx;
			display: block;
		}
		.desc{
			font-size:30rpx;
			color:#ffffff;
			margin-left:15rpx;
		}
	}
	.tzzuijin{
		.tzinfo{
			.desc1{
				color: #9B7FE5;
			}
			.desc2{
				margin-top:20rpx;
				.num{
					font-size:50rpx;
					color: #9B7FE5;
					line-height:50rpx;
				}
				.unit{
					color: #9B7FE5;
					align-self: flex-end;
				}
				.icon{
					width:8px;
					height:10px;
					margin-left:10rpx;
				}
				.btn{
					margin-left:30rpx;
					padding-left:25rpx;
					padding-right:25rpx;
					height:50rpx;
					line-height:50rpx;
					border-radius:50rpx;
					background-color:#9B7FE5;
					align-self: center;
					color:#ffffff;
				}
			}
			.desc3{
				color:#333333;
				margin-top:10rpx;
				.up{
					color:#99433B;
				}
				.down{
					color:#45A95A;
				}
			}
		}
		.more{
			color: #666666;
		}
	}
	.scroll-view_H{
		white-space: nowrap;
		width: 100%;
		margin-top:30rpx;
		.item{
			display: inline-block;
			background-color: #F2FBFA;
			text-align: center;
			margin-right:20rpx;
			width: 24%;
			padding: 30rpx 10rpx;
			border-radius:10rpx;
			.name{
				color:#666666;
			}
			.val{
				color:#333333;
				font-weight:500;
				margin-top:8rpx;
			}
		}
	}
	.jianzpaih{
		.item{
			margin-top: 20rpx;
			width:32%;
			padding:10rpx;
			background-color:#F8F7FC;
			border-radius:10rpx;
			.top{
				background-color:#ffffff;
				display: flex;
				flex-direction: column;
				align-items: center;
				.avatar{
					width:100rpx;
					height:100rpx;
					border-radius:100rpx;
					display: block;
					margin-top:20rpx;
					margin-bottom:30rpx;
				}
				.rankbox{
					background-color: #FFF6E7;
					padding:5rpx 15rpx;
					border-radius:20rpx;
					margin-top: 20rpx;
					.iconhg{
						width:24rpx;
						height:24rpx;
					}
					text{
						font-size:20rpx;
						color: #FDF063;
					}
				}
				.rankbox1{
					background-color: #F1F1F1;
					text{
						color: #B1B1B1;
					}
				}
				.rankbox2{
					background-color: #FEFAEF;
					text{
						color: #FFDBA5;
					}
				}
			}
			.name{
				font-weight:bold;
				padding-top:10rpx;
				padding-bottom:10rpx;
				overflow: hidden;
				white-space:nowrap; 
				text-overflow: ellipsis;
			}
		}
	}
	.topbg{
		position: absolute;
		z-index: -1;
		width:100%;
		height: 390rpx;
		background-color: #9B7FE5;
		border-radius: 0 0 30rpx 30rpx;
	}
	.floorbox{
		background-color: #ffffff;
		padding:30rpx;
		margin: 20rpx 30rpx;
		border-radius:10rpx;
	}
	.floorheader .tit{
		line-height:32rpx;
		font-size:30rpx;
		font-weight:bold;
		border-left: 8rpx solid #BCAEE0;
	}
	.floorheader .tit text{
		padding-left:15rpx;
	}
	.floorheader .desc{
		color:#666666;
	}
	.tizhongmubiao{
		.des{
			flex:1;
			color:#666666;
		}
		.homea2pic{
			width: 170rpx;
			height: 150rpx;
		}
		.btn{
			margin-top:20rpx;
			text-align: center;
			height:80rpx;
			line-height:80rpx;
			font-size:30rpx;
			color: #9479DB;
			background-color: #F2FBFA;
			border-radius:10rpx;
		}
	}
}
</style>
<template>
	<view class="baogaopage">
		<view class="topbg"></view>
		<view class="flex toptitle">
			<view class="lt flex1">健康报告</view>
			<view>2024-05-15 22:30:20</view>
		</view>
		<view class="floorbox zhbg">
			<view class="desc1">当前体重(KG)</view>
			<view class="desc2">64.2</view>
			<view class="jiancebiaozhundata">
				<view class="item">89.54</view>
				<view class="item">116.16</view>
				<view class="item">135.52</view>
				<view class="item">145.2</view>
			</view>
			<view class="jiancebiaozhun">
				<view class="item">
					<view class="line bg1"></view>
					<view class="ms">偏瘦</view>
					<!-- <image :src="homec1pic" class="pic"></image> -->
				</view>
				<view class="item">
					<view class="line bg2"></view>
					<view class="ms">标准</view>
					<!-- <image :src="homec1pic" class="pic"></image> -->
				</view>
				<view class="item">
					<view class="line bg3"></view>
					<view class="ms">偏胖</view>
					<!-- <image :src="homec1pic" class="pic"></image> -->
				</view>
				<view class="item">
					<view class="line bg4"></view>
					<view class="ms">肥胖</view>
					<!-- <image :src="homec1pic" class="pic"></image> -->
				</view>
				<view class="item">
					<view class="line bg5"></view>
					<view class="ms">重度</view>
					<image :src="homec1pic" class="pic"></image>
				</view>
			</view>
			<view class="desc4 bd5">
				<view class="dot">“</view>
				<view class="msg">每天早上必须坚持小跑30分钟以上哈，真的必须要控制体重啦!</view>
				<view class="dot">”</view>
			</view>
			<view class="desc3">
				脂肪没有测出来哦!肽瘦体重管理没法知道您的体型，是称不支持还是测量方式不对呢?赤脚上称才会更准哦!
			</view>
		</view>
		
		<view class="floorbox zonghedeifen">
			<view class="top">综合得分：<text>0</text>分</view>
			<view @click="gohandle(0)" class="flex item bgf5">
				<view class="flex1">体重</view>
				<view class="num">64.2KG</view>
				<view class="label">重度</view>
				<view class="arrow"></view>
			</view>
			<view @click="gohandle(1)" class="flex item bgff">
				<view class="flex1">BMI</view>
				<view class="num">13.3</view>
				<view class="label">重度</view>
				<view class="arrow"></view>
			</view>
		</view>
	</view>
</template>

<script>
import homec1pic from './images/homec1.png'
export default {
	data() {
		return {
			homec1pic
			
		}
	},
	methods:{
		gohandle(index){
			uni.navigateTo({ url:`/pages/weight/baogaodetail?current=${index}` })
		}
	}
}
</script>

<style lang="scss" scoped>
.baogaopage{
	overflow: hidden;
	padding-bottom:20rpx;
	.zonghedeifen{
		.top{
			margin-bottom:30rpx;
			text{
				font-weight:bold;
				font-size:40rpx;
			}
		}
		.item{
			padding: 20rpx;
			.label{
				background-color:#D10012;
				color:#ffffff;
				font-size:24rpx;
				padding:5rpx 25rpx;
				margin-left:15rpx;
				border-radius:20rpx;
				transform: scale(0.9);
			}
			.arrow{
				margin-left:40rpx;
			}
		}
		.bgff{
			background-color:#ffffff;
		}
		.bgf5{
			background-color:#f5f5f5;
		}
	}
	.jiancebiaozhundata{
		margin-top:30rpx;
		display: flex;
		padding-left:80rpx;
		.item{
			flex:1;
		}
	}
	.bg1{
		background: #15AEDD;
	}
	.bg2{
		background: #96CC9A;
	}
	.bg3{
		background: #FFC23D;
	}
	.bg4{
		background: #FF5F32;
	}
	.bg5{
		background: #D10012;
	}
	.desc4{
		display: flex;
		padding:30rpx 0;
		margin-top:20rpx;
		border-radius:10rpx;
		.dot{
			color: #F5AAB0;
			font-size:50rpx;
		}
		.msg{
			padding:20rpx 15rpx;
			font-size:30rpx;
		}
	}
	.bd1{
		border:1px dashed #15AEDD;
		background: #15AEDD;
	}
	.bd2{
		border:1px dashed #96CC9A;
		background: #96CC9A;
	}
	.bd3{
		border:1px dashed #FFC23D;
		background: #FFC23D;
	}
	.bd4{
		border:1px dashed #FF5F32;
		background: #FF5F32;
	}
	.bd5{
		border:1px dashed #E36671;
		background: #FFF2F3;
	}
	.jiancebiaozhun{
		margin-top:10rpx;
		display: flex;
		.item{
			flex:1;
			margin-left:10rpx;
			display: flex;
			flex-direction: column;
			align-items: center;
			&:first-child{
				margin-left:0;
			}
			.line{
				width: 100%;
				height: 4px;
			}
			.ms{
				color:#333333;
				margin-top:10rpx;
			}
			.pic{
				margin-top:10rpx;
				display: block;
				width:40rpx;
				height:48rpx;
			}
		}
	}
	.zhbg{
		.desc1{
			color: #666666;
			font-size:30rpx;
		}
		.desc2{
			font-size:50rpx;
			margin-top:20rpx;
		}
		.desc3{
			margin-top:15rpx;
			color: #666666;
		}
	}
	.toptitle{
		margin:30rpx 30rpx 30rpx 30rpx;
		color:#ffffff;
		.lt{
			font-size:32rpx;
			font-weight:bold;
		}
	}
	.topbg{
		position: absolute;
		z-index: -1;
		width:100%;
		height: 180rpx;
		background-color: #9B7FE5;
		// border-radius: 0 0 30rpx 30rpx;
	}
	.floorbox{
		background-color: #ffffff;
		padding:30rpx;
		margin: 20rpx 30rpx;
		border-radius:10rpx;
	}
	.arrow {margin-right:4px;position: relative}
	.arrow:after {content:" ";display:inline-block;height:6px;width:6px;border-width:1px 1px 0 0;border-style:solid;border-color:#999999;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-3px; position:absolute;top:50%;right:0;}
}
</style>
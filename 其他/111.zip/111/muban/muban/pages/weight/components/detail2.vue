<template>
	<view class="detailwrap">
		<image :src="home5pic" class="toppic"></image>
		
		<view class="des">
			BM指数(即身体质量指数，简秤体质指数又秤体重，英文为 Body Mass Index，简秤BMI)，是用体重公斤数除以身高米数平方得出的数字，是目前国际上常用的衡量人体胖瘦程度以及是否健康的一个标准。
		</view>
		
		<view class="data">
			您的BMI：47.2
		</view>
		
		
		<view class="jiancebiaozhundata">
			<view class="item">89.54</view>
			<view class="item">116.16</view>
			<view class="item">135.52</view>
			<view class="item">145.2</view>
		</view>
		
		<view class="jiancebiaozhun">
			<view class="item">
				<view class="line bg1"></view>
				<view class="ms">偏瘦</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg2"></view>
				<view class="ms">标准</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg3"></view>
				<view class="ms">偏胖</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg4"></view>
				<view class="ms">肥胖</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg5"></view>
				<view class="ms">重度</view>
				<image :src="homec1pic" class="pic"></image>
			</view>
		</view>
		
		<view class="floorguid">
			<image :src="homea3pic" class="homea3pic"></image>
			<view class="tit">BMI小百科</view>
			<image :src="homea3pic" class="homea3pic"></image>
		</view>
		<view class="des">
			根据日本肥胖学会志《肥胖研究》中的标准，用BM计算出的正常范围内的人，从统计学的角度来看，在同等身高的人中，患病概率最小。
		</view>
		<view class="des">
			与正常范围内的人相比较，大于或小于这个数值，都更容易患病。因此，我们需要通过控制饮食和适量运动来维持良好的BM指数，以达到管理健康的目的。
		</view>
		<view class="des">
			使BM正常的两大“法宝”:管住嘴，迈开腿。适当的节食是有助于减肥，而且尽量少吃高盐、高脂肪的食物，多吃蔬果，这样平衡身体的营养。减肥中，节食外还要配以适当的运动，让一定的热量从中释放，在体闲的日子中多做一下瑜伽、或者去慢跑一下，促进血液循环，排除身体的毒素，在忙碌的日子，也要抽时间做一些简单的运动，比如在办公室就可以做一些伸展运动，活动一下。
		</view>
	</view>
</template>

<script>
import home5pic from '../images/home5.png'
import homea3pic from '../images/homea3.png'
import homec1pic from '../images/homec1.png'
export default {
	data() {
		return {
			home5pic,homea3pic,homec1pic
		}
	}
}
</script>

<style lang="scss" scoped>
.detailwrap{
	padding:30rpx;
	.toppic{
		width:120rpx;
		height:120rpx;
		display: block;
		margin:0 auto;
	}
	.des{
		margin-top:30rpx;
		font-size:32rpx;
		color:#737874;
		line-height:50rpx;
	}
	.data{
		border:1px dashed #E36671;
		background: #FFF2F3;
		padding:20rpx;
		font-size:32rpx;
		text-align: center;
		width:500rpx;
		margin:50rpx auto 0 auto;
	}
	.floorguid{
		display: flex;
		align-items: center;
		margin-top:30rpx;
		.homea3pic{
			width: 38rpx;
			height:24rpx;
		}
		.tit{
			font-size:34rpx;
			font-weight:bold;
			margin:0 10rpx;
		}
	}
	.jiancebiaozhundata{
		margin-top:30rpx;
		display: flex;
		padding-left:80rpx;
		.item{
			flex:1;
		}
	}
	.bg1{
		background: #15AEDD;
	}
	.bg2{
		background: #96CC9A;
	}
	.bg3{
		background: #FFC23D;
	}
	.bg4{
		background: #FF5F32;
	}
	.bg5{
		background: #D10012;
	}
	.desc4{
		display: flex;
		padding:30rpx 0;
		margin-top:20rpx;
		border-radius:10rpx;
		.dot{
			color: #F5AAB0;
			font-size:50rpx;
		}
		.msg{
			padding:20rpx 15rpx;
			font-size:30rpx;
		}
	}
	.bd1{
		border:1px dashed #15AEDD;
		background: #15AEDD;
	}
	.bd2{
		border:1px dashed #96CC9A;
		background: #96CC9A;
	}
	.bd3{
		border:1px dashed #FFC23D;
		background: #FFC23D;
	}
	.bd4{
		border:1px dashed #FF5F32;
		background: #FF5F32;
	}
	.bd5{
		border:1px dashed #E36671;
		background: #FFF2F3;
	}
	.jiancebiaozhun{
		margin-top:10rpx;
		display: flex;
		.item{
			flex:1;
			margin-left:10rpx;
			display: flex;
			flex-direction: column;
			align-items: center;
			&:first-child{
				margin-left:0;
			}
			.line{
				width: 100%;
				height: 4px;
			}
			.ms{
				color:#333333;
				margin-top:10rpx;
			}
			.pic{
				margin-top:10rpx;
				display: block;
				width:40rpx;
				height:48rpx;
			}
		}
	}
}
</style>
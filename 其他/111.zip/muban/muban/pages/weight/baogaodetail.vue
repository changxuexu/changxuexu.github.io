<template>
	<view class="baogaodetailpage">
		<vtabs v-model="current" :tabs="tabs" :scroll="false" lineScale="0.2" @change="changeTab" activeColor="#9471F5" lineColor="#9471F5" bgColor="#F7F7F7" height="80rpx" :fixed="true"></vtabs>
		<view  v-if="current == 0">
			<detail1></detail1>
		</view>
		<view v-if="current == 1">
			<detail2></detail2>
		</view>
	</view>
</template>

<script>
import vtabs from './components/v-tabs/v-tabs.vue';
import detail1 from './components/detail1.vue';
import detail2 from './components/detail2.vue';
export default {
	components: {
	  vtabs,
	  detail1,
	  detail2
	},
	data() {
		return {
			current: 0,
			tabs: ['体重', 'BMI']
		}
	},
	onLoad(options){
		this.current = options['current']
	},
	methods:{
		changeTab(index) {
		  // this.current = index
		}
	}
}
</script>

<style lang="scss" scoped>
.baogaodetailpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
}
</style>
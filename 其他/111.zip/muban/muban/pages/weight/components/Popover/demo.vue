<template>

	<view class="page" @click="close">

		<view>
			<view class="demo-block">
				<view class="title">
					基础用法
				</view>
			</view>
			<view class="item-wrap">
				<zb-popover placement="bottom-start" :options="actions" ref="Popover1" @handleClick="handleClick"
					@select="onSelect" class="item-popover">
					<button class="mini-btn" type="primary" size="mini">浅色风格</button>
				</zb-popover>

				<zb-popover placement="bottom-start" :options="actions" theme="dark" ref="Popover2"
					@handleClick="handleClick1" @select="onSelect">
					<button class="mini-btn" type="primary" size="mini">深色风格</button>
				</zb-popover>
			</view>
		</view>



		<view>
			<view class="demo-block">
				<view class="title">
					排列方向
				</view>
			</view>
			<view class="item-wrap">
				<zb-popover placement="bottom-start" :options="actions" ref="Popover1" actionsDirection="horizontal"
					@handleClick="handleClick" @select="onSelect" class="item-popover">
					<button class="mini-btn" type="primary" size="mini">水平排列</button>
				</zb-popover>

				<zb-popover placement="bottom-start" :options="actions" ref="Popover2" @handleClick="handleClick1"
					@select="onSelect">
					<button class="mini-btn" type="primary" size="mini">垂直排列</button>
				</zb-popover>
			</view>
		</view>


		<view>
			<view class="demo-block">
				<view class="title">
					自定义内容
				</view>
			</view>
			<view class="item-wrap">
				<zb-popover placement="bottom-start" ref="Popover1" class="item-popover">
					<button class="mini-btn" type="primary" size="mini">自定义内容</button>
					<view slot="content">
						<view class="text">
							你好，欢迎使用
						</view>
					</view>
				</zb-popover>
			</view>
		</view>

	</view>
</template>

<script>
import zbPopover from './components/Popover/Popover'
	const actions = [{
			text: '选项一'
		},
		{
			text: '选项二'
		},
		{
			text: '选项三'
		},
	];
	export default {
		components: {
		  zbPopover
		},
		data() {
			return {
				title: 'Hello',
				actions
			}
		},
		onLoad() {

		},
		methods: {
			close() {
				this.$refs.Popover2.close()
				this.$refs.Popover1.close()
			},
			handleClick() {
				this.$refs.Popover2.close()
			},
			handleClick1() {
				this.$refs.Popover1.close()
			},
			onSelect(val) {
				uni.showToast({
					icon: 'none',
					title: val.text
				})
				console.log('===============================', val)
			}
		}
	}
</script>

<style lang="scss">
	.page {
		background: #eff2f5;
		position: absolute;
		left: 0;
		top: 0;
		right: 0;
		overflow: auto;
		bottom: 0;
		padding: 24rpx 32rpx 32rpx;
		box-sizing: border-box;
	}

	.mini-btn {
		height: 88rpx;
		line-height: 88rpx;
		padding: 0 30rpx;
		background: #1989fa;
	}

	.item-popover {
		margin-right: 20rpx;
	}

	.item-wrap {
		display: flex;
	}

	.demo-block {

		.title {
			margin: 0;
			padding-bottom: 24rpx;
			color: #969799;
			font-weight: 400;
			font-size: 28rpx;
		}


	}

	.text {
		padding: 20px;
		width: 300rpx;
	}
</style>
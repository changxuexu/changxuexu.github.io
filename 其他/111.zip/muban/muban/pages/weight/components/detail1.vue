<template>
	<view class="detailwrap">
		<image :src="home4pic" class="toppic"></image>
		<view class="des">体重是指人体各部分的总重量。它受年龄、性别、种族、遗传以及地理环境的影响。因此，体重是在不断变化的，在某一个时期内相对保持稳定。</view>
		
		<view class="data">
			您的体重：47.2KG
		</view>
		
		<view class="jiancebiaozhundata">
			<view class="item">89.54</view>
			<view class="item">116.16</view>
			<view class="item">135.52</view>
			<view class="item">145.2</view>
		</view>
		
		<view class="jiancebiaozhun">
			<view class="item">
				<view class="line bg1"></view>
				<view class="ms">偏瘦</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg2"></view>
				<view class="ms">标准</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg3"></view>
				<view class="ms">偏胖</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg4"></view>
				<view class="ms">肥胖</view>
				<!-- <image :src="homec1pic" class="pic"></image> -->
			</view>
			<view class="item">
				<view class="line bg5"></view>
				<view class="ms">重度</view>
				<image :src="homec1pic" class="pic"></image>
			</view>
		</view>
		
		<view class="floorguid">
			<image :src="homea3pic" class="homea3pic"></image>
			<view class="tit">测量体重的重要性</view>
			<image :src="homea3pic" class="homea3pic"></image>
		</view>
		<view class="des">
			日常生活中，健康人的体重通常不会有明显的变化，除非由于工作过度繁忙，体息时间少，饮食不规律等原因造成，且通常是暂时性的。一旦哪些客观因素消除后，体重很快恢复正常。然而一些原因不明的体重变化，可能是某种疾病，甚至癌症所致。因此，有人把体重比喻成一面镜子，定期测是体重可以反映一个人的健康状况。
		</view>
		<view class="des">
			对于正常人来说，每个人每天摄食和饮水得到的，大致与排除的汗液、尿液、粪便及呼吸道带出的水分相对平衡，不会给机体内在的生理生化稳定带来很大的影响，由此说来，保持一定的体重水平对整个身体健康都非常的重要。
		</view>
	</view>
</template>

<script>
import home4pic from '../images/home4.png'
import homea3pic from '../images/homea3.png'
import homec1pic from '../images/homec1.png'
export default {
	data() {
		return {
			home4pic,homea3pic,homec1pic
		}
	}
}
</script>

<style lang="scss" scoped>
.detailwrap{
	padding:30rpx;
	.toppic{
		width:120rpx;
		height:120rpx;
		display: block;
		margin:0 auto;
	}
	.des{
		margin-top:30rpx;
		font-size:32rpx;
		color:#737874;
		line-height:50rpx;
	}
	.data{
		border:1px dashed #E36671;
		background: #FFF2F3;
		padding:20rpx;
		font-size:32rpx;
		text-align: center;
		width:500rpx;
		margin:50rpx auto 0 auto;
	}
	.floorguid{
		display: flex;
		align-items: center;
		margin-top:30rpx;
		.homea3pic{
			width: 38rpx;
			height:24rpx;
		}
		.tit{
			font-size:34rpx;
			font-weight:bold;
			margin:0 10rpx;
		}
	}
	.jiancebiaozhundata{
		margin-top:30rpx;
		display: flex;
		padding-left:80rpx;
		.item{
			flex:1;
		}
	}
	.bg1{
		background: #15AEDD;
	}
	.bg2{
		background: #96CC9A;
	}
	.bg3{
		background: #FFC23D;
	}
	.bg4{
		background: #FF5F32;
	}
	.bg5{
		background: #D10012;
	}
	.desc4{
		display: flex;
		padding:30rpx 0;
		margin-top:20rpx;
		border-radius:10rpx;
		.dot{
			color: #F5AAB0;
			font-size:50rpx;
		}
		.msg{
			padding:20rpx 15rpx;
			font-size:30rpx;
		}
	}
	.bd1{
		border:1px dashed #15AEDD;
		background: #15AEDD;
	}
	.bd2{
		border:1px dashed #96CC9A;
		background: #96CC9A;
	}
	.bd3{
		border:1px dashed #FFC23D;
		background: #FFC23D;
	}
	.bd4{
		border:1px dashed #FF5F32;
		background: #FF5F32;
	}
	.bd5{
		border:1px dashed #E36671;
		background: #FFF2F3;
	}
	.jiancebiaozhun{
		margin-top:10rpx;
		display: flex;
		.item{
			flex:1;
			margin-left:10rpx;
			display: flex;
			flex-direction: column;
			align-items: center;
			&:first-child{
				margin-left:0;
			}
			.line{
				width: 100%;
				height: 4px;
			}
			.ms{
				color:#333333;
				margin-top:10rpx;
			}
			.pic{
				margin-top:10rpx;
				display: block;
				width:40rpx;
				height:48rpx;
			}
		}
	}
}
</style>
<template>
	<!-- 1、上称改为填写，采集数据为：男或女，年龄、身高、体重。 -->
</template>

<script>
</script>

<style>
</style>
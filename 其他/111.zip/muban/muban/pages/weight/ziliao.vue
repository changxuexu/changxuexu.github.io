<template>
	<view class="ziliaopage">
		
		<view class="p-relative border-line-b ptd"> 
			<picker :range="arr_sex" :value="sex_index" @change="bindsexChange">
				<view class="flex item">
					<view class="flex1">性别</view>
					<view class="val">{{sex_value ? sex_value : '请选择'}}</view>
					<view class="arrow"></view>
				</view>
			</picker> 
		</view> 
		<view class="p-relative border-line-b ptd">
			<picker mode="date" :value="currentDate" @change="bindDateChange">
				<view class="flex item">
					<view class="flex1">出生日期</view>
					<view class="val">{{birdate ? birdate : '请选择'}}</view>
					<view class="arrow"></view>
				</view>
			</picker> 
		</view> 
		<view @click="heighthandle" class="p-relative border-line-b ptd">
			<view class="flex item">
				<view class="flex1">身高</view>
				<view class="val">{{height ? `${height} cm` : '请选择'}}</view>
				<view class="arrow"></view>
			</view>
		</view>
		
		<view @click="weighthandle" class="p-relative border-line-b ptd">
			<view class="flex item">
				<view class="flex1">体重</view>
				<view class="val">{{weight ? `${weight} kg` : '请选择'}}</view>
				<view class="arrow"></view>
			</view>
		</view>
		
		<view class="footerwrap">
			<view class="fixfoot">提交</view>
		</view>
		

		<liupopup type="bottom" ref="heightbottom">
			<view class='scale-value'>{{ horizontaPointVal }}CM</view>
			<view class="heightscale">
				<vue-scale :min="20"
				   :max="220"
				   :int="false"
				   :single="10"
				   :h="40"
				   :active="36.1"
				   :styles="styles"
				   @value="horizontaPointMethods"/> 
			</view>
			<view @click="saveheighthandle" class="queding">确定</view>
		</liupopup>
		
		<liupopup type="bottom" ref="weightbottom">
			<view class='scale-value'>{{ horizontaPointVal2 }}KG</view>
			<view class="heightscale">
				<vue-scale :min="20"
				   :max="220"
				   :int="false"
				   :single="10"
				   :h="40"
				   :active="36.1"
				   :styles="styles"
				   @value="horizontaPointMethods2"/> 
			</view>
			<view @click="saveweighthandle" class="queding">确定</view>
		</liupopup>
	</view>
</template>

<script>
import { dateFormater } from './util.js'
import liupopup from './components/liu-popup/liu-popup'
import vueScale from './components/vueScale/index.vue';
export default {
	components: {
	  liupopup,vueScale
	},
	data() {
		return {
			arr_sex:['男', '女'],
			sex_index:0,
			sex_value:'',
			currentDate:dateFormater('YYYY-MM-DD'),
			birdate:'',
			styles: {
			  line: '#BEBEBE',
			  bginner: '#fbfbfb',
			  bgoutside: '#ffffff',
			  font: '#404040',
			  fontColor: '#404040',
			  fontSize: 14,
					lineSelect: '#C74D41',
			},
			horizontaPointVal: '',
			height:'',
			horizontaPointVal2: '',
			weight:''
		}
	},
	methods:{
		saveweighthandle(){
			this.weight = this.horizontaPointVal2
			this.$refs['weightbottom'].close();
		},
		weighthandle(){
			this.$refs['weightbottom'].open();
		},
		horizontaPointMethods2(msg){
			this.horizontaPointVal2 = msg;
		},
		saveheighthandle(){
			this.height = this.horizontaPointVal
			this.$refs['heightbottom'].close();
		},
		heighthandle(){
			this.$refs['heightbottom'].open();
		},
		horizontaPointMethods(msg) {
		  this.horizontaPointVal = msg;
		},
		bindsexChange(e){
			let arr_sex = this.arr_sex
			this.sex_index = e.detail.value
			this.sex_value = arr_sex[e.detail.value]
		},
		bindDateChange(e){
			this.currentDate = e.detail.value
			this.birdate = e.detail.value
		}
	}
}
</script>

<style lang="scss" scoped>
.ziliaopage{
	padding:30rpx;
	.ptd{padding:20rpx;}
	.p-relative{ position: relative; }
	.border-line-b::after{position: absolute;box-sizing: border-box;content: " ";
		pointer-events: none;top: -50%;right: -50%;bottom: -50%;left: -50%;border: 0 solid #ebedf0;
		-webkit-transform: scale(.5);transform: scale(.5);border-bottom-width: 1px;}
	.arrow {margin-right:4px;position: relative}
	.arrow:after {content:" ";display:inline-block;height:6px;width:6px;border-width:1px 1px 0 0;border-style:solid;border-color:#999999;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-3px; position:absolute;top:50%;right:0;}
	.val{padding-right: 30rpx;}
	.footerwrap{
		height:40px;
	}
	.fixfoot{
		position: fixed;
		left:0;
		right:0;
		bottom:0;
		height:40px;
		line-height:40px;
		background-color: #9A7EE5;
		text-align: center;
		font-size:30rpx;
		color:#ffffff;
	}
	.scale-value{
		text-align: center;
		color: #C74D41;
		font-size:54rpx;
		margin-top:30rpx;
		margin-bottom:30rpx;
	}
	.heightscale{
		padding:0 60rpx;
	}
	.queding{
		height: 36px;
		line-height:36px;
		border-radius:36px;
		background-color: #9A7EE5;
		width:180rpx;
		margin: 30rpx auto;
		text-align: center;
		color: #ffffff;
		font-size:30rpx;
	}
}
</style>
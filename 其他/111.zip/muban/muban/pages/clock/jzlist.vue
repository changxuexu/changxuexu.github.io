<template>
	<view class="jzlistpage">
		<view class="dateserbox flex flex-bt">
			<picker mode="date" :value="startDate" :end="endDate" @change="bindstartDateChange">
				<view class="flex">
					<view class="">开始日期:</view>
					<view class="">{{startDate}}</view>
				</view>
			</picker>
			<picker mode="date" :value="endDate" :end="endDate" @change="bindendDateChange">
				<view class="flex">
					<view class="">结束日期:</view>
					<view class="">{{endDate}}</view>
				</view>
			</picker>
		</view>
		
		<view class="dateserbox flex flex-bt mt15">
			<view class="tit">全部剂量共：0.12mg</view>
			<view @click="gohandle('buka')" class="btn">补打卡</view>
		</view>
		
		<template v-for="item in 2">
			<view :key="item" class="dateserbox mt15">
				<view class="tit">时间：2024-05-14</view>
				<view class="btn mt10">本日剂量共：0.06mg</view>
				<view class="data mt10">
					<view class="item">
						<view class="desc">早餐时段</view>
						<view class="num">0.06mg</view>
					</view>
					<view class="item">
						<view class="desc">中餐时段</view>
						<view class="num">0mg</view>
					</view>
					<view class="item">
						<view class="desc">晚餐时段</view>
						<view class="num">0mg</view>
					</view>
					<view class="item">
						<view class="desc">加餐时段</view>
						<view class="num">0mg</view>
					</view>
				</view>
			</view>
		</template>
			
	</view>
</template>

<script>
import { dateFormater, minusThreeMonths } from './util.js'
export default {
	data() {
		return {
			startDate:dateFormater('YYYY-MM-DD',minusThreeMonths()),
			endDate:dateFormater('YYYY-MM-DD')
		}
	},
	methods:{
		gohandle(type){
			uni.navigateTo({ url:`/pages/clock/jzclock?type=${type}` })
		},
		bindstartDateChange(e){
			this.startDate = e.detail.value
		},
		bindendDateChange(e){
			this.endDate = e.detail.value
		}
	}
}
</script>

<style>
.jzlistpage{
	padding:30rpx;
}
.jzlistpage .mt15{
	margin-top:30rpx;
}
.jzlistpage .mt10{
	margin-top:20rpx;
}
.jzlistpage .dateserbox{
	background:#ffffff;
	padding:30rpx;
	border-radius:10rpx;
}
.jzlistpage .tit{
	color: #666666;
}
.jzlistpage .btn{
	color: #2D79C2;
}
.dateserbox .data{
	display: flex;
}
.dateserbox .data .item{
	background:#F3FCF7;
	flex:1;
	text-align: center;
	padding:25rpx 0;
	border-radius:10rpx;
	margin-left:15rpx;
}
.dateserbox .data .item:first-child{
	margin-left:0;
}
.dateserbox .data .item .desc{
	color: #666666;
	font-size:24rpx;
}
.dateserbox .data .item .num{
	color: #2D79C2;
	font-weight:bold;
	margin-top:10rpx;
}
</style>
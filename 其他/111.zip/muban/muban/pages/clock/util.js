export const minusThreeMonths = (t) => {
	const newDate =  t ? new Date(t) : new Date();
	newDate.setMonth(newDate.getMonth() - 3);
	return newDate;
}
//时间格式化
export const dateFormater = (formater, t) => {
  let date = t ? new Date(t) : new Date();
  let Y = date.getFullYear() + "";
  let M = date.getMonth() + 1;
  let D = date.getDate();
  let H = date.getHours();
  let m = date.getMinutes();
  let s = date.getSeconds();
  return formater
    .replace(/YYYY|yyyy/g, Y)
    .replace(/YY|yy/g, Y.substr(2, 2))
    .replace(/MM/g, (M < 10 ? "0" : "") + M)
    .replace(/DD/g, (D < 10 ? "0" : "") + D)
    .replace(/HH|hh/g, (H < 10 ? "0" : "") + H)
    .replace(/mm/g, (m < 10 ? "0" : "") + m)
    .replace(/ss/g, (s < 10 ? "0" : "") + s);
};
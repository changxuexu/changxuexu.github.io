<template>
	<view class="yslistpage">
		<view class="wrap">
			<view class="flex-y-center flex-bt">
				<view class="flex-y-center flex1">
					<image :src="clock6pic" mode="aspectFill" class="iconuser"></image>
					<view class="name">tom</view>
				</view>
				<picker mode="date" :value="endDate" :end="endDate" @change="bindendDateChange">
					<view class="flex-y-center">
						<view class="time">{{endDate}}</view>
						<image :src="clock6pic" mode="aspectFill" class="iconclock6"></image>
					</view>
				</picker>
			</view>
			
			<template v-for="item in 2">
				<view class="itemrecord">
					<view class="flex">
						<view class="flex1 tit">早餐</view>
						<view class="tim">2024-05-12 22:16:24</view>
					</view>
					<view class="data">
						<view class="">饮食食物：</view>
						<view class="mt5">饮食时间：09:00</view>
						<view class="picbox">
							<template v-for="item in 6">
								<image :src="clock6pic" mode="aspectFit" class="pic"></image>
							</template>
						</view>
					</view>
				</view>
			</template>
			
		</view>
	</view>
</template>

<script>
import clock6pic from './images/clock6.png'
import { dateFormater } from './util.js'
export default {
	data() {
		return {
			clock6pic,
			endDate:dateFormater('YYYY-MM-DD')
		}
	},
	methods:{
		bindendDateChange(e){
			this.endDate = e.detail.value
		}
	},
}
</script>

<style>
.yslistpage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
}
.yslistpage .wrap{
	padding:30rpx;
}
.yslistpage .iconuser{
	width:80rpx;
	height:80rpx;
	border-radius: 100%;
	background-color:#f5f5f5;
}
.yslistpage .name{
	font-size:30rpx;
	margin-left:10rpx;
}
.yslistpage .iconclock6{
	width:24rpx;
	height:24rpx;
	margin-left:10rpx;
}
.yslistpage .time{
	text-decoration: underline;
	color:#666666;
}
.itemrecord{
	margin-top:30rpx;
}
.itemrecord .tit{
	color: #3EB1B8;
}
.itemrecord .tim{
	color:#666666;
}
.itemrecord .data{
	margin-top:20rpx;
	padding:30rpx;
	background-color: #F6FCFC;
}
.itemrecord .mt5{
	margin-top:10rpx;
}
.itemrecord .picbox{
	display: flex;
	flex-wrap: wrap;
}
.itemrecord .picbox .pic{
	border-radius: 10rpx;
	background-color:#ffffff;
	width:120rpx;
	height:120rpx;
	margin-top:18rpx;
	margin-right:18rpx;
}
</style>

<template>
	<view class="yswancpage">
		
	</view>
</template>

<script>
</script>

<style>
</style>
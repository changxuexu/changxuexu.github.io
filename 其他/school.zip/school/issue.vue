<template>
	<view class="issuepage">
		<section title="基础用法" type="line">
			<collapse ref="collapse" v-model="curvalue" accordion>
				<template v-for="(item,idx) in 10">
					<collapseitem :key="idx">
						<template v-slot:title>
							<view class="flex-y-center headerwrap">
								<image :src="qus1pic" class="qus1pic"></image>
								<view class="flex1 tit">贵校是一所什么层次的学校?</view>
							</view>
						</template>
						<template v-slot:icon>
							<image :src="qus3pic" class="qus3pic"></image>
						</template>
						<view class="flex">
							<image :src="qus2pic" class="qus2pic"></image>
							<view class="flex1 content">
								我校是一所以工学为主，多学科协调发展的省属重点大学，是湖北省“双一流”建设高校、国家“中西部高校基础能力建设工程”高校、全国毕业生就业典型经验高校、全国深化创新创业教育改革示范高校、国家知识产权试点高校、国家”赋予科研人员职务科技成果所有权或长期使用权试点单位”、首批国家级现代产业学院建设单位、全国文明校园先进学校。学校连续多年在湖北省录取分数线位居省属高校前三，自2014年起，学校整体进入一本批次招生。
							</view>
						</view>
					</collapseitem>
				</template>
			</collapse>
		</section>
	</view>
</template>

<script>
import section from './components/collapse/section'
import collapse from './components/collapse/collapse'
import collapseitem from './components/collapse/collapse-item'
import qus1pic from './images/qus1.png'
import qus2pic from './images/qus2.png'
import qus3pic from './images/qus3.png'
export default {
	components:{
		section,collapse,collapseitem
	},
	data() {
		return {
			qus1pic,qus2pic,qus3pic,
			curvalue:['0']
		}
	},
	methods: {
		
	}
}
</script>

<style lang="scss" scoped>
.issuepage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
	padding-left:30rpx;
	padding-right:30rpx;
	.headerwrap{
		padding-top:30rpx;
		padding-bottom:30rpx;
		.qus1pic{
			width: 34rpx;
			height:34rpx;
		}
		.tit{
			margin-left:20rpx;
			font-size:32rpx;
		}
	}
	/deep/ .qus2pic{
		width: 34rpx;
		height:34rpx;
		flex-shrink:0;
	}
	/deep/ .qus3pic{
		width: 28rpx;
		height:14rpx;
	}
	.content{
		background-color:#f5f5f5;
		padding:30rpx;
		margin:0 0 30rpx 20rpx;
		border-radius:10rpx;
		line-height:1.5;
	}
}
</style>
<template>
	<view class="zsgudiepage">
		<view class="floorwrap">
			<view class="title">年份</view>
			<view class="info">
				<view 
					@click="yearhandle(index)" 
					:class="['item', {'active':index == year_index}]" 
					v-for="(item,index) in year" :key="index">{{item}}</view>
			</view>
		</view>
		<view class="floorwrap">
			<view class="title">地区</view>
			<view class="info">
				<view 
					@click="areahandle(index)" 
					:class="['item', {'active':index == area_index}]"
					v-for="(item,index) in area" :key="index">{{item}}</view>
			</view>
		</view>
		<view class="floorwrap">
			<view class="title">科类</view>
			<view class="info">
				<view
					@click="typehandle(index)" 
					:class="['item', {'active':index == type_index}]"
					v-for="(item,index) in type" :key="index">{{item}}</view>
			</view>
		</view>
		
		<view class="tablewrap">
			<ws-table :config="config" :table-data="tableData" :showSummary="false" :showTableFilter="false"></ws-table>
		</view>
		
	</view>
</template>

<script>
import WsTable from "./components/ws-table/index.vue"
export default {
	components: {WsTable},
	data() {
		return {
			year:['2023','2022','2021','2020'],
			year_index:0,
			area:['湖北省','陕西省','河南省','贵州省','云南省','宁夏回族自治区'],
			area_index:0,
			type:['文史(历史类)','理工(物理类)','文史/专(历史类)','理工/专(物理类)'],
			type_index:0,
			
			config: [
				{ label: '专业', key: 'zhuanye', width: 345 },
				{ label: '计划数', key: 'jihuanum', width: 350 }
			],
			tableData: [
				{ zhuanye: '金融学', jihuanum: '16' },
				{ zhuanye: '国际经济与贸易', jihuanum: '16' },
				{ zhuanye: '法学', jihuanum: '16' },
				{ zhuanye: '汉语言文学', jihuanum: '16' }
			]
		}
	},
	methods: {
		yearhandle(index){
			this.year_index = index
		},
		areahandle(index){
			this.area_index = index
		},
		typehandle(index){
			this.type_index = index
		}
	}
}
</script>

<style lang="scss" scoped>
.zsgudiepage{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#ffffff;
	overflow: hidden;
	.floorwrap{
		padding-left:30rpx;
		padding-right:30rpx;
		display: flex;
		margin-top:30rpx;
		.title{
			flex-shrink:0;
			font-size:32rpx;
			font-weight:bold;
			height:60rpx;
			line-height:60rpx;
			margin-right:30rpx;
		}
		.info{
			display: flex;
			flex-wrap: wrap;
			.item{
				background-color: #F0F0F0;
				height:60rpx;
				line-height:60rpx;
				border-radius:60rpx;
				padding-left:30rpx;
				padding-right:30rpx;
				margin-right:20rpx;
				margin-bottom:20rpx;
				font-size:28rpx;
			}
			.active{
				background-color: #0168B7;
				color: #ffffff;
			}
		}
	}
	.tablewrap{
		margin:30rpx;
		/deep/ .header-bg{
			background-color: #0168B7 !important;
			color: #ffffff;
		}
	}
}
</style>
<template>
	<view class="xydetailwrap">
		<image :src="xytoppic"></image>
		<view class="content">
			<view class="title">艺术学院2022届毕业生去向报告</view>
			<view class="time">发布日期:2023-11-21 点击量:11</view>
			<view class="htmlwrap">
				<u-parse :content="article"></u-parse>
			</view>
		</view>
	</view>
</template>

<script>
import xytoppic from './images/xytop.png'
import uParse from './components/u-parse/u-parse.vue'
export default {
	components: {
	    uParse
	},
	data() {
		return {
			xytoppic,
			article: '<div>我是HTML代码</div>'
		}
	},
	methods: {
		
	}
}
</script>

<style lang="scss" scoped>
@import url("./components/u-parse/u-parse.css");
.xydetailwrap{
	/* #ifdef MP */
	min-height: 100vh;
	/* #endif */
	/* #ifdef H5 */
	min-height: calc(100vh - 44px);
	/* #endif */
	background-color:#F3EFCA;
	position: relative;
	.xytoppic{
		width:100%;
		height:200rpx;
	}
	.content{
		background-color: rgba(255, 255, 255, 0.8);
		min-height:85vh;
		position: absolute;
		left:30rpx;
		right:30rpx;
		top:100rpx;
		border-radius:20rpx;
		padding:30rpx;
		.title{
			font-size:32rpx;
			font-weight:bold;
			text-align: center;
		}
		.time{
			margin-top:20rpx;
			text-align: center;
			color:#999999;
		}
		.htmlwrap{
			margin-top:30rpx;
		}
	}
}
</style>
<template>
	<view class="ysjspage">
		<view class="title">院系介绍</view>
		<template v-for="(item,idx) in 10">
			<view class="item" :key="idx">
				<view class="flex-y-center">
					<view class="dot"></view>
					<view class="flex1 tit">建筑学院</view>
					<view class="intro arrow">院系介绍</view>
				</view>
				<view class="labelwrap">
					<view class="type active">建筑学</view>
					<view class="type">城乡规划</view>
					<view class="type">风录园林</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
</script>

<style lang="scss" scoped>
.ysjspage{
	overflow: hidden;
	.title{
		font-size: 40rpx;
		font-weight:bold;
		padding:50rpx 30rpx;
	}
	.item{
		background-color: #ffffff;
		margin-bottom:30rpx;
		padding:30rpx;
		
		.dot{
			width:15rpx;
			height:15rpx;
			border-radius:100%;
			background-color:#4B7C2A;
			margin-right:12rpx;
		}
		.tit{
			font-size:36rpx;
			font-weight:bold;
		}
		.intro{
			position: relative;
			padding-right:20rpx;
		}
		.arrow {position: relative}
		.arrow:after {content:" ";display:inline-block;height:4px;width:4px;border-width:1px 1px 0 0;border-style:solid;border-color:#666666;transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);margin-top:-2px; position:absolute;top:50%;right:0;}
		
		.labelwrap{
			display: flex;
			flex-wrap: wrap;
			.type{
				margin-right:20rpx;
				border:1px solid #8F8F8F;
				font-size:30rpx;
				height:55rpx;
				line-height:55rpx;
				border-radius:55rpx;
				padding-left:30rpx;
				padding-right:20rpx;
				margin-top:20rpx;
			}
			.active{
				border-color:#4C7C2B;
				background-color: #4C7C2B;
				color:#ffffff;
			}
		}
	}
}
</style>
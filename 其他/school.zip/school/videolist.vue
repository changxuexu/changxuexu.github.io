<template>
	<view>
		<vtabs v-model="current" :tabs="tabs" :scroll="false" lineScale="0.2" @change="changeTab" activeColor="#527739" lineColor="#527739" bgColor="#ffffff" height="80rpx" :fixed="true"></vtabs>
		<view class="content">
			<view class="col" v-for="(item,index) in list" :key="index">
				<video v-if="currentId == item.videoId" style="width: 690rpx;height: 390rpx; display: block;" autoplay="true" :id="'video'+item.videoId" :src="item.video"></video>
				<view @click="play(item.videoId,index)" v-else>
					<image :src="item.img" style="height:390rpx;width:690rpx;display: block;"></image>
					<view class="block">
						<view class="sanjia"></view>
					</view>
				</view>
				<view class="infowrap">
					<view class="lt">
						<view class="name">
							{{item.name}}
						</view>
						<view class="time">
							2023-11-22 15:54
						</view>
					</view>
					<button open-type="share" class="rt">
						<image :src="sharepic" class="sharepic"></image>
					</button>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import sharepic from './images/share.png'
import vtabs from './components/v-tabs/v-tabs.vue';
	export default {
		components: {
		  vtabs
		},
		data() {
			return {
				sharepic,
				list: [],
				currentId: 0,
				scrollH: 0,
				scrollTop: 0,
				height: 0,
				windowHeight: 0,
				current: 0,
				tabs: ['宣传片', '学院视频', '学科介绍']
			}
		},
		onLoad() {
			let that = this
			this.getList()
			// 获取可视区域高度
			uni.getSystemInfo({
				success: function(res) {
					that.windowHeight = res.windowHeight
				}
			})
		},
		onPageScroll(res) {
			// 获取滚动距离
			this.scrollH = res.scrollTop
			// 判断元素是否已经出了可视区
			if (this.scrollH > this.scrollTop || this.scrollH + this.windowHeight < this.scrollTop) {
				const e = uni.createVideoContext("video" + this.currentId, this);
				e.pause()
			}
		},
		onHide() {
			this.currentId = 0
		},
		methods: {
			changeTab(index) {
				// this.current = index
			},
			play(id, i) {
				this.currentId = id
				// 获取当前播放视频 元素距离顶部的高度
				if (this.height == 0) {
					uni.createSelectorQuery().select('.col').boundingClientRect((res) => {
						this.height = res.height
						this.scrollTop = res.height * (i + .5)
					}).exec()
				} else {
					this.scrollTop = this.height * (i + .5)
				}
			},
			getList() {
				this.list = [
					{
						name: '你相信有灵魂伴侣吗',
						img: 'https://t7.baidu.com/it/u=1951548898,3927145&fm=193&f=GIF',
						video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=5544&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
						videoId: '1'
					}, 
					{
						name: '2020 奥斯卡提名动画短片：「勿忘我」',
						img: 'https://t7.baidu.com/it/u=3601447414,1764260638&fm=193&f=GIF',
						video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=184884&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
						videoId: '2'
					}, 
					{
						name: '2020 奥斯卡最佳动画短片提名：「女儿」',
						img: 'https://t7.baidu.com/it/u=695301425,3518772921&fm=193&f=GIF',
						video: 'https://baobab.kaiyanapp.com/api/v1/playUrl?vid=186094&resourceType=video&editionType=default&source=aliyun&playUrlType=url_oss&ptl=true',
						videoId: '3'
					}
				]
			}
		}
	}
</script>

<style scoped lang="scss">
	
	.content {
		padding: 30rpx;
	}
	
	.infowrap{
		border-radius: 0 0 10px 10px;
		background-color: #FFFFFF;
		padding:10px;
		display: flex;
		align-items: center;
		.lt{
			flex: 1;
			margin-right:20rpx;
			.name{
				font-size:32rpx;
				color:#333333;
				font-weight:bold;
			}
			.time{
				color:#999999;
				margin-top:8rpx;
			}
		}
		.rt{
			
		}
		.sharepic{
			width:40rpx;
			height:40rpx;
			display: block;
		}
	}
	
	.col {
		overflow: hidden;
		position: relative;
		overflow: hidden;
		margin-bottom: 30rpx;
		border-radius: 10px 10px 0 0;
		.block {
			position: absolute;
			width: 100%;
			height: 390rpx;
			background-color: rgba($color: #000000, $alpha: .3);
			left: 0;
			top: 0;
			display: flex;
			justify-content: center;
			align-items: center;

			.sanjia {
				width: 0;
				height: 0;
				border-top: 12px solid transparent;
				border-left: 17px solid #FFFFFF;
				border-bottom: 12px solid transparent;
			}
		}
	}
</style>

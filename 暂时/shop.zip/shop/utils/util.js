const app = getApp();
function geturl(a) {
    return app.d.hostUrl + a
}
function post(b, c, d) {
  wx.showLoading({
    title: "加载中",
  });
  var a = c;
  a.token = app.d.token;
  wx.request({
    url: geturl(b),
    header: {
      "content-type": "application/x-www-form-urlencoded"
    },
    method: "post",
    data: a,
    success: function (e) {
      if (e.data.status == "1") {
        d(e)
      } else {
        wx.showToast({
          title: e.data.info,
          icon: "none",
          duration: 4000
        });
        wx.hideLoading()
      }
    },
    fail: function (e) {
      wx.showToast({
        title: "网络连接错误",
        icon: "none",
        duration: 2000
      });
      wx.hideLoading()
    }
  })
} 
function postSub(b, c, d) {
 
  var a = c;
  a.token = app.d.token;
  wx.request({
    url: geturl(b),
    header: {
      "content-type": "application/x-www-form-urlencoded"
    },
    method: "post",
    data: a,
    success: function (e) {
      if (e.data.status == "1") {
        d(e)
      } else {
        wx.showToast({
          title: e.data.info,
          icon: "none",
          duration: 4000
        });
     
      }
    },
    fail: function (e) {
      wx.showToast({
        title: "网络连接错误",
        icon: "none",
        duration: 2000
      });
      wx.hideLoading()
    }
  })
}
function get(a, b) {
    wx.showLoading({
        title: "加载中",
    });
    wx.request({
        url: geturl(a),
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        method: "get",
        success: function(c) {
            if (c.data.status == "1") {
                b(c)
            } else {
                wx.showToast({
                    title: c.data.info,
                    icon: "none",
                    duration: 2000
                });
                wx.hideLoading()
            }
        },
        fail: function(c) {
            wx.showToast({
                title: "网络连接错误",
                icon: "none",
                duration: 2000
            });
            wx.hideLoading()
        }
    })
}
module.exports = {
    post: post,
    get: get,
  postSub: postSub
};
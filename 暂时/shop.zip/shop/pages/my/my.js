import {post} from '../../utils/util.js';
const app = getApp()
Page({

  data: {
    judLogin:'',
    wait:0,
    pay:0,
    ship:0,
    success:0,
    data:''
   },
  onShow: function () {
    this.setData({
      judLogin: app.d.judLogin
    })
    
    this.getData();
  },
  getData() {
    var that = this;
   post('ucenter/index',{},function(res){
         wx.hideLoading()
         that.setData({
           data:res.data.data,
            wait: res.data.tab.wait,
            pay: res.data.tab.pay,
            ship: res.data.tab.ship,
            success: res.data.tab.success
          })
     })
  }, 
  callPhone:function(){
    wx.makePhoneCall({
      phoneNumber: '‭17615835043'
    })
  },
  goLogin(){
    wx.navigateTo({
      url: '/pages/login/login'
    })
  },
  onPullDownRefresh: function () {
    this.getData();
  },
  goAgent(){
    wx.navigateTo({
      url: '/pages/agent/agent',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  }
})
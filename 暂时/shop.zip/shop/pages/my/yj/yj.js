import { post } from '../../../utils/util.js';
let page =1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: '',
    isLoadingMore:false,
    count:0,
    brokerage_type:'invite'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    page =1;
      this.getData()
  },
  order(e){
    page = 1;
    this.setData({brokerage_type: e.currentTarget.dataset.order});
    this.getData();
  },
  onReachBottom: function () {
    if (this.data.isLoadingMore) {
      return;
    }
    page++;

    if (page > this.data.count) {
      wx.showToast({
        title: '没有更多了',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    this.setData({ isLoadingMore: true })
    this.getData()
  },
  getData() {
    var that = this;
    post('ucenter/broke', { page, brokerage_type: that.data.brokerage_type}, function (res) {
      wx.hideLoading()
      let data = that.data.data
      if(that.data.isLoadingMore){
        data = data.concat(res.data.data)
      }else {
        data = res.data.data
      }
      that.setData({ data,isLoadingMore:false,count:res.data.ye })
    })

  },
  lingqu(e){
    let id = e.currentTarget.dataset.id;
    let that =this;
    post('ucenter/usebrokerage', { id }, function (res) {
      wx.hideLoading();
      that.setData({isLoadingMore:false});
      page =1;
      that.getData();
    })
    console.log(e.currentTarget.dataset.id)
  }
})
let page = 1;
import {post} from '../../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order: 'pay',
    data: '',
    count:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    page = 1;
    that.getOrder(page, false);

  },
  order(e) {
    this.setData({ order: e.currentTarget.dataset.order });
    page = 1;
    this.getOrder(page, false);
  },
  onReachBottom: function () {
    page++;
    if (page > this.data.count) {
      wx.showToast({
        title: '没有更多了',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    this.getOrder(page, true)
  },
  getOrder(page, state) {
    let that = this;
    let vales = { page: page, type: that.data.order}
      post('ucenter/tuan',vales,function(res){
         wx.hideLoading()
           if (res.data.data == null) {
            wx.showToast({
              title: res.data.info,
              icon: 'none',
              duration: 2000
            })
            return;
          }
          if (state) {
            that.setData({ data: that.data.data.concat(res.data.data),count:res.data.ye });
            return;
          } 
          that.setData({ data: res.data.data, count: res.data.ye});
     })
  
  },
  pay(e) {
    wx.navigateTo({
      url: '/pages/ptDetails/ptDetails?order_no=' + e.target.dataset.orderno + '&mai=' + true
    })
  },
  wuliu(e) {
    wx.navigateTo({
      url: '/pages/wuliu/wuliu?wuliu=' + e.target.dataset.kuaidi
    })
  },
  queren(e) {
    let that = this;
    post('ucenter/doorder',{ id: e.target.dataset.id,status: e.target.dataset.state},function(res){
         wx.hideLoading()
       wx.showToast({
        title: {'success': '确认收货成功', 'delete': '取消订单成功', 'refund':'退款已提交'}[e.target.dataset.state],
        icon: 'success',
        duration: 2000
          })
          setTimeout(function () {
            wx.switchTab({ url: '/pages/my/my' });
          }, 1000)
     })
  },
  creatErm(e) {
    wx.navigateTo({
      url: '/pages/main/index?url=' + e.target.dataset.url
    })
  }
})
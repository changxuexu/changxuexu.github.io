import { post } from '../../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    setTimeout(()=>{
      this.getData()
    },1000)
    // this.getData()
  },
  getData() {
    var that = this;
    post('ucenter/jiami', {}, function (res) {
      wx.hideLoading()
      that.setData({ data: res.data.data })
    })

  },
  dowimg(){
    console.log(this.data.data)
    let that = this;
    wx.downloadFile({
      url: that.data.data,
      success: function (res) {
    wx.saveImageToPhotosAlbum({
      filePath: res.tempFilePath,
      success(res) {
        wx.showToast({
          title: '保存图片成功',
          icon: 'success',
          duration: 2000
        })

      }, fail(err) {
        console.log(err)
        if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {

          wx.openSetting({
            success(settingdata) {
              if (settingdata.authSetting['scope.writePhotosAlbum']) {
                console.log('获取权限成功，给出再次点击图片保存到相册的提示。')
              } else {
                console.log('获取权限失败，给出不给权限就无法正常使用的提示')
              }
            }
          })
        }

      }
    })
      }
      })
  }
})
import {post} from '../../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
      data:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData()
  },
  getData() {
    var that = this;
    post('ucenter/account',{page: 1},function(res){
         wx.hideLoading()
           that.setData({data:res.data.data})
     })
  
  }
})
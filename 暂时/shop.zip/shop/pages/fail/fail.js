// pages/fail/fail.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order_no: ''
  },
  onLoad: function (options) {
    this.setData({ order_no: options.orderno })
  },
  gopay() {
    wx.navigateBack({
      delta: 1
    })
  }
})
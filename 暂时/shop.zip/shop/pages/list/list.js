import {post} from '../../utils/util.js';
let page = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
     list:[] ,
     id:'',
     count:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    page=1;
    this.setData({ id: options.id, title: options.title})
    wx.setNavigationBarTitle({
      title: options.title,
    })  
    this.getList(page,false)
  },
  onReachBottom: function () {
    page++;
    if(page>this.data.count){
      wx.showToast({
        title: '没有更多了',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    this.getList(page, true)
  },
  getList(page,state){
    var that = this;
      post('index/goods',{  cid: that.data.id,size: 10,page: page},function(res){
         wx.hideLoading()
          if (res.data.data == null) {
            wx.showToast({
              title: res.data.info,
              icon: 'none',
              duration: 2000
            })
            return;
          }
          if (state) {
            that.setData({ list: that.data.list.concat(res.data.data),count:res.data.ye });
            return;
          }
          that.setData({ list: res.data.data, count: res.data.ye });
     })
  },
  onPullDownRefresh: function () {
    this.getList(1, false)
  },
  onShareAppMessage: function () {
    return {
      title: this.data.title,
      path: '/pages/list/list'
    }
  }
})
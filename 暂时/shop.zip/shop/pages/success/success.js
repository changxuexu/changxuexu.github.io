// pages/success/success.js
Page({
  data: {
    order_no: '',
    tuan:''
  },
  onLoad: function (options) {
    this.setData({ order_no: options.orderno, tuan: options.tuan})
  },
  goIndex: function () {
    if(this.data.tuan){
      wx.navigateTo({
        url: '/pages/ptDetails/ptDetails?order_no='+this.data.order_no+'&mai='+true
      })
      return;
    }
    wx.switchTab({ url: '/pages/index/index' });
  }
})
import {post} from '../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
      data:'',
      hour:'',
      min:'',
      second:'',
      num: 1,
      // 使用data数据对象设置样式名  
      minusStatus: 'disabled',
      tuan_num: '',
      spec:'',
      order_no:'',
      mai:'',
      specPice:'',
      goods_group_id:''
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.setData({ order_no: options.order_no})
    if (options.mai){
      that.setData({ mai: options.mai })
    }
    if (options.goods_group_id) {
      that.setData({ goods_group_id: options.goods_group_id })
    }
    post('index/showgroup',{ order_no: options.order_no},function(res){
         wx.hideLoading()
           let spc = res.data.data.spec;
          for (let i in spc) {
            spc[i].xunzhong = false;
          }
          that.timer = setInterval(function(){
            if (parseInt(res.data.data.group_end_time) - Date.parse(new Date()) / 1000 > 0){
              let time = that.sec_to_time(parseInt(res.data.data.group_end_time) - Date.parse(new Date()) / 1000);
              that.setData({ hour: time.hour ? time.hour : 0, min: time.min ? time.min : 0, second: time.second ? time.second:0}); 
            } else {
              clearInterval(that.timer );
            }
          },1000)
          that.setData({ data: res.data.data, spec: spc, specPice: res.data.data.goods.goods_price});
     })
  },
  sec_to_time(second_time) {
    var second;
    var hour ;
    var min;
    var day 
    if (parseInt(second_time) > 60) {
        second = parseInt(second_time) % 60;
       min = parseInt(second_time / 60);
     if (min > 60) {
        min = parseInt(second_time / 60) % 60;
         hour = parseInt(parseInt(second_time / 60) / 60);
        if (hour > 24) {
          hour = parseInt(parseInt(second_time / 60) / 60) % 24;
          day = parseInt(parseInt(parseInt(second_time / 60) / 60) / 24);
        
        }
      }
    }
    return { hour, min, second};
  },
  //显示对话框
  showModal: function (e) {
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
  addorder() {
    let that = this;
    let spc = this.data.spec;
    let sp_log = '';
    for (let i in spc) {
      if (spc[i].xunzhong == true) {
        sp_log = spc[i].sp_log
      }
    }
    that.hideModal()
    post('order/realbuy',{ goods_id: that.data.data.goods.goods_id,sp_log: sp_log,type: 'group',buy_num: that.data.num,group_order_no:that.data.order_no,goods_group_id: that.data.goods_group_id},function(res){
         wx.hideLoading()
          wx.navigateTo({
            url: '/pages/pay/pay?id=' + res.data.oid + '&tuan=' + true
          })
     })
  },
  qiehuan(e) {
    let spc = this.data.spec;
    for (let i in spc) {
      if (spc[i].id == e.currentTarget.dataset.id) {

        spc[i].xunzhong = !spc[i].xunzhong;
      } else {
        spc[i].xunzhong = false;
      }
    }
    this.setData({ spec: spc, specPice: e.currentTarget.dataset.tuanpice })
  },
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减  
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1  
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回  
    this.setData({
      num: num
    });
  },
  zhuanfa(){
    return {
      title: this.data.data.goods.goods_title,

      path: `/pages/ptDetails/ptDetails?order_no=${this.data.order_no}&goods_group_id=${this.data.goods_group_id}`

    }
  },
   onShareAppMessage: function () {
    return {
      title: this.data.data.goods.goods_title,
      path: `/pages/ptDetails/ptDetails?order_no=${this.data.order_no}&goods_group_id=${this.data.goods_group_id}`

    }
  }
})
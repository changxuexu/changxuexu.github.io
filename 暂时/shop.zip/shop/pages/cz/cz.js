import {post} from '../../utils/util.js';
let app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:'',
    yu:null,
    judLogin: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      judLogin: app.d.judLogin
    })
    this.getData()
  },
  getData() {
    var that = this;
     post('ucenter/yu',{},function(res){
       wx.hideLoading()
        let data=res.data.data;
          for(let i in data){
            data[i].state = false
          }
          data[0].state = true; 
          that.setData({
            data:data,
            yu:res.data.yu
          })
     })
  }, 
  xuanzhe(e){
    for (let i in this.data.data){
      if (e.currentTarget.dataset.index == i){
        this.data.data[i].state = true;
      } else {
        this.data.data[i].state = false;
      }
    }
    this.setData({ data: this.data.data})
  
  },
  cz(){
    let id= '';
    for (let i in this.data.data) {
      if (this.data.data[i].state) {
        id = this.data.data[i].id;
        break
      }
    }
    var that = this;
      post('pay/recharge',{id:id},function(res){
         wx.hideLoading()
          app.wx_pay(res.data.data,'','','')
     })
    //  wx.request({
    //   url: app.d.hostUrl + "pay/recharge", //仅为示例，并非真实的接口地址
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded'
    //   },
    //   data: {
    //     token: app.d.token,
    //     id:id
    //   },
    //   method: 'post',
    //   success: function (res) {
    //     if (res.data.status == '1') {
    //       app.wx_pay(res.data.data,'','','')
    //     } else {
    //       wx.showToast({
    //         title: res.data.info,
    //         icon: 'none',
    //         duration: 2000
    //       })
    //     }

    //   }
    // })
  }
 
})
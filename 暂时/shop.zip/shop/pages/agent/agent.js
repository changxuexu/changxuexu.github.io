import {post} from '../../utils/util.js';
let app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   this.getData();
  },
 getData(){
   post('agents/agents',{},(res)=>{
     wx.hideLoading();
     this.setData({ data: res.data.data, content: res.data.data.content.replace(/\<img/g, '<img style="max-width:100%;height:auto;display:block"')})
   })
 },
  formSubmit (e) {
    post('pay/buy_agents', { id: this.data.data.id, ...e.detail.value},(res)=>{
      wx.hideLoading();
      app.wx_pay(res.data.data, '', '', '')
    })

  }
})
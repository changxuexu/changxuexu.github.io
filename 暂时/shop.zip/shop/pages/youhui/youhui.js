import {post} from '../../utils/util.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    order: 'notuse',
    data: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    let that = this;
    that.getOrder();
  },
  order(e) {
    this.setData({ order: e.currentTarget.dataset.order });
    this.getOrder();
  },
  getOrder() {
    let that = this;
   
    let vales = { status:that.data.order }
   post('ucenter/mycoupon',vales,function(res){
       wx.hideLoading()
          that.setData({ data: res.data.data });
        
     })
  },
  goIndex: function () {
    wx.switchTab({ url: '/pages/index/index' });
  },
  goBack:function(){
    wx.navigateBack({
      delta: 1
    })
    
  }
})
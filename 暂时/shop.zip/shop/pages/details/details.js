import { post, postSub} from '../../utils/util.js';
let page =1;
const app = getApp();
Page({
  data: {
    tab:true,
     goods_content: [],
     spec:[],
     goods_id:'',
     goods_price:'0.00',
    goods_photo:'',
    goods_title: '',
    goods_market_price:'0.00',
    num: 1,
    // 使用data数据对象设置样式名  
    minusStatus: 'disabled',
    jilu:'',
    youfei:'',
   carCount:0,
    winWidth:0,
    winHeight:0,
    mode:false,
    showTosts:false,
    tostNum:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
    var that = this;
    if (options.pid) {
      app.d.pid = options.pid;
    }
    wx.getSystemInfo({
      success(res) {
        that.setData({ winWidth: res.windowWidth, winHeight: res.windowHeight})
      }
    })
    that.setData({ id: options.id });
    that.getCarCount();
    

      that.getjyjl();
      that.getData();

  },
  getData(){
    let that =this;
    post('index/detail', { id: that.data.id }, function (res) {
      wx.hideLoading()
      let spc = res.data.data.spec;
      for (let i in spc) {
        spc[i].xunzhong = false;
      }
      that.setData({
        data: res.data.data,
        service_show: res.data.data.service_show,
        goods_content: res.data.data.goods_content,
        goods_photo: res.data.data.goods_photo,
        goods_title: res.data.data.goods_title,
        spec: res.data.data.spec,
        goods_id: that.data.id,
        goods_price: res.data.data.goods_price,
        goods_market_price: res.data.data.goods_market_price,
        goods_logistics: res.data.data.goods_logistics,
        goods_all_sales_count: res.data.data.goods_all_sales_count,
        youfei: res.data.data.sub || ''
      });
      wx.setNavigationBarTitle({
        title: res.data.data.goods_title,
      })
      setTimeout((res)=>{
        that.getImage();
      },1000)
      
    })
  },
  getImage(){
    let path = `pages/details/details?id=${this.data.goods_id}&pid=`
    post('ucenter/detailqrcode',{path},(res)=>{
      wx.hideLoading();
      let left = 20+parseInt(this.data.goods_price).toString().length*20;
      this.setData({
        pading: {
          width: 375,
          height: 540,
          views: [
            {
              type: 'rect',
              background:'#fff',
              top: 0,
              left: 0,
              width: 375,
              height: 540
            },
            {
              type: 'image',
              url: this.data.goods_photo[0],
              top: 0,
              left: 0,
              width: 375,
              height: 375
            },
            {
              type: 'image',
              url: res.data.data,
              top: 375,
              left: 240,
              width: 125,
              height: 125
            },
            {
              type: 'text',
              content: '扫描/长按识别二维码',
              fontSize: 12,
              color: '#999',
              textAlign: 'left',
           
            
              MaxLineNumber: 1,
              lineHeight: 26,
              width: 200,
              top: 510,
              left: 240
            },
            {
              type: 'text',
              content: this.data.goods_title,
              fontSize: 18,
              color: '#000',
              textAlign: 'left',
              bolder:true,
              breakWord:true,
              MaxLineNumber:3,
              lineHeight:26,
              width: 200,
              top: 375,
              left: 10
            },
            {
              type: 'text',
              content: '¥',
              fontSize: 14,
              color: '#f00',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,

              top: 475,
              left: 10
            }, {
              type: 'text',
              content: `${parseInt(this.data.goods_price)}`,
              fontSize: 26,
              color: '#f00',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,
              top: 465,
              left: 20
            },
            {
              type: 'text',
              content: `¥${parseInt(this.data.goods_market_price)}`,
              fontSize: 12,
              color: '#999',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,
              textDecoration:'line-through',
              top: 475,
              left: left
            }
          ]
        }
      })

    })
  },
  eventSave() {
    let that =this;
    wx.saveImageToPhotosAlbum({
      filePath: that.data.shareImage,
      success(res) {
        wx.showToast({
          title: '保存图片成功',
          icon: 'success',
          duration: 2000
        })
       
      }, fail(err) {
        if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
         
          wx.openSetting({
            success(settingdata) {
              if (settingdata.authSetting['scope.writePhotosAlbum']) {
                console.log('获取权限成功，给出再次点击图片保存到相册的提示。')
              } else {
                console.log('获取权限失败，给出不给权限就无法正常使用的提示')
              }
            }
          })
        }
       
      }
    })
  },
  eventGetImage(event) {
    wx.hideLoading()
    const { tempFilePath, errMsg } = event.detail
    if (errMsg === 'canvasdrawer:ok') {
      this.setData({
        shareImage: tempFilePath
      })
    }
  },
  qidong(){
    this.setData({
      mode: true
    })
  },
  guanbi(){
    this.setData({
      mode:false
    })
  },
  setInt(){
    let tostNum = this.data.tostNum;
    setInterval(() => {
      if (this.data.jilu.length != 0) {
        if (tostNum + 1 >= this.data.jilu.length) {
          tostNum = 0;
        } else {
          tostNum++;
        }
        this.setData({ tostNum})
        this.settime();
      }
    }, 7000);

  },
  settime  (){
    this.setData({  showTosts: true });
    setTimeout(() => {
      this.setData({ showTosts: false });
    }, 5000);
  },
  guanzhu(e){
    postSub('ucenter/collect', { goods_id:this.data.goods_id},(res)=>{
      this.getData();
    })
  },
  getjyjl(page, state) {
    let that = this;
    post('index/gpcjlist', {}, function (res) {
    
      wx.hideLoading()
     
      that.setData({
        jilu: res.data.data
      });
      that.setInt();
    })
  },
  qiehuan(e){
    let spc = this.data.spec;
    for (let i in spc){
      if (spc[i].id == e.currentTarget.dataset.id ){
        spc[i].xunzhong = !spc[i].xunzhong;
      } else {
        spc[i].xunzhong = false;
      }
    }
    this.setData({ spec: spc, goods_price: e.currentTarget.dataset.goods_price})
  },
  //显示对话框
  showModal: function (e) {

    this.setData({ xztj: e.currentTarget.dataset.cart});
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },

  tabde(){
    let tabs= !this.data.tab;
    this.setData({
      tab: tabs
    })
  },
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减  
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1  
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回  
    this.setData({
      num: num
    });
  },
  addorder(){
    if (app.d.judLogin != 1) {
      wx.navigateTo({
        url: '/pages/login/login'
      })
      return;
    }
    let that = this;
    let spc = that.data.spec;
    let sp_log ='';
    for (let i in spc) {
      if (spc[i].xunzhong == true) {
        sp_log = spc[i].sp_log
      } 
    }
    that.hideModal()
    postSub('order/realbuy',{ goods_id: that.data.goods_id,sp_log: sp_log,type: that.data.xztj,buy_num: that.data.num,},function(res){
       
         if (that.data.xztj=='car'){
            wx.showToast({
              title: '加入购物车成功',
              icon: 'success',
              duration: 2000
            })
            that.getCarCount()
          } else {
            wx.navigateTo({
              url: '/pages/pay/pay?id='+res.data.oid
            })
          }
     })
  },
  getCarCount(){
    let that = this;
     post('index/gou',{},function(res){
       wx.hideLoading()
         that.setData({carCount:res.data.data});
     })
  },
  onShareAppMessage: function () {
    return {
      title: this.data.title,
      path: '/pages/details/details?title=' + this.data.title + '&id=' + this.data.id
    }
  }
  

})
// pages/checkrest/checkrest.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      data:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     this.setData({ data: JSON.parse(options.data)})
  },
  cheeackyouhui(e) {
    let that = this;
    // console.log(e.currentTarget.dataset.name)
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2]
    if(e.currentTarget.dataset.name =='self'){
      prevPage.setData({
        ziti: true,
      })
    }
    
    prevPage.setData({
      name: e.currentTarget.dataset.name,
    })
    wx.navigateBack({
      delta: 1
    })
  }
})
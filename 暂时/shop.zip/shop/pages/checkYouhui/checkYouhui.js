
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ data: JSON.parse(options.data), oid: options.oid})
  },
  goIndex(e){
    let that = this;
    // console.log(e.currentTarget.dataset.qid)
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2]
    prevPage.setData({
      qid: e.currentTarget.dataset.qid
    })
    wx.navigateBack({
              delta: 1
            })
  }
})
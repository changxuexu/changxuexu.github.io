import { post, get } from '../../utils/util.js';
const app = getApp();
Page({
  data: {
    'hai_truename':'',
    'hai_card_no':'',
    haicardright:'',
    haicardrightsrc:'', //图片正面地址
    haicardleft:'',
    haicardleftsrc: ''//图片反面地址
  },
  onLoad: function (options) {
    this.init()
  },
  submithhandle(){
    let hai_truename = this.data.hai_truename
    let hai_card_no = this.data.hai_card_no
    let hai_card_right = this.data.haicardright
    let hai_card_left = this.data.haicardleft
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if (!hai_truename){
      this.showtips('请填写身份证上的姓名')
      return
    } 
    if (!reg.test(hai_card_no)) {
      this.showtips('请填写正确的身份证号')
      return
    }
    if (!hai_card_right) {
      this.showtips('请上传身份证正面')
      return
    }
    if (!hai_card_left) {
      this.showtips('请上传身份证反面')
      return
    }
    post('ucenter/goautonym', {
      hai_truename,
      hai_card_no,
      hai_card_right,
      hai_card_left
    }, (res) => {
      let { data, status } = res.data
      if (status == "1") {
        this.showtips('个人信息认证成功')
        setTimeout(()=>{
          wx.navigateBack({
            delta:1
          })
        },1000)
      }else{
        this.showtips('个人信息认证失败')
      }
    })
  },
  init(){
    post('ucenter/myautonym', { }, (res) => {
      let { data, status} = res.data
      if (status=="1"){
        this.setData({
          'hai_truename':data['hai_truename'],
          'hai_card_no': data['hai_card_no'],
          'haicardright': data['hai_card_right'],
          'haicardrightsrc': data['hai_card_rights']['img'],
          'haicardleft': data['hai_card_left'],
          'haicardleftsrc': data['hai_card_lefts']['img'],
        })
      }
      wx.hideLoading()
    })
  },
  uploadzhengmianhandle(e) {
    let _this = this;
    let id = e.currentTarget.dataset['id']
    wx.chooseImage({
      success(res) {
        const tempFilePaths = res.tempFilePaths
        // console.log("tempFilePaths=", tempFilePaths)
        wx.uploadFile({
          url: app.d.hostUrl + 'public/uploadPicture',
          filePath: tempFilePaths[0],
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data",
          },
          formData: {},
          success(res) {
            console.log(JSON.parse(res.data))
            let { status, data } = JSON.parse(res.data)
            if (status == 1){
              if (id == '1') {
                _this.setData({
                  haicardright: data.id,
                  haicardrightsrc: data.src
                })
              } else if (id == '0') {
                _this.setData({
                  haicardleft: data.id,
                  haicardleftsrc: data.src
                })
              }
            }
            
          }
        })
      }
    })
  },
  truenamehandle(e){
    let value = e.detail.value
    this.setData({
      'hai_truename': value
    })
  },
  cardnumhandle(e){
    let value = e.detail.value
    this.setData({
      'hai_card_no': value
    })
  },
  showtips(tips) {
    wx.showToast({
      title: tips,
      icon: "none",
      duration: 1500
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
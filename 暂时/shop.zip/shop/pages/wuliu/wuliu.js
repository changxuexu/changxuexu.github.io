const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wuliu:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData(options.wuliu)
  },
  getData(wuliu) {
    var that = this;
    post('ucenter/get_expressop',{  expressno: wuliu},function(res){
       wx.hideLoading()
        that.setData({wuliu:res.data.data.data})
     })
  }
})
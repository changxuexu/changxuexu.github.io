import {post} from '../../utils/util.js';
const app= getApp();
Page({
  data: {
    data:'',
    coupon:'',
    order_exhort:'',
    goods_group_id:'',
    qid:'',
    isAllSelect:false,
    is_self:0,
    is_card:0,
    tuan:'',
    rest:'',
    name:'',
    ziti:false,
    zitis:[],
    branch_id:''
  },
  onLoad: function (opt) {
    var that = this;
    that.setData({oid:opt.id})
    if (opt.tuan){
      that.setData({ tuan: opt.tuan })
    }
   
  },
  onShow:function(){
    var that = this;
    that.getorder();
  },
 getorder(){
   var that = this;
   let values = {
     oid: that.data.oid,
     is_self:that.data.is_self
     }
   if(that.data.qid){
     values.qid = that.data.qid
   }
   if (that.data.name) {
     values.pd = that.data.name
   }
   if (that.data.branch_id) {
     values.branch_id = that.data.branch_id
   }
     post('order/center',values,function(res){
         wx.hideLoading()
       that.setData({ data: res.data.data, coupon: res.data.coupon, rest: res.data.rest});
       if (res.data.data.order_logistics =='self'){
         that.setData({ziti:true})
       } else {
         that.setData({ ziti: false })
       }
     })
 },
  pay:function(){
    app.pays(this.data.data.order_no, { order_exhort: this.data.order_exhort, user_card: this.data.user_card},'',this.data.tuan);
  },
  chooseAddress(){
    var that = this;
    wx.chooseAddress({
        success: function (res) {
          post('order/editaddress',{ truename: res.userName,mobile: res.telNumber,province: res.provinceName,city: res.cityName,district: res.countyName,address: res.detailInfo,},function(res){
          wx.hideLoading()
          
        })
        }
    })
  },
  cheackrest() {
    wx.navigateTo({
      url: '/pages/checkrest/checkrest?data=' + JSON.stringify(this.data.rest)
    })
  },
  cheackyouhui(){
    wx.navigateTo({
      url: '/pages/checkYouhui/checkYouhui?oid=' + this.data.oid+'&data=' + JSON.stringify(this.data.coupon)
    })
  },
  cheackziti(){
    wx.navigateTo({
      url: '/pages/checkziti/checkziti?data=' + JSON.stringify(this.data.zitis)
    })
  },
  bindKeyInput (e) {
    this.setData({
      order_exhort: e.detail.value
    })
  },
  bindKeyInputCard(e) {
    this.setData({
      user_card: e.detail.value
    })
  },
  allSelect: function () {
    let status = '';
    this.setData({
      isAllSelect: !this.data.isAllSelect,
    })
    if (this.data.isAllSelect){
      status=1;
    } else {
      status = 0;
    }
    this.setData({ is_self: status})
    this.getorder()
  }
  
})  
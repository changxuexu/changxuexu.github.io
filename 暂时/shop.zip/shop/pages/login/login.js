// pages/login/login.js
const app = getApp();
Page({

  data: {
    flag: true,
    store:''
  },
  onLoad(){
        this.setData({store:app.d.store})
  },
  goLogin:function(e){
   let that = this;
   wx.getSetting({
     success: function (res) {
       if (res.authSetting['scope.userInfo']) {
         // 已经授权，可以直接调用 getUserInfo 获取头像昵称
         wx.getUserInfo({
           success: function (res) {
             wx.request({
               url: app.d.hostUrl + "user/userinfo", //仅为示例，并非真实的接口地址
               header: {
                 'content-type': 'application/x-www-form-urlencoded'
               },
               data: {
                 token: app.d.token,
                 nickname: res.userInfo.nickName,
                 avatar: res.userInfo.avatarUrl,
                 pid:app.d.pid
               },
               method: 'post',
               success: function (res) {
                 if (res.data.status == '1') {
                   that.setData({ flag: false })
                  
                 } else if (res.data.status == '3'){
                   that.setData({ flag: false })
                 }else {
                   wx.showToast({
                     title: res.data.info,
                     icon: 'none',
                     duration: 2000
                   })
                 }
               }
             })
           }
         })
       }
     }
   })
  
  },
  jujue(){
    wx.switchTab({
      url: '/pages/index/index'
    })
  },
  show: function () {
    this.setData({ flag: false })
  },

  hide: function () {
    this.setData({ flag: true })
  },
  goPhone(e){
    let that = this;
      wx.request({
        url: app.d.hostUrl + "user/getphone", //仅为示例，并非真实的接口地址
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        data: {
          token: app.d.token,
          session_key: app.d.session,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv
        },
        method: 'post',
        success: function (res) {
          if (res.data.status == '1') {
            that.setData({ flag: true })
             wx.navigateBack({
               delta: 1
             })
             app.d.judLogin='1';
          } else {
            wx.showToast({
              title: res.data.info,
              icon: 'none',
              duration: 2000
            })
          }
        }
      })
  }
  
})
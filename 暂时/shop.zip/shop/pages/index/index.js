import {post,get} from '../../utils/util.js';
const timer = require("./wxTimer.js")
const app = getApp();
let page =1;
Page({
  data: {
    lunbo:[],
    Category:[],
    card:'',
    tuan:'',
    list:'',
    miao:[],
    tuan:[],
    mai: [], 
    conpanBannner:'',
    list:[],
    count:0,
    miaoend: '',
    isLoadingMore:false,
    wxTimerList: {},
    endTime: '2021-11-22 10:40:30'
  },
  onLoad: function (options) {
    if (options.pid){
      app.d.pid = options.pid;
    }
    page=1;
   this.getList();
   this.getData();
    
    // var beginTime = this.dateFormater('YYYY-MM-DD HH:mm:ss', 1591113300)
    // console.log("beginTime=", beginTime)
  },
  dateFormater(formater, t) {
    //兼容IE  Date.parse(t.replace(/-/g, "/"))
    let date = t ? new Date(t) : new Date()
    let Y = date.getFullYear() + ''
    let M = date.getMonth() + 1
    let D = date.getDate()
    let H = date.getHours()
    let m = date.getMinutes()
    let s = date.getSeconds()
    return formater.replace(/YYYY|yyyy/g, Y)
      .replace(/YY|yy/g, Y.substr(2, 2))
      .replace(/MM/g, (M < 10 ? '0' : '') + M)
      .replace(/DD/g, (D < 10 ? '0' : '') + D)
      .replace(/HH|hh/g, (H < 10 ? '0' : '') + H)
      .replace(/mm/g, (m < 10 ? '0' : '') + m)
      .replace(/ss/g, (s < 10 ? '0' : '') + s)
  },
  // 倒计时
  countDown:function(){
    var that=this;
    var nowTime = new Date().getTime();//现在时间（时间戳）
    // var miaoend = that.data.miaoend;//结束时间（时间戳）

    var miaoend = new Date('2020-5-18 10:40:30').getTime();//结束时间（时间戳）

    //距离结束的毫秒数
    var time = (miaoend-nowTime)/1000;
    // 获取天、时、分、秒
    let day = parseInt(time / (60 * 60 * 24));
    let hou = parseInt(time % (60 * 60 * 24) / 3600);
    let min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
    let sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
    // console.log(day + "," + hou + "," + min + "," + sec)
    day = that.timeFormin(day),
    hou = that.timeFormin(hou),
    min = that.timeFormin(min),
    sec = that.timeFormin(sec)
    that.setData({
      day: that.timeFormat(day),
      hou: that.timeFormat(hou),
      min: that.timeFormat(min),
      sec: that.timeFormat(sec)
    })
    // 每1000ms刷新一次
    if (time>0){
      that.setData({
        countDown: true
      })
      setTimeout(this.countDown, 1000);
    }else{
      that.setData({
        countDown:false
      })
    }
  },
  //小于10的格式化函数（2变成02）
  timeFormat(param) {
    return param < 10 ? '0' + param : param;
  },
  //小于0的格式化函数（不会出现负数）
  timeFormin(param) {
    return param < 0 ? 0: param;
  },
  getList(){
    var that = this;
    get('index/index', function (res) {

      that.setData({ 
        lunbo: res.data.data.lb, 
        catlistImg: res.data.data.cate, 
        miao:res.data.data.miao,
        tuan:res.data.data.tuan,
        mai: res.data.data.bimai,
        miaoend: res.data.data.miaoend,
        conpanBannner: res.data.data.adv
      },()=>{
        that.countDown()
      });
      
      wx.hideLoading();
      wx.stopPullDownRefresh()
    })
  },
  
  getData(){
    post('index/new_goods',{page},(res)=>{
      let list = this.data.list;
      if(this.data.isLoadingMore){
        list = list.concat(res.data.data.list)
      } else {
        list = res.data.data.list;
      }

      this.setData({ list, count: res.data.data.ye,isLoadingMore:false})
    })
  },
  onReachBottom: function () {
    if(this.data.isLoadingMore){
      return;
    }
    page++;
    
    if (page > this.data.count) {
      wx.showToast({
        title: '没有更多了',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    this.setData({isLoadingMore:true})
    this.getData()
  },
  onShareAppMessage: function () {
    return {
      title: app.d.store.store_name,
      path: '/pages/index/index'
    }
  },
 onPullDownRefresh: function () {
   this.getList();
  },
  guangao(e){
    let item = e.currentTarget.dataset.item;
    let url ='';
    if (item.id==0){
      return;
    }
    if(item.type=='goods'){
      url = `/pages/details/details?id=${item.goods_id}&title=${item.title}`
    } else{
      url = `/pages/list/list?id=${item.goods_id}&title=${item.title}`
    }
    wx.navigateTo({
      url: url,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
    // /pages/details / details ? id = {{ item.id }}& title={{ item.goods_title }}
    console.log(e.currentTarget.dataset.item)
  },
  goNewList(e){
    let item = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: `/pages/list/list?id=${item.id}&title=${item.title}`,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  }
})

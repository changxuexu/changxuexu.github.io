import {post} from '../../utils/util.js';
Page({
  data: {
    isAllSelect: false,
    totalMoney: 0,
    // 商品详情介绍
    carts: ''
  },
  onShow: function () {
    this.getData();
  },
  onHide:function(){
    let that = this;
    let opts = {};
    for (let i in this.data.carts) {
        opts[this.data.carts[i].id] = {
          id: this.data.carts[i].id,
          buy_num: this.data.carts[i].buy_num,
          is_xuan: this.data.carts[i].is_xuan
        }
    }
    post('order/uplcar',{ data: JSON.stringify(opts)},function(res){ wx.hideLoading()})
  },
  //获取数据
  getData() {
    var that = this;
    post('order/carinfo',{},function(res){
       wx.hideLoading()
      if (res.data.data.length!=0){
              that.setData({ carts: res.data.data, isAllSelect: res.data.is_xuans, totalMoney: res.data.price });
      } else{
              that.setData({ carts: '' });
      }
    })
  }, 
  //勾选事件处理函数  
  switchSelect: function (e) {
    // 获取item项的id，和数组的下标值  
    var Allprice = 0, i = 0;
    let id = e.target.dataset.id,

      index = parseInt(e.target.dataset.index);
    if (this.data.carts[index].is_xuan==1){
      this.data.carts[index].is_xuan =0
    } else {
      this.data.carts[index].is_xuan = 1
    }
    //价钱统计
    if (this.data.carts[index].is_xuan==1) {
      this.data.totalMoney = this.data.totalMoney + parseInt(this.data.carts[index].goods_price) * parseInt(this.data.carts[index].buy_num);
    }
    else {
      this.data.totalMoney = this.data.totalMoney - parseInt(this.data.carts[index].goods_price) * parseInt(this.data.carts[index].buy_num);
    }
    //是否全选判断
    for (i = 0; i < this.data.carts.length; i++) {
      Allprice = Allprice + parseInt(this.data.carts[i].goods_price) * parseInt(this.data.carts[i].buy_num);
    }
    if (Allprice == this.data.totalMoney) {
      this.data.isAllSelect = true;
    }
    else {
      this.data.isAllSelect = false;
    }
    this.setData({
      carts: this.data.carts,
      totalMoney: this.data.totalMoney,
      isAllSelect: this.data.isAllSelect,
    })
  },
  //全选
  allSelect: function (e) {
    //处理全选逻辑
    let i = 0;
    let totalMoney =0;
    if (!this.data.isAllSelect) {
      for (i = 0; i < this.data.carts.length; i++) {
        this.data.carts[i].is_xuan = 1;
        totalMoney = totalMoney + parseInt(this.data.carts[i].goods_price) * parseInt(this.data.carts[i].buy_num);
      }
    }
    else {
      for (i = 0; i < this.data.carts.length; i++) {
        this.data.carts[i].is_xuan = 0;
      }
      this.data.totalMoney = 0;
    }
    this.setData({
      carts: this.data.carts,
      isAllSelect: !this.data.isAllSelect,
      totalMoney:totalMoney,
    })
  },
  // 去结算
  toBuy() {
    let that = this;

    let opts = {};
    for (let i in this.data.carts) {
      if (this.data.carts[i].is_xuan == 1) {
        opts[this.data.carts[i].id] = {
          id: this.data.carts[i].id,
          buy_num: this.data.carts[i].buy_num
        }

      }
    }
    post('order/car',{ data: JSON.stringify(opts)},function(res){
       wx.hideLoading()
        wx.navigateTo({
            url: '/pages/pay/pay?id=' + res.data.oid,
          })
    })
  },

  bindMinus: function (e) {
    let index = parseInt(e.target.dataset.index);
    if (this.data.carts[index].buy_num>1){
      this.data.carts[index].buy_num--
      if (this.data.carts[index].is_xuan == 1) {
        this.data.totalMoney = this.data.totalMoney - parseInt(this.data.carts[index].goods_price);
      }
    }
    this.setData({
      carts: this.data.carts,
      totalMoney: this.data.totalMoney,
      isAllSelect: this.data.isAllSelect,
    })
  },
  /* 点击加号 */
  bindPlus: function (e) {
    let index = parseInt(e.target.dataset.index);
    this.data.carts[index].buy_num++
    if (this.data.carts[index].is_xuan == 1) {
      this.data.totalMoney = this.data.totalMoney + parseInt(this.data.carts[index].goods_price);
    }
 this.setData({
   carts: this.data.carts,
   totalMoney: this.data.totalMoney,
   isAllSelect: this.data.isAllSelect,
 })
  },
  delGoods(e){
    let index = parseInt(e.target.dataset.index); 
   
    if (this.data.carts[index].is_xuan == 1) {
      this.data.totalMoney = this.data.totalMoney - parseInt(this.data.carts[index].goods_price) * parseInt(this.data.carts[index].buy_num);
    }
    this.data.carts.splice(index, 1);
    console.log(this.data.carts.length);
    this.setData({
      carts: this.data.carts,
      totalMoney: this.data.totalMoney,
    })
  },
  goIndex: function () {
    wx.switchTab({ url: '/pages/index/index' });
  }
});
import { post } from '../../utils/util.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:'',
    keys:0,
    widthSize:10
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData();
    let that =this;
    wx.getSystemInfo({
      success(res) {
        that.setData({ widthSize: (res.windowWidth/4*3-40)/3})
      }
    })
  },
  getData() {
    post('index/allcate', { }, (res) => {
     wx.hideLoading();
      this.setData({ data:res.data.data})
    })
  },
  clickFirstScreen(e){
    this.setData({ keys: e.currentTarget.dataset.keys})
    // console.log(e.currentTarget.dataset.keys)
  },
  goCatSearch(e){
    let item = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: `/pages/list/list?id=${item.id}&title=${item.title}`,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  }
})
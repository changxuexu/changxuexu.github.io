let page=1;
const app = getApp();
import { post, postSub} from '../../utils/util.js';
Page({
   data: {
    tab: true,
    goods_content: [],
    spec: [],
    goods_id: '',
    goods_price: '0.00',
    goods_photo: '',
    goods_title: '',
    goods_market_price: '0.00',
    num: 1,
    // 使用data数据对象设置样式名  
    minusStatus: 'disabled',
    jilu: '',
    group_over_time:'',
    tuan_num:'',
    youfei:'',
    pt:'',
    goods_group_id:'',
    specPice:0,
     carCount: 0, 
     winWidth: 0,
     winHeight: 0,
     mode: false,
     showTosts: false,
     tostNum: 0
  },

  onLoad: function (options) {
  
    var that = this;
    if (options.pid) {
      app.d.pid = options.pid;
    }
    wx.getSystemInfo({
      success(res) {
        that.setData({ winWidth: res.windowWidth, winHeight: res.windowHeight })
      }
    })
    that.getCarCount()
    that.setData({  id: options.id});
    that.getjyjl(1, false);
     post('index/tdetail',{id: options.id},function(res){
       wx.hideLoading()
         let spc = res.data.data.spec;
          for (let i in spc) {
            spc[i].xunzhong = false;
          }
         
          setInterval(function(){
            let pt = [];
              for(let j in res.data.pt){
                res.data.pt[j].endTime = that.sec_to_time(parseInt(res.data.pt[j].group_end_time) - Date.parse(new Date()) / 1000);
                pt.push(res.data.pt[j])
            }
            let time = parseInt(res.data.data.group_over_time) - Date.parse(new Date())/1000;
            that.setData({ group_over_time: that.sec_to_time(time),pt:res.data.pt})
          },1000)
          that.setData({
            data: res.data.data,
            goods_content: res.data.data.goods_content,
            goods_photo: res.data.data.goods_photo,
            goods_title: res.data.data.goods_title,
            spec: res.data.data.spec,
            goods_id: options.id,
            goods_price: res.data.data.tuan_price,
            goods_market_price: res.data.data.goods_price,
            goods_logistics: res.data.data.goods_logistics,
            goods_all_sales_count: res.data.data.goods_all_sales_count,
            youfei: res.data.data.sub||'',
            tuan_num: res.data.data.tuan_num,
            pt: res.data.pt,
            goods_group_id: res.data.data.goods_group_id,
            service_show: res.data.data.service_show
          });
       wx.setNavigationBarTitle({
         title: res.data.data.goods_title,
       })
       that.getImage();
     })
  },
  getImage() {
    let path = `pages/detailsTuan/detailsTuan?id=${this.data.goods_id}&pid=`
    post('ucenter/detailqrcode', { path }, (res) => {
      wx.hideLoading()
      let left = 20 + parseInt(this.data.goods_price).toString().length * 20;
      this.setData({
        pading: {
          width: 375,
          height: 540,
          views: [
            {
              type: 'rect',
              background: '#fff',
              top: 0,
              left: 0,
              width: 375,
              height: 540
            },
            {
              type: 'image',
              url: this.data.goods_photo[0],
              top: 0,
              left: 0,
              width: 375,
              height: 375
            },
            {
              type: 'image',
              url: res.data.data,
              top: 375,
              left: 240,
              width: 125,
              height: 125
            },
            {
              type: 'text',
              content: '扫描/长按识别二维码',
              fontSize: 12,
              color: '#999',
              textAlign: 'left',


              MaxLineNumber: 1,
              lineHeight: 26,
              width: 200,
              top: 510,
              left: 240
            },
            {
              type: 'text',
              content: this.data.goods_title,
              fontSize: 18,
              color: '#000',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,
              width: 200,
              top: 375,
              left: 10
            },
            {
              type: 'text',
              content: '¥',
              fontSize: 14,
              color: '#f00',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,

              top: 475,
              left: 10
            }, {
              type: 'text',
              content: `${parseInt(this.data.goods_price)}`,
              fontSize: 26,
              color: '#f00',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,
              top: 465,
              left: 20
            },
            {
              type: 'text',
              content: `¥${parseInt(this.data.goods_market_price)}`,
              fontSize: 12,
              color: '#999',
              textAlign: 'left',
              bolder: true,
              breakWord: true,
              MaxLineNumber: 3,
              lineHeight: 26,
              textDecoration: 'line-through',
              top: 475,
              left: left
            }
          ]
        }
      })

    })
  },
  eventSave() {
    wx.saveImageToPhotosAlbum({
      filePath: this.data.shareImage,
      success(res) {
        wx.showToast({
          title: '保存图片成功',
          icon: 'success',
          duration: 2000
        })
      }
    })
  },
  eventGetImage(event) {
    wx.hideLoading()
    const { tempFilePath, errMsg } = event.detail
    if (errMsg === 'canvasdrawer:ok') {
      this.setData({
        shareImage: tempFilePath
      })
    }
  },
  qidong() {
    this.setData({
      mode: true
    })
  },
  guanbi() {
    this.setData({
      mode: false
    })
  },
  setInt() {
    let tostNum = this.data.tostNum;
    setInterval(() => {
      if (this.data.jilu.length != 0) {
        if (tostNum + 1 >= this.data.jilu.length) {
          tostNum = 0;
        } else {
          tostNum++;
        }
        this.setData({ tostNum })
        this.settime();
      }
    }, 7000);

  },
  settime() {
    this.setData({ showTosts: true });
    setTimeout(() => {
      this.setData({ showTosts: false });
    }, 5000);
  },
  guanzhu(e) {
    postSub('ucenter/collect', { goods_id: this.data.goods_id }, (res) => {
      this.getData();
    })
  },
  getjyjl(page, state) {
    let that = this;
    post('index/gpcjlist', {}, function (res) {

      wx.hideLoading()

      that.setData({
        jilu: res.data.data
      });
      that.setInt();
    })
  },
  sec_to_time(second_time) {
   var time = parseInt(second_time) + "秒";
   if (parseInt(second_time) > 60) {

     var second = parseInt(second_time) % 60;
     var min = parseInt(second_time / 60);
     time = min + "分" + second + "秒";

     if (min > 60) {
       min = parseInt(second_time / 60) % 60;
       var hour = parseInt(parseInt(second_time / 60) / 60);
       time = hour + "小时" + min + "分" + second + "秒";

       if (hour > 24) {
         hour = parseInt(parseInt(second_time / 60) / 60) % 24;
         var day = parseInt(parseInt(parseInt(second_time / 60) / 60) / 24);
         time = day + "天" + hour + "小时" + min + "分" + second + "秒";
       }
     }


   }
    return time;  
  },
  qiehuan(e) {
    let spc = this.data.spec;
    let specPice;
    for (let i in spc) {
      if (spc[i].id == e.currentTarget.dataset.id) {

        spc[i].xunzhong = !spc[i].xunzhong;
      } else {
        spc[i].xunzhong = false;
      }
    }
 
    if (this.data.xztj=='buy'){
      specPice = e.currentTarget.dataset.goods_price
    } else {
      specPice = e.currentTarget.dataset.tuan_pice
    }
    this.setData({ spec: spc, specPice: specPice })
  },
  //显示对话框
  showModal: function (e) {
    
    this.setData({ xztj: e.currentTarget.dataset.cart });
    if (e.currentTarget.dataset.cart=='buy'){
      this.setData({ specPice: this.data.goods_market_price });
    } else{
      this.setData({ specPice: this.data.goods_price });
    }
    // 显示遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
      showModalStatus: true
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export()
      })
    }.bind(this), 200)
  },
  //隐藏对话框
  hideModal: function () {
    // 隐藏遮罩层
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step()
    this.setData({
      animationData: animation.export(),
    })
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },
  addorder() {
    if (app.d.judLogin != 1) {
      wx.navigateTo({
        url: '/pages/login/login'
      })
      return;
    }
    let that = this;
    let spc = this.data.spec;
    let sp_log = '';
    for (let i in spc) {
      if (spc[i].xunzhong == true) {
        sp_log = spc[i].sp_log
      }
    }
    this.hideModal()
    let values = {
      goods_id: that.data.goods_id,
      sp_log: sp_log,
      type: that.data.xztj,
      buy_num: that.data.num
    }
    if (that.data.xztj == 'group'){
      values.goods_group_id = that.data.goods_group_id
    }
    postSub('order/realbuy',values,function(res){
      
         let url = '/pages/pay/pay?id=' + res.data.oid;
          if (that.data.xztj == 'group') {
            url = '/pages/pay/pay?id=' + res.data.oid+'&tuan='+true;
          }
          wx.navigateTo({
            url:url
          })
     })

  },
  tabde() {
    let tabs = !this.data.tab;
    this.setData({
      tab: tabs
    })
  },
  bindMinus: function () {
    var num = this.data.num;
    // 如果大于1时，才可以减  
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  /* 点击加号 */
  bindPlus: function () {
    var num = this.data.num;
    // 不作过多考虑自增1  
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态  
    var minusStatus = num < 1 ? 'disabled' : 'normal';
    // 将数值与状态写回  
    this.setData({
      num: num,
      minusStatus: minusStatus
    });
  },
  goptDetail(e){
    wx.navigateTo({
      url: '/pages/ptDetails/ptDetails?order_no=' + e.currentTarget.dataset.order_no + '&goods_group_id=' + this.data.goods_group_id
    })
  },
  /* 输入框事件 */
  bindManual: function (e) {
    var num = e.detail.value;
    // 将数值与状态写回  
    this.setData({
      num: num
    });
  },
  onShareAppMessage: function () {
    return {
      title: this.data.title,
      path: '/pages/detailsTuan/detailsTuan?title=' + this.data.title + '&id=' + this.data.id
    }
  },
  getCarCount() {
    let that = this;
     post('index/cjlist',{},function(res){
       wx.hideLoading()
       that.setData({ carCount: res.data.data });
     })
  }

})
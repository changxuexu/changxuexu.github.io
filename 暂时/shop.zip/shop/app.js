//app.js
App({
  d: {
    hostUrl: 'https://hysshop.ijiaque.com/apii/',
    token:'',
    session:'',
    judLogin:'',
    store:'',
    pid:''
  },
  onLaunch: function () {
     this.login();
  },
  
  login:function(){
    var that = this;
    wx.login({
      success: res => {
        wx.request({
          method: 'post',
          url: that.d.hostUrl + "user/getopenidlogin",
          data: {
            code: res.code
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
          
            if (res.data.status==1){
              that.d.token = res.data.data.token;
              that.d.session = res.data.session_key
              that.jiancha();
            }
          }
        })
      }
    })
  },
  jiancha(){
    let that = this;
    wx.request({
      method: 'post',
      url: that.d.hostUrl + "user/is_info",
      data: {
        token: that.d.token
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        if (res.data.status == 1 || res.data.status == 2){
          that.d.judLogin=res.data.data;
          that.d.store = res.data.store;
        } else {
          wx.showToast({
            title: '网络错误',
            icon: 'waiting',
            duration: 1000
          })
        }
      }
    })
  },
  pays: function (orderNo,values,ben,tuan){
    let that = this;
    console.log(values)
    wx.request({
      url: that.d.hostUrl + "pay/pay",
      method: 'post',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      data: {
        token: that.d.token,
        order_no: orderNo,
        ...values
      },
      success: function (res) {
        if (res.data.status==1){
          that.wx_pay(res.data.data, orderNo, ben,tuan)
        } else if (res.data.status == 3){
          wx.navigateTo({
            url: '/pages/success/success?orderno=' + orderNo+'&tuan='+tuan
          })
        } else {
          wx.showToast({
            title: res.data.info,
            icon: 'none',
            duration: 1000
          })
        }
        
      },
      'fail': function (res) {
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 1000
        })
      }

    })
  },
  wx_pay(alplay,orderNo,ben,tuan){
    wx.requestPayment({
      'timeStamp': alplay.timeStamp,
      'nonceStr': alplay.nonceStr,
      'package': alplay.package,
      'signType': 'MD5',
      'paySign': alplay.paySign,
      'success': function (res) {
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 1000
        });
        wx.navigateTo({
          url: '/pages/success/success?orderno=' + orderNo + '&tuan=' + tuan
        })
      },
      'fail': function (res) {
        wx.showToast({
          title: '支付失败',
          icon: 'none',
          duration: 1000
        });
        if (ben) {
          return;
        }
        wx.navigateTo({
          url: '/pages/fail/fail?orderno=' + orderNo
        })

      }
    })
  }
})
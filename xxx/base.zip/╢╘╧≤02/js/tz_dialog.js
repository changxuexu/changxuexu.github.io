/*
	author:Jery
	date:2016-04-08
	content:sg类库插件之弹出组件
*/
(function($){
	$.tzDialog = {
		zIndex:100,
		Sure:function(options){
			var $dialog = this.init(options);
			$dialog.find(".cancel,.sure").remove();
		},
		Alert:function(options){
			var $dialog = this.init(options);
			$dialog.find(".cancel").remove();
		},
		Confirm:function(options){
			this.init(options);
		},
		init:function(options){
			this.zIndex++;
			var opts = $.extend({},$.tzDialog.defaults,options);
			var $dialog = this.template(opts);
			//位置居中显示
			this._position($dialog);
			//调用改变窗口
			this._resize($dialog);
			//调用拖拽
			if(opts.drag)this._drag($dialog);
			//宽度、高度、背景颜色、透明度、边框、阴影
			$dialog.css({
				width:opts.width,
				height:opts.height,
				background:opts.background,
				border:opts.border,
				zIndex:this.zIndex
			}).next().css({zIndex:this.zIndex-1});
			this._events($dialog,opts);
			return $dialog;
		},
		template:function(opts){
			var $dialog = $("<div class='dialog'>"+
			"		<div class='header'>"+
			"			<span>"+opts.title+"</span>"+
			"		<a href='javascript:void(0);' class='close'><i class='iconfont'>&#xe607;</i></a>"+
			"		</div>"+
			"		<div class='content'>"+opts.content+"</div>"+
			"		<div class='button'>"+
			"			<a href='javascript:void(0);' class='sure'>确认</a>"+
			"			<a href='javascript:void(0);' class='cancel'>取消</a>"+
			"		</div>"+
			"	</div>");
			//追加到body中
			$("body").append($dialog).append("<div class='overlay'></div>");
			return $dialog;
		},
		//定位居中
		_position:function($dialog){
			var left = ($(window).width() - $dialog.width())/2;
			var top = ($(window).height() - $dialog.height())/2; 
			$dialog.css({left:left,top:top});
		},
		//时实改变弹出层位置
		_resize:function($dialog){
			var $this = this;
			$(window).resize(function(){
				$this._position($dialog);
			});
		},
		//拖拽
		_drag:function($dialog){
			$dialog.find(".header").mousedown(function(e){
				var ev = e||window.event;
				var x = ev.pageX - $dialog.offset().left;
				var y = ev.pageY - $dialog.offset().top;
				$(document).mousemove(function(e){
					var ev = e||window.event;
					var l = ev.pageX - x;
					var t = ev.pageY - y;
					var maxL = $(window).width() - $dialog.get(0).offsetWidth;
					var maxT = $(window).height() - $dialog[0].offsetHeight;
					if(l<0)l=0;
					if(t<0)t=0;
					if(l>maxL)l = maxL;
					if(t>maxT)t = maxT;
					$dialog.css({left:l,top:t});
				}).mouseup(function(){
					$(document).off("mousemove");
					$(document).off("mouseup");
				}).mousedown(function(){
					return false;
				});
			});
		},
		//触发事件
		_events:function($dialog,opts){
			//点击确认按钮
			$dialog.find(".sure").on("click",function(){
				if(opts.callback){
					opts.callback.call($dialog,true);
					$dialog.next().remove();
					$dialog.remove();
				}
			});
			//点击取消按钮
			$dialog.find(".cancel,.close").on("click",function(){
				if(opts.callback){
					opts.callback.call($dialog,false);
					$dialog.next().remove();
					$dialog.remove();
				}
			});
			//点击阴影层
			if(opts.overlayClick){
				$dialog.next().click(function(){
					$(this).remove();
					$dialog.remove();
				});
			}
		},
	};
	$.tzDialog.defaults = {
		title:"您要删除吗？",
		content:"潭州学院在湖南长沙！",
		width:320,
		height:200,
		background:"#333",
		drag:true,
		overlayClick:true
	};
})(jQuery);
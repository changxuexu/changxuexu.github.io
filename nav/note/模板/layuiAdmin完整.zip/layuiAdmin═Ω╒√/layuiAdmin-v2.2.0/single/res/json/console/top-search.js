{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "keywords": "UI"
    ,"frequency": 8520
    ,"userNums": 2216
  },{
    "keywords": "layer 弹出层组件"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "此表格是静态模拟数据"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 888
    ,"userNums": 333
  }]
}
{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "keywords": "UI"
    ,"frequency": 8520
    ,"userNums": 2216
  },{
    "keywords": "layer 弹出层组件"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "此表格是静态模拟数据"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  },{
    "keywords": "前端 UI"
    ,"frequency": 777
    ,"userNums": 333
  }]
}
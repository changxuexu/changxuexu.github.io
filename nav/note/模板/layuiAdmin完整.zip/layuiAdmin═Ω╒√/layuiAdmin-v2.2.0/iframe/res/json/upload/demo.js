{
  "code": 0,
  "msg": "",
  "data": {
    "src": "https://unpkg.com/outeres/demo/avatar/0.png"
  }
}
/**
 * 界面入口模块  
 */
 
layui.define('admin', function(exports){
  var setter = layui.setter;
  var element = layui.element;
  var admin = layui.admin;
  var tabsPage = admin.tabsPage;
  var view = layui.view;
  var util = layui.util;
  
  // 打开标签页
  var openTabsPage = function(options){
    options = $.extend({
      url: '',
      escape: true
    }, options);

    // 遍历页签选项卡
    var matchTo;
    var tabs = $('#LAY_app_tabsheader>li');
    var path = options.url.replace(/(^http(s*):)|(\?[\s\S]*$)/g, '');
    
    tabs.each(function(index){
      var li = $(this);
      var layid = li.attr('lay-id');
      
      if(layid === options.url){
        matchTo = true;
        tabsPage.index = index;
      }
    });

    options.title = options.title || (tabsPage.index === 0 ? '' : '新标签页');
    
    // 定位当前 tabs
    var setThisTab = function(){
      element.tabChange(FILTER_TAB_TBAS, options.url);

      admin.tabsBodyChange(tabsPage.index, {
        url: options.url,
        title: options.title
      });
    };
    
    if(setter.pageTabs){
      // 如果未在选项卡中匹配到，则追加选项卡
      if(!matchTo){
        // 延迟修复 Firefox 空白问题
        setTimeout(function(){
          $(APP_BODY).append([
            '<div class="layadmin-tabsbody-item layui-show">'
              ,'<iframe src="'+ options.url +'" frameborder="0" class="layadmin-iframe"></iframe>'
            ,'</div>'
          ].join(''));
          setThisTab();
        }, 10);
        
        tabsPage.index = tabs.length;
        element.tabAdd(FILTER_TAB_TBAS, {
          title: '<span>'+ function(title){
            return options.highlight 
              ? '<span style="'+ options.highlight +'">'+ title +'</span>' 
            : title;
          }(util.escape(options.title)) +'</span>',
          id: options.url,
          attr: path
        });

        // 新添加-2023-11-14
        layui.data(FILTER_TAB_TBAS, {
          key: layui.md5(options.url)
          ,value: {
            title: options.title
            ,id: options.url
            ,attr: path
            ,index: tabsPage.index
          }
        });        
        layui.data(FILTER_TAB_TBAS, {
          key: 'layui-this'
          ,value: layui.md5(options.url)
        });

        // 新添加-end
        
      }
    } else {
      var iframe = admin.tabsBody(admin.tabsPage.index).find('.layadmin-iframe');
      iframe[0].contentWindow.location.href = options.url;
    }

    // 执行定位当前 tabs
    setThisTab();
  };
  
  var APP_BODY = '#LAY_app_body';
  var FILTER_TAB_TBAS = 'layadmin-layout-tabs';
  var $ = layui.$;
  var $win = $(window);
  
  //初始
  if(admin.screen() < 2) admin.sideFlexible();
  
  view().autoRender();

  // 根据 record 属性，打开对应的初始页面
  var openInitPage = (function fn(){
    var url = layui.url();
    var hash = url.hash;
    var record = setter.record || {};
    var url = hash.path.join('/');
    var title = function(){
      var dataRecord = layui.data(setter.tableName).record || {};
      return dataRecord[url] || '';
    }();

    (function(){
      if(!record.url) return;
      if(url){
        // 禁止读取远程 url
        if(function(url){
          return /^(\w*:)*\/\/.+/.test(url) && url.indexOf(location.hostname) === -1
        }($.trim(url))) return fn;

        openTabsPage({
          url: url,
          title: title
        });
      }
    })();

    setTimeout(function(){
      $('#'+ setter.container).css('visibility', 'visible');
    }, 300);

    return fn;
  })();

  // 新添加-2023-11-14
  if ($('[lay-filter="' + FILTER_TAB_TBAS + '"]').length > 0) {
    var tabs = layui.data(FILTER_TAB_TBAS), cur_tab = tabs['layui-this']?tabs[tabs['layui-this']]:undefined;
    $.each(tabs, function (i, elem) {
      if ($('#LAY_app_tabsheader>li[lay-id="' + elem.id + '"]').length == 0 && i != 'layui-this') {
        element.tabAdd(FILTER_TAB_TBAS, {
          title: '<span>' + elem.title + '</span>'
          , id: elem.id
          , attr: elem.attr
        });
        // $(APP_BODY).append('<div class="layadmin-tabsbody-item"></div>');
        $(APP_BODY).append([
          '<div class="layadmin-tabsbody-item">'
            ,'<iframe src="'+ elem.id +'" frameborder="0" class="layadmin-iframe"></iframe>'
          ,'</div>'
        ].join(''));
      }
    });
    if (cur_tab) {
      element.tabChange(FILTER_TAB_TBAS, cur_tab.id);
      admin.tabsBodyChange(tabsPage.index, {
        url: cur_tab.id,
        title: cur_tab.title
      });
    }
  }
  // 新添加-end

  // 对外输出
  var adminuiIndex = {
    openTabsPage: openTabsPage
  };

  $.extend(admin, adminuiIndex);
  exports('adminIndex', adminuiIndex);
});

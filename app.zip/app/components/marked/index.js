export default './lib/marked'
